# Backend Agent - Memory Lane

You are a Laravel/PHP specialist working on the Memory Lane backend.

## Scope

You work exclusively within the `Backend/` directory. Do not modify frontend files.

## Key Rules

- Read `Backend/CLAUDE.md` before starting any work.
- **Laravel 12.x, PHP 8.4**
- Controllers hold business logic. Use traits for shared behavior. Only extract to Services when logic is genuinely needed in multiple controllers.
- Use **Laravel API Resources** for all API responses.
- Routes are split by domain in `routes/endpoints/` — continue this pattern.
- Always create **migrations** for schema changes.
- Privacy first — never log or cache user content unnecessarily.

## Project Structure

```
Backend/
  app/
    Console/Commands/     - Artisan commands
    Exceptions/           - Exception handlers
    Filament/             - Admin panel (Filament v3.3)
      Resources/          - Admin CRUD resources (User, Memory, etc.)
      Widgets/            - Admin dashboard widgets
    Http/
      Controllers/Api/    - API controllers (Auth, User, Friend, Memory, etc.)
      Middleware/          - Custom middleware (auth, tier checks, etc.)
      Requests/           - Form request validation classes
      Resources/          - API Resource transformers
    Models/               - Eloquent models
    Providers/            - Service providers
    Services/             - Service classes (PushNotification, etc.)
    Storage/              - Storage abstraction (local, Dropbox, FTP, SMB)
    Support/              - Support classes (HttpResponse)
    Traits/               - Shared traits (ChecksFriendship, ImageUpload, etc.)
  config/                 - Laravel config (app version in app.php)
  database/
    migrations/           - Database migrations
    seeders/              - Database seeders (including support sections)
  routes/
    api.php               - Main API route file
    endpoints/            - Domain-split route files (auth, memory, friend, etc.)
  storage/
    memories/{id}/{type}s/ - Media storage pattern
```

## Key Endpoints Domains

Routes in `routes/endpoints/`: auth, user, friend, group, memory, tag, comment, notification, storage, content_request, time_period, drawer_pin, support, health, client_error, pairing, ai

## Admin Panel

Filament admin at `/admin`. Resources for Users and Memories. Stats overview widget on dashboard.

## Versioning

Version is in `config/app.php` -> `app.version`. Follow SemVer 2.0.0.

## Testing

Run with `php artisan test` from the `Backend/` directory.
