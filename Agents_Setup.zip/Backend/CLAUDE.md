# Memory Lane Backend - Laravel/PHP

## Technology

- **Laravel 12.x** with **PHP 8.4**
- **Filament ^3.3** admin panel at `/admin`
- **Laravel Sanctum** for API authentication
- **MySQL/MariaDB** database
- **Local filesystem** for media storage (with Dropbox, FTP, SMB providers)

## Code Guidelines

### Controllers & Logic
- Controllers hold the business logic — this is intentional.
- Use **traits** (`app/Traits/`) for shared behavior across controllers.
- Only extract to **Services** (`app/Services/`) when logic is genuinely needed in multiple controllers.

### API Responses
- Use **Laravel API Resources** (`app/Http/Resources/`) for all responses.
- Base resource: `ApiResource`.

### Routing
- All API routes under `/api/v1/`.
- Routes are split by domain in `routes/endpoints/` — continue this pattern.
- Current domains: auth, user, friend, group, memory, tag, comment, notification, storage, content_request, time_period, drawer_pin, support, health, client_error, pairing, ai.

### Database
- Always create **migrations** for schema changes.
- Update seeders when adding features that need default data.
- Update support sections seeder when adding new app areas.

### Validation
- Use **Form Request** classes (`app/Http/Requests/`) for request validation.
- Base class: `AuthorizedFormRequest`.

### Storage
- Storage abstraction in `app/Storage/` with interface `StorageProviderInterface`.
- Providers: Local, Dropbox, FTP, SMB.
- Media storage pattern: `storage/memories/{memory_id}/{type}s/`.
- Use `ResolvesStorage` trait for storage operations.

### Admin Panel
- Filament resources in `app/Filament/Resources/` (User, Memory).
- Dashboard widgets in `app/Filament/Widgets/`.

### Privacy
- Never log, cache, or transmit user content beyond what's strictly necessary.

## Models

Key models in `app/Models/`: User, Memory (via separate package paths), Friendship, FriendInvite, Group, Tag, Comment, Reaction, ContentRequest, TimePeriod, DrawerPin, DeviceToken, UserStorageSetting, UserTier, StorageMigration, MediaUploadHistory, MemoryContentOrder, MemoryContentPendingUpload, SupportTicket, AppSetting.

## Version

`config/app.php` -> `app.version`. Follow SemVer 2.0.0.

## Running

- Development: `php artisan serve` at `http://127.0.0.1:8000`
- Production: `https://memorylane.blommemix.dk/api`
- Tests: `php artisan test`
