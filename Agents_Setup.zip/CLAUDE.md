# Memory Lane - Claude Code Instructions

## Session Startup

1. **Read `PROJECT.md`** in the project root. This is the living document describing the entire project, its architecture, code guidelines, and development plan.
2. **Follow the Session Startup Checklist** at the top of `PROJECT.md` (verify backend, verify frontend, then resume work).
3. **Resume work** from where the plan left off — find the next uncompleted `[ ]` step.

## Workflow Rules

- When you **start** a step: update `PROJECT.md` immediately — mark it `[~]` and note the starting date.
- When you **complete** a step: update `PROJECT.md` immediately — mark it `[x]`, note the date, and log any changes or decisions in the Change Log.
- If something **changes** during a step, update `PROJECT.md` to reflect reality.
- If you encounter **issues or decisions** that affect future steps, note them in the Notes & Decisions section.
- Always follow the **Code Guidelines** section in `PROJECT.md` when writing code.

## Versioning

Both the frontend AND backend follow [Semantic Versioning 2.0.0](https://semver.org/).

- **Frontend version:** `Frontend/pubspec.yaml` → `version` field
- **Backend version:** `Backend/config/app.php` → `app.version`

When completing a phase, bump the version appropriately (patch for bug fixes, minor for new features, major for breaking changes). Update whichever is relevant — if a phase touches both, update both.

## Project Overview

**Memory Lane** is a collaborative memory-sharing app. Users create memories with mixed content (text, audio, images, video), share them with friends, and organize them into groups. See `PROJECT.md` for full details.

| Layer    | Technology      | Notes                                      |
|----------|-----------------|--------------------------------------------|
| Frontend | Flutter (Dart)  | SDK ^3.7.0, Material 3                     |
| Backend  | Laravel (PHP)   | 12.x, PHP 8.4, REST API under `/api/v1/`  |
| Admin    | Filament ^3.3   | Admin panel at `/admin`                    |
| Auth     | Laravel Sanctum  | Token-based + biometric on frontend       |
| Database | MySQL/MariaDB   | Via Laravel migrations                     |
| Storage  | Local filesystem | Public storage for media files             |

## Key Code Guidelines (Quick Reference)

### General
- **Privacy first** — never log, cache, or transmit user content beyond what's strictly necessary.
- All user-facing strings go through the **localization system** (`AppLocalizations`).
- When a phase is complete, all missing labels must be translated to all 8 languages (EN, DA, DE, ES, FR, JA, KO, ZH).

### Backend (Laravel)
- Controllers hold the business logic. Use traits for shared behavior. Only extract to Services when logic is genuinely needed in multiple controllers.
- Use **Laravel API Resources** for all responses.
- Routes are split by domain in `routes/endpoints/` — continue this pattern.
- Always create **migrations** for schema changes.

### Frontend (Flutter)
- **State management:** Provider + ChangeNotifier. Do not introduce Riverpod, Bloc, etc.
- **Services are singletons.** All HTTP calls go through `ApiService`.
- Break screens into small, composable widget files.
- Follow Dart conventions: `snake_case` files, `PascalCase` classes.
- Use the existing `ThemeProvider` and `ColorConfig` — do not hardcode colors.

## Post-Development: Forced Update Assessment

After completing a phase or significant change, assess whether a **minimum app version update** should be recommended or required. Present your findings to the user — they will decide whether to set it in the admin panel (Administration > App Settings).

### When to RECOMMEND a forced update (suggest to user)
- **Security fixes** — patched vulnerabilities, auth changes, encryption updates
- **Privacy changes** — changes to how data is collected, stored, or transmitted
- **Major bug fixes** — fixes for data corruption, data loss, or significant UX-breaking bugs

### When a forced update is REQUIRED (strongly advise user)
- **Breaking API changes** — removed or renamed endpoints, changed request/response formats, removed fields that the old frontend depends on
- **Database schema changes** that alter API responses in backward-incompatible ways
- **Authentication/authorization changes** — new auth flow, token format changes, permission model changes
- **Security vulnerabilities** — if the old version has a known exploitable vulnerability

### How to present this
After completing work, if any of the above criteria apply:

1. Tell the user whether a forced update is **recommended** or **required**, the reason(s) why, and which version
2. **Store the recommendation in the database** so it appears as a banner in the admin panel. Run this via `php artisan tinker` in the Backend directory:
   ```php
   App\Models\AppSetting::setUpdateRecommendation('recommended', '0.10.0', [
       'Reason 1',
       'Reason 2',
   ]);
   ```
   Use `'required'` instead of `'recommended'` when the update is mandatory. Use the version being deployed and provide clear, human-readable reasons.
3. The recommendation will appear as a banner on the **Administration > App Settings** page with "Apply" and "Dismiss" buttons. It also shows how many users would be affected.

If none of the criteria apply, no action is needed — don't mention it and don't store a recommendation.

## Maintenance Reminders

- **Support sections:** When adding new features or app areas, update the support sections list in the `support_settings` database seeder (`Backend/database/seeders/`) so that users can select the new area when submitting support tickets. The sections are admin-configurable at runtime, but the seeder should always reflect the current set of app areas for fresh deployments.

## Important Notes

- **Backend production URL:** `https://memorylane.blommemix.dk/api`
- **Local development:** Backend runs via `php artisan serve` at `http://127.0.0.1:8000`
- **Frontend API config:** `lib/config/api_config.dart` — toggle `useDevelopmentServer` for local/production
- **Upload flow:** Two-step process (create content record → get upload_key → upload file)
- **Media storage pattern:** `storage/memories/{memory_id}/{type}s/`
