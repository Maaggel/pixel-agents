# Memory Lane Frontend - Flutter/Dart

## Technology

- **Flutter** with Dart SDK ^3.7.0
- **Material 3** design system
- **Auth:** Laravel Sanctum tokens + biometric on device

## Code Guidelines

### State Management
- **Provider + ChangeNotifier** exclusively. Do not introduce Riverpod, Bloc, or other packages.
- Providers live in `lib/providers/`.

### Services
- All services are **singletons**.
- All HTTP calls go through `ApiService` (`lib/services/api_service.dart`).
- Service files live in `lib/services/`.

### UI
- Break screens into small, composable widget files.
- Screens go in `lib/screens/`, sub-pages in `lib/screens/settings/`.
- Reusable widgets go in `lib/widgets/`, organized by feature subdirectories (e.g., `widgets/friends/`, `widgets/settings/`, `widgets/sharing/`).
- Use `ThemeProvider` and `ColorConfig` (`lib/config/color_config.dart`) — never hardcode colors.

### Naming
- `snake_case` for file names.
- `PascalCase` for classes.

### Localization
- All user-facing strings go through `AppLocalizations`.
- Supported languages: EN, DA, DE, ES, FR, JA, KO, ZH.
- When a phase is complete, ensure all labels are translated to all 8 languages.

### Privacy
- Never log, cache, or transmit user content beyond what's strictly necessary.

## API Integration

- Config: `lib/config/api_config.dart` — toggle `useDevelopmentServer` for local/production.
- Local: `http://127.0.0.1:8000`
- Production: `https://memorylane.blommemix.dk/api`
- Upload flow: two-step (create content record -> get `upload_key` -> upload file).

## Models

Data models in `lib/models/`: user, friend, group, memory_content, tag, time_period, comment, app_notification, support_ticket, recording_data, upload_status, content_request.

## Version

`pubspec.yaml` -> `version` field. Follow SemVer 2.0.0.
