# Memory Lane - Project Overview & Development Plan

> **This file is a living document for AI-assisted development sessions.**
> When resuming work, read this file first to understand the project state, what has been completed, and what remains.
> After completing a step or making changes, update this file to reflect the current state.

---

## Session Startup Checklist

> **Run this at the start of every new session.**

### 1. Read this file
Read this `PROJECT.md` to understand current state, what's been done, and what's next.

### 2. Verify backend can run
Check if the backend is running locally by trying to reach `http://127.0.0.1:8000/api`.

**If it's NOT running, diagnose and fix before continuing:**

- **Check PHP is installed:** Run `php -v`. Must be PHP 8.4. If not found:
  - Windows: Check if PHP is in PATH. Common locations: `C:\php\`, `C:\laravel\`, XAMPP/WAMP paths.
  - If not installed, help the user install PHP 8.4 (download from php.net or via Scoop/Chocolatey).
  - If installed but wrong version, help the user upgrade to 8.4.
- **Check Composer is installed:** Run `composer --version`. If not found:
  - Help the user install Composer (https://getcomposer.org/download/).
- **Check dependencies are installed:** If `Backend/vendor/` doesn't exist, run:
  ```
  cd Backend
  composer install
  ```
- **Check .env exists:** If `Backend/.env` doesn't exist, copy from `.env.example` and configure database credentials.
- **Check database is accessible:** Run `php artisan migrate:status` to verify DB connection. If it fails, help the user configure the database in `.env`.
- **Start the server:**
  ```
  cd Backend
  php artisan serve
  ```
  The server runs at `http://127.0.0.1:8000` by default.

### 3. Verify frontend can run
Check if Flutter is available and the frontend can build.

**Diagnose and fix if needed:**

- **Check Flutter is installed:** Run `flutter --version`. If not found:
  - Help the user install Flutter SDK (https://docs.flutter.dev/get-started/install).
  - Ensure `flutter` is in PATH.
- **Check dependencies are installed:** If `Frontend/.dart_tool/` doesn't exist or packages are missing:
  ```
  cd Frontend
  flutter pub get
  ```
- **Check the frontend points to the local backend:**
  - Open `Frontend/lib/config/api_config.dart`
  - `developmentHost` should be `127.0.0.1:8000`
  - `useDevelopmentServer` should be `true`
  - `baseUrl` should use `http://` (not https) for local development
  - If any of these are wrong, fix them.

### 4. Resume work
Pick up from where the plan left off - find the next uncompleted `[ ]` step.
Be sure to update frontend app version according to standard semantic versioning when it makes sense.

---

## Last Updated

2026-03-05 - Phase 32 added (AI Features — Transcription, Smart Metadata, Cover Art & TTS). 20 steps across 6 sub-phases.
2026-03-04 - Phase 31 completed (Watch Experience Enhancement). Frontend 0.12.0+1, Backend 0.14.0.
2026-03-05 - Phase 30 completed (Watch Recording Reliability & Error Logging). Frontend 0.11.1+1, Backend 0.13.1.
2026-03-02 - Phase 26 added (Support / Suggestion / Bug Report System). 13 steps planned.
2026-02-20 - Phase 25 completed (step 25.8 groups page reload fix). Version 0.9.0+1.

---

## Project Summary

**Memory Lane** is a collaborative memory-sharing application. Users can create memories composed of mixed content (text, audio recordings, images, video), share them with other users, and browse/manage their collection. The project consists of two separate repositories living in the same parent folder.

---

## Core Principles: Privacy & Data Ownership

> **This section is non-negotiable. Every feature, every line of code, and every architectural decision must respect these principles.**

Memory Lane handles deeply personal content - people's memories, voices, photos, and private moments. We take this responsibility seriously.

### 1. Users own their data - fully, unconditionally
- All content created by a user belongs to **them**, not to us
- Users must always be able to export, move, or delete their data
- External storage providers (Phase 9) exist specifically so users can keep files on **their own** infrastructure
- If a user deletes their account, their data is gone - we don't retain copies

### 2. We cannot read your memories
- End-to-end encryption (Phase 10) means the server **never** sees plaintext content
- Zero-knowledge architecture: even with full database access, we cannot decrypt user content
- Encryption keys are derived client-side and never transmitted to the server

### 3. Minimal data collection
- We only collect what is strictly necessary to make the app function
- No behavioral tracking, no analytics profiling, no selling data to third parties - ever
- Usage tracking (Phase 11) is limited to aggregate counts (storage used, memory count) for tier enforcement, not content analysis

### 4. Transparency
- The user must always know where their data is stored and how it's protected
- Storage location is visible and changeable in settings
- Encryption status is clearly indicated per memory
- No hidden data flows or silent uploads

### 5. Security by default
- Authentication tokens expire and require re-authentication
- Upload keys are cryptographically random (64 chars) and single-use
- CORS will be tightened to specific origins before production
- SSL/TLS enforced for all production traffic
- Contributor uploads relay through our server only when necessary (owner's storage) and are not retained after delivery

**These principles inform the roadmap directly:** External storage (Phase 9) gives users physical control of their files. E2E encryption (Phase 10) gives them cryptographic privacy. The payment model (Phase 11) will never hold data hostage - downgrading a tier limits new creation, never deletes existing content.

---

## Technology Stack

| Layer    | Technology       | Version     | Notes                                    |
|----------|------------------|-------------|------------------------------------------|
| Frontend | Flutter (Dart)   | SDK ^3.7.0  | App version 0.9.0+1 (`pubspec.yaml`), Material 3 |
| Backend  | Laravel (PHP)    | 12.x        | App version 0.9.0 (`config/app.php`), PHP 8.4, REST API under `/api/v1/` |
| Admin    | Filament          | ^3.3        | Admin panel at `/admin`                  |
| Auth     | Laravel Sanctum  | ^4.0        | Token-based, plus biometric on frontend  |
| Database | MySQL/MariaDB    | -           | Via Laravel migrations                   |
| Storage  | Local filesystem  | -           | Public storage for media files           |

---

## Repository & Folder Structure

```
(project root)/
├── PROJECT.md                      <-- THIS FILE (living document)
├── Backend\            <-- Laravel API
│   ├── app\
│   │   ├── Http\
│   │   │   ├── Controllers\Api\
│   │   │   │   ├── AuthController.php
│   │   │   │   ├── GroupController.php
│   │   │   │   ├── MemoryController.php
│   │   │   │   ├── TagController.php
│   │   │   │   ├── FriendController.php
│   │   │   │   ├── NotificationController.php
│   │   │   │   └── UserController.php
│   │   │   ├── Middleware\
│   │   │   ├── Requests\
│   │   │   │   ├── ShareMemoryRequest.php
│   │   │   │   ├── UpdateSharePermissionRequest.php
│   │   │   │   ├── ShareGroupRequest.php
│   │   │   │   └── UpdateGroupSharePermissionRequest.php
│   │   │   └── Resources\
│   │   │       ├── MemoryResource.php
│   │   │       ├── MemoryListResource.php
│   │   │       ├── MemoryContentResource.php
│   │   │       ├── GroupResource.php
│   │   │       ├── GroupListResource.php
│   │   │       ├── TagResource.php
│   │   │       ├── TagListResource.php
│   │   │       ├── FriendListResource.php
│   │   │       ├── FriendshipResource.php
│   │   │       ├── FriendInviteResource.php
│   │   │       ├── UserSearchResource.php
│   │   │       ├── NotificationResource.php
│   │   │       ├── NotificationListResource.php
│   │   │       └── ApiResource.php
│   │   ├── Models\
│   │   │   ├── User.php
│   │   │   ├── Memory.php
│   │   │   ├── MemoryContent.php
│   │   │   ├── MemoryContentOrder.php
│   │   │   ├── MemoryContentPendingUpload.php
│   │   │   ├── MediaUploadHistory.php
│   │   │   ├── Group.php
│   │   │   ├── Tag.php
│   │   │   ├── Friendship.php
│   │   │   ├── FriendInvite.php
│   │   │   ├── AppNotification.php
│   │   │   └── DeviceToken.php
│   │   ├── Filament\
│   │   │   ├── Resources\
│   │   │   │   ├── UserResource.php
│   │   │   │   ├── UserResource\Pages\
│   │   │   │   ├── MemoryResource.php
│   │   │   │   └── MemoryResource\Pages\
│   │   │   └── Widgets\
│   │   │       ├── StatsOverview.php
│   │   │       ├── ContentTypeChart.php
│   │   │       └── UserGrowthChart.php
│   │   ├── Providers\
│   │   │   └── Filament\AdminPanelProvider.php
│   │   └── Traits\
│   │       ├── ImageUpload.php
│   │       ├── MemoryContentManagement.php
│   │       ├── ChecksFriendship.php
│   │       ├── CreatesNotifications.php
│   │       └── ResolvesStorage.php
│   │   └── Storage\
│   │       ├── StorageProviderInterface.php
│   │       ├── StorageManager.php
│   │       ├── StorageManifest.php
│   │       └── Providers\
│   │           ├── BaseStorageProvider.php
│   │           └── LocalStorageProvider.php
│   ├── config\
│   ├── database\
│   │   ├── factories\
│   │   ├── migrations\
│   │   └── seeders\
│   ├── routes\
│   │   ├── api.php
│   │   └── endpoints\
│   │       ├── auth.php
│   │       ├── memory.php
│   │       ├── group.php
│   │       ├── tag.php
│   │       ├── friend.php
│   │       ├── notification.php
│   │       └── user.php
│   ├── storage\
│   ├── composer.json
│   └── .env
│
└── Frontend\           <-- Flutter app
    ├── lib\
    │   ├── main.dart
    │   ├── config\
    │   │   ├── api_config.dart
    │   │   ├── color_config.dart
    │   │   ├── theme_config.dart
    │   │   ├── language_config.dart
    │   │   └── debug_config.dart
    │   ├── models\
    │   │   ├── user.dart
    │   │   ├── memory.dart
    │   │   ├── memory_content.dart
    │   │   ├── group.dart
    │   │   ├── tag.dart
    │   │   ├── friend.dart
    │   │   ├── app_notification.dart
    │   │   ├── upload_status.dart
    │   │   ├── pending_upload.dart
    │   │   └── recording_data.dart
    │   ├── providers\
    │   │   ├── user_provider.dart
    │   │   ├── theme_provider.dart
    │   │   ├── language_provider.dart
    │   │   └── privacy_provider.dart
    │   ├── services\
    │   │   ├── api_service.dart
    │   │   ├── auth_service.dart
    │   │   ├── user_service.dart
    │   │   ├── memory_service.dart
    │   │   ├── group_service.dart
    │   │   ├── tag_service.dart
    │   │   ├── friend_service.dart
    │   │   ├── upload_service.dart
    │   │   ├── notification_service.dart
    │   │   ├── app_notification_service.dart
    │   │   └── recording_state.dart
    │   ├── screens\
    │   │   ├── splash_screen.dart
    │   │   ├── login_screen.dart
    │   │   ├── register_screen.dart
    │   │   ├── forgot_password_screen.dart
    │   │   ├── home_screen.dart
    │   │   ├── create_memory_screen.dart
    │   │   ├── memory_detail_screen.dart
    │   │   ├── memory_settings_screen.dart
    │   │   ├── record_memory_screen.dart
    │   │   ├── profile_screen.dart
    │   │   ├── edit_profile_screen.dart
    │   │   ├── friends_screen.dart
    │   │   ├── groups_screen.dart
    │   │   ├── group_detail_screen.dart
    │   │   ├── notifications_screen.dart
    │   │   └── settings_screen.dart
    │   ├── widgets\
    │   │   ├── memory_list.dart
    │   │   ├── memory_content_list.dart
    │   │   ├── memory_audio_player.dart
    │   │   ├── memory_content_editor.dart
    │   │   ├── custom_bottom_nav.dart
    │   │   ├── custom_input_field.dart
    │   │   ├── add_content_modal.dart
    │   │   ├── create_memory_modal.dart
    │   │   ├── profile_avatar.dart
    │   │   ├── tag_picker_modal.dart
    │   │   ├── filter_sort_buttons.dart
    │   │   ├── pin_dialog.dart
    │   │   ├── upload_progress.dart
    │   │   ├── pending_uploads_list.dart
    │   │   ├── shimmer_loading.dart
    │   │   ├── friends\
    │   │   │   ├── friend_tile.dart
    │   │   │   ├── friend_list_tab.dart
    │   │   │   ├── friend_requests_tab.dart
    │   │   │   ├── friend_search_tab.dart
    │   │   │   └── friend_invites_tab.dart
    │   │   └── settings\
    │   │       ├── color_theme_selector.dart
    │   │       ├── notification_settings.dart
    │   │       ├── settings_container.dart
    │   │       └── settings_selection_tile.dart
    │   ├── utils\
    │   │   ├── exceptions.dart
    │   │   ├── date_formatter.dart
    │   │   ├── image_helper.dart
    │   │   └── debug_dialog.dart
    │   └── l10n\
    │       ├── app_en.arb
    │       ├── app_da.arb
    │       ├── app_de.arb
    │       ├── app_es.arb
    │       ├── app_fr.arb
    │       ├── app_ja.arb
    │       ├── app_ko.arb
    │       └── app_zh.arb
    ├── assets\images\
    ├── test\
    ├── pubspec.yaml
    └── l10n.yaml
```

---

## Database Schema

| Table                            | Purpose                                       |
|----------------------------------|-----------------------------------------------|
| `users`                         | User accounts (name, email, is_admin, is_banned, password, profile_picture, notification_preferences JSON) |
| `memories`                      | Memory entries (title, cover_image, is_personal, is_flagged) |
| `memory_user`                   | Pivot: which users belong to which memories (permission: owner/contribute/view) |
| `memory_contents`               | Content items: type (text/audio/image/video), text, source, thumbnail |
| `memory_content_order`          | Ordering of content within a memory            |
| `memory_contents_pending_upload`| Temporary upload keys for pending media        |
| `media_upload_history`          | Audit trail of all media uploads               |
| `groups`                        | Memory groups (name, color, user_id)           |
| `group_memory`                  | Pivot: which memories belong to which groups   |
| `group_user`                    | Pivot: shared groups (group_id, user_id, permission_level) |
| `tags`                          | User tags (name, user_id, unique per user)     |
| `taggables`                     | Polymorphic pivot: tags on memories and groups |
| `friendships`                   | Friend relationships (user_id, friend_id, status: pending/accepted) |
| `friend_invites`                | Shareable invite links (code, used_by, expires_at) |
| `notifications`                 | In-app notifications (type, title, message, data JSON, read_at) |
| `device_tokens`                 | Push notification tokens (token, platform: android/ios/web) |
| `user_storage_settings`         | Per-user storage provider config (provider_type, encrypted config JSON) |
| `personal_access_tokens`        | Sanctum auth tokens                            |

---

## API Endpoints

### Authentication (unauthenticated)
- `POST /api/v1/auth/register` - Register new user
- `POST /api/v1/auth/login` - Login, returns bearer token

### User (authenticated)
- `GET /api/v1/user` - Current user profile
- `POST /api/v1/user/profile` - Update name/email
- `POST /api/v1/user/profile/picture` - Update profile picture
- `GET /api/v1/user/memories` - Current user's memories
- `GET /api/v1/user/{id}/memories` - Specific user's memories

### Memories (authenticated)
- `GET /api/v1/memories` - List accessible memories
- `POST /api/v1/memories` - Create memory with initial content
- `GET /api/v1/memories/{memory}` - Get memory details
- `POST /api/v1/memories/{memory}` - Update memory (title + contents)
- `DELETE /api/v1/memories/{memory}` - Delete memory
- `POST /api/v1/memories/{memory}/cover-image` - Update cover image

### Memory Sharing (authenticated)
- `POST /api/v1/memories/{memory}/share` - Share memory with a friend (owner-only)
- `POST /api/v1/memories/{memory}/share/{user}` - Update share permission (owner-only)
- `DELETE /api/v1/memories/{memory}/share/{user}` - Revoke share (owner-only)

### Memory Privacy (authenticated)
- `PATCH /api/v1/memories/{memory}/personal` - Toggle personal flag (owner-only)

### Group Privacy (authenticated)
- `PATCH /api/v1/groups/{group}/personal` - Toggle personal flag (owner-only)

### Memory Content (authenticated)
- `POST /api/v1/memories/{memory}/contents` - Add content
- `DELETE /api/v1/memories/{memory}/contents/{content}` - Remove content
- `PATCH /api/v1/memories/{memory}/contents/{content}` - Update content
- `GET /api/v1/memories/content/{content}/stream` - Stream audio/video

### Groups (authenticated)
- `GET /api/v1/groups` - List user's groups
- `POST /api/v1/groups` - Create group
- `GET /api/v1/groups/{group}` - Get group details with memories
- `POST /api/v1/groups/{group}` - Update group (name, color)
- `DELETE /api/v1/groups/{group}` - Delete group
- `POST /api/v1/groups/{group}/memories/{memory}` - Add memory to group (owner of both)
- `DELETE /api/v1/groups/{group}/memories/{memory}` - Remove memory from group
- `POST /api/v1/groups/{group}/share` - Share group with a friend (owner-only)
- `POST /api/v1/groups/{group}/share/{user}` - Update group share permission (owner-only)
- `DELETE /api/v1/groups/{group}/share/{user}` - Revoke group share (owner-only)

### Tags (authenticated)
- `GET /api/v1/tags` - List user's tags
- `POST /api/v1/tags` - Create tag
- `GET /api/v1/tags/{tag}` - Get tag with related memories/groups
- `POST /api/v1/tags/{tag}` - Update tag name
- `DELETE /api/v1/tags/{tag}` - Delete tag
- `POST /api/v1/tags/{tag}/memories/{memory}` - Attach tag to memory
- `DELETE /api/v1/tags/{tag}/memories/{memory}` - Detach tag from memory
- `POST /api/v1/tags/{tag}/groups/{group}` - Attach tag to group
- `DELETE /api/v1/tags/{tag}/groups/{group}` - Detach tag from group

### Friends & Social (authenticated)
- `GET /api/v1/friends` - List accepted friends
- `DELETE /api/v1/friends/{friendship}` - Remove a friend
- `GET /api/v1/friends/requests` - List incoming pending requests
- `GET /api/v1/friends/requests/sent` - List outgoing pending requests
- `POST /api/v1/friends/request` - Send friend request
- `POST /api/v1/friends/requests/{friendship}/accept` - Accept request
- `POST /api/v1/friends/requests/{friendship}/decline` - Decline request
- `DELETE /api/v1/friends/requests/{friendship}` - Cancel sent request
- `GET /api/v1/friends/search?q=` - Search users by name (LIKE) or exact email
- `GET /api/v1/friends/invites` - List user's invite links
- `POST /api/v1/friends/invites` - Create invite link
- `DELETE /api/v1/friends/invites/{invite}` - Delete invite link
- `POST /api/v1/friends/invites/redeem` - Redeem invite code

### Notifications (authenticated)
- `GET /api/v1/notifications` - List notifications (paginated, with unread_count)
- `GET /api/v1/notifications/unread-count` - Get unread count (for badge)
- `PATCH /api/v1/notifications/{notification}/read` - Mark as read
- `POST /api/v1/notifications/read-all` - Mark all as read
- `DELETE /api/v1/notifications/{notification}` - Delete notification
- `GET /api/v1/notifications/settings` - Get notification preferences
- `POST /api/v1/notifications/settings` - Update notification preferences
- `POST /api/v1/notifications/device-token` - Register device token for push
- `DELETE /api/v1/notifications/device-token` - Remove device token

### Media Upload (unauthenticated, uses upload key)
- `POST /api/v1/memories/upload` - Upload file via upload key

---

## Frontend Features

- **Auth:** Login, register, biometric (fingerprint/face), forgot password
- **Memories:** Create/view/edit/delete memories with mixed content
- **Media:** Audio recording with waveform, image picker with auto-resize, audio/video playback
- **Groups:** Create/edit/delete color-coded groups, add/remove memories from groups
- **Tags:** Create/manage tags, attach to memories and groups, filter by tags
- **Search:** Inline search in memory list with debounced query (searches title, content, and tag names)
- **Filters:** Content type, date range, tag filters with sort options (date, title)
- **Offline:** Upload queue with exponential backoff retry, persistence across app restarts, connectivity-aware processing, native progress notifications
- **Theming:** Light/Dark/System + 6 color themes (Ocean, Forest, Sunset, Lavender, Ruby, Midnight)
- **Localization:** 8 languages (EN, DA, DE, ES, FR, JA, KO, ZH)
- **Friends:** Friends list, send/accept/decline/cancel requests, search users, invite links (create/copy/redeem), pending request badge
- **Privacy:** Mark memories/groups as personal (hidden by default), unlock via biometrics or 4-digit PIN, session-based locking, "Personal only" filter
- **State:** Provider + ChangeNotifier pattern

---

## Backend Features

- **Auth:** Sanctum token-based authentication
- **Media:** Two-step upload (create content -> get key -> upload file)
- **Images:** Auto thumbnail generation (300x300) via Intervention Image
- **Streaming:** Audio/video file streaming for authenticated users
- **Audit:** Full media upload history with IP logging
- **Content ordering:** Positional ordering of content within memories
- **Sharing:** Memory & group sharing with view/contribute permissions, friendship-gated, transitive group access
- **Authorization:** Permission-based access control on all memory endpoints (owner/contribute/view hierarchy)
- **Privacy:** `is_personal` flag on memories and groups, excluded from API responses by default, owner-only toggle endpoints

---

## Development Plan

> **How to use this plan:**
> - Each phase has numbered steps with a status checkbox
> - `[ ]` = not started, `[~]` = in progress, `[x]` = completed
> - When a step is completed, mark it `[x]` and note the date
> - When something changes during a step, add a note under it
> - If a step is skipped or modified, note why
> - New steps can be added at any time - insert them where logical
> - Features are brainstormed with the user, then promoted from the Backlog into numbered phases

### Phase 1: Project Foundation & Local Development Setup

**1A - Update frameworks to latest versions**

- [x] **1.1** Update Laravel to the latest version (currently ^11.0, check for 12.x) *(2026-02-09)*
  - Updated `laravel/framework` from `^11.0` to `^12.0` (installed v12.50.0)
  - Updated `phpunit/phpunit` from `^10.2` to `^11.0` (installed v11.5.52)
  - Ran `composer update` - 95 packages updated, 4 installed, 4 removed
  - Checked all Laravel 12 breaking changes: no impact on codebase
  - Backend starts and serves requests correctly on Laravel 12
- [x] **1.2** Update Flutter SDK and all dependencies to latest versions *(2026-02-09)*
  - Flutter already at latest stable 3.38.9 (Dart 3.10.8)
  - Ran `flutter pub upgrade --major-versions` - 94 dependencies upgraded
  - Major version bumps: audioplayers 5→6, record 5→6, local_auth 2→3, connectivity_plus 5→7, mime 1→2, flutter_lints 5→6
  - Fixed `intl` constraint from `^0.19.0` to `^0.20.2` (SDK pinned)
  - Fixed `connectivity_plus` 7.x breaking change: `checkConnectivity()` now returns `List<ConnectivityResult>`
  - Fixed localization imports: `flutter_gen/gen_l10n/` → `memory_lane_flutter/l10n/` (21 files)
  - Removed deprecated `synthetic-package` from l10n.yaml
  - `flutter analyze` passes with 0 errors (215 warnings/info are pre-existing code quality items)

**1B - Local development environment**

- [x] **1.3** Update backend README with clear local setup instructions *(2026-02-09)*
  - Rewrote README.md with prerequisites, step-by-step setup, and API docs section
- [x] **1.4** Configure frontend `api_config.dart` for local development *(2026-02-09)*
  - Set `developmentHost` to `127.0.0.1:8000`
  - `baseUrl` now uses `http://` for dev, `https://` for production
  - `useDevelopmentServer = true` is the default
  - SSL pinning only references production host; dev host bypasses via `isTrustedDomain()`
  - SSL pinning is config-only (not enforced in code), no `HttpOverrides`/`SecurityContext` found
- [x] **1.5** Verify end-to-end local flow works (backend serves, frontend connects, login works) *(2026-02-09)*
  - Backend serves at 127.0.0.1:8000, returns proper JSON for all endpoints
  - MySQL not available locally (no DB server) - API layer, routing, validation all work
  - Frontend analyzes cleanly (0 errors), api_config.dart points to local backend
  - Full E2E test requires running the app on a device/emulator (manual step)

**1C - Project cleanup**

- [x] **1.6** Review and clean up backend `.env.example` for new developer setup *(2026-02-09)*
  - Removed unused services (Pusher, AWS, Redis, Memcached, Vite, Mail)
  - Set APP_NAME to "Memory Lane", DB_DATABASE to "memory_lane", APP_URL to local server
- [x] **1.7** Review frontend `debug_config.dart` - ensure dev mode is toggleable cleanly *(2026-02-09)*
  - Already clean: single `isDevelopmentMode` boolean, used for conditional logging and debug UI
  - No changes needed
- [x] **1.8** Review and document any other hardcoded URLs or config in the frontend *(2026-02-09)*
  - All URLs centralized in `api_config.dart` - no hardcoded URLs elsewhere
  - No instances of domain names, localhost, or IP addresses outside config files

### Phase 2: Bug Fixes & Existing Feature Repair

> Fix everything that's broken before adding new features.

- [x] **2.1** Fix white bar at top of login screen *(2026-02-09)*
  - Root cause: Android system status bar had default white/translucent background; no AppBar to control it
  - Added `AnnotatedRegion<SystemUiOverlayStyle>` with transparent status bar to login screen
  - Fixed deprecated `colorScheme.background` → `colorScheme.surface` in login, register, forgot password, create memory screens
  - Fixed deprecated `colorScheme.onBackground` → `colorScheme.onSurface` in login screen
  - Fixed `local_auth` 3.x breaking change: replaced `AuthenticationOptions` with direct `persistAcrossBackgrounding`/`biometricOnly` params (login_screen + auth_service)
  - Updated `theme_config.dart`: replaced deprecated `background:` with `surface:` in ColorScheme
  - Removed unused imports (color_config, mime, http_parser)
- [x] **2.2** Fix language selector - instant change without restart *(2026-02-09)*
  - Root cause: `_loadLanguage()` was never called from constructor; `setLanguage()` didn't persist to SharedPreferences
  - Rewrote `LanguageProvider`: calls `_loadLanguage()` on init, persists with `setLanguage()`, defaults to system locale
  - Added "System default" as first option in language selector (shows resolved system language name)
  - Selection tile now compares raw `currentLanguageCode` instead of resolved locale (prevents double-highlighting)
  - `MaterialApp` rebuild via `Consumer2` was already correct - just needed proper `notifyListeners()` calls
- [x] **2.3** Fix audio recording waveform persistence *(2026-02-09)*
  - Root cause: `_maxWaveformPoints = 50` was declared but never enforced; waveform grew unbounded during recording
  - Added `RecordingData.downsample()` - takes max amplitude per segment for visual fidelity
  - Both `_saveRecording()` and `_handleDone()` now downsample to 50 points before returning data
  - Added error handling to `RecordingData.parseWaveform()` for empty/invalid strings
  - Full waveform still captured during recording for real-time display; downsampled only on save
- [x] **2.4** Fix audio playback in memory detail view *(2026-02-09)*
  - Root cause: `MemoryContentList` had "Audio playback coming soon..." placeholder instead of using `MemoryAudioPlayer`
  - Fixed `MemoryContent` model: renamed `source` → `streamUrl`, maps from backend's `stream_url` field
  - Rewrote `MemoryAudioPlayer`: supports both URL (remote) and local file playback via `UrlSource`/`DeviceFileSource`
  - Added auth token as query param for stream URLs (audioplayers can't send HTTP headers)
  - Backend: moved stream route outside auth middleware, added manual token auth via query param in `streamMedia()`
  - Wired `MemoryAudioPlayer` into `MemoryContentList` for audio content type
  - Added error state UI for failed audio loads
- [x] **2.5** Fix audio memory creation flow *(2026-02-09)*
  - Root cause: multiple bugs in the two-step upload flow
  - Backend: Fixed upload key length from 16 chars to 64 chars (`bin2hex(random_bytes(32))`)
  - Frontend: Added `uploadKey` field to `UploadItem` class - was being lost during queue processing
  - Frontend: Removed duplicate `_api.post('/memories/{id}/contents')` call in `_uploadAudio()` that created duplicate content records after upload
  - Frontend: Fixed silent error swallowing - `_uploadAudio()` caught all errors internally, so `processQueue()` always thought upload succeeded (deleting local file on failure)
  - Frontend: Added `_removePendingUpload()` to clean up SharedPreferences after successful upload
  - Frontend: Fixed `toJson()` missing file path (broke pause/resume serialization)
  - Removed unused code: `_memoryService`, `_api`, `_completeUpload()`, `_handleUploadError()`, and dead imports
- [x] **2.6** Fix memory list cut off at bottom *(2026-02-09)*
  - Added `extendBody: true` to HomeScreen Scaffold so body extends behind bottom nav bar
  - Added bottom padding (100px + safe area) to ListView so last item scrolls above nav bar
  - Updated CustomBottomNav to account for bottom safe area on devices with home indicators
  - Wrapped MemoryList in `SafeArea(bottom: false)` for proper status bar handling
- [x] **2.7** Code quality pass *(2026-02-09)*
  - Removed ~170 lines of dead code from `home_screen.dart` (unused methods, properties, imports from before MemoryList widget was extracted)
  - Consolidated duplicate `UploadStatus` enum and `UploadItem` class: removed stale copy from `upload_status.dart`, single source of truth in `upload_service.dart` (imports enum from model)
  - Replaced deprecated `WillPopScope` → `PopScope` with `canPop`/`onPopInvokedWithResult` in `create_memory_screen.dart`
  - Fixed all `withOpacity()` → `withValues(alpha:)` deprecation warnings across 13 files (~35 instances)
  - Removed duplicate `dart:math` import and unused imports (`image_picker`, `create_memory_modal`) from `create_memory_screen.dart`

### Phase 3: Complete & Polish Existing Features

> Finish features that are scaffolded but incomplete.

- [x] **3.1** Rewrite pending uploads system from scratch *(2026-02-10)*
  - **Architecture:** Single source of truth (SharedPreferences `pending_uploads_v2` key) with in-memory cache. Dropped redundant StreamController - uses only ChangeNotifier via Provider. All periodic timers eliminated.
  - **Unified model:** `PendingUpload` replaces both `UploadItem` and `PendingAudioUpload`. Fully JSON-serializable (`filePath` as String, not `File`). `contentType` field ('audio'/'image'/'video') ready for Step 3.4.
  - **Queue processing:** Sequential upload with real progress tracking (byte-level via stream wrapping). Connectivity-aware: subscribes to `connectivity_plus` stream for immediate recovery on reconnect.
  - **Retry:** Exponential backoff (2s→4s→8s→16s→32s, capped at 300s) with per-upload Timer. Max 5 auto-retries, then marked "failed" for manual retry. Manual retry resets count.
  - **Notifications:** Android MethodChannel wired in `MainActivity.kt` → `NotificationHelper.kt`. Progress bar in notifications, plus completion/failure notifications. Added `POST_NOTIFICATIONS` permission.
  - **UI:** New `UploadStatusBanner` widget on home screen (shows active upload progress or failed count with retry-all button). Simplified `PendingUploadsList` on profile screen (Consumer-only, no StreamBuilder/countdown).
  - **Cleanup:** Deleted dead files (`pending_audio_upload.dart`, `local_storage_service.dart`). Removed all orphaned `UploadService()` direct construction (memory_list, record_memory_screen). Removed all `checkPendingUploads()` calls (main, splash, login, profile). Legacy data migration from old SharedPreferences format.
  - **Localization:** 11 new upload-related keys added to all 8 language files.
  - `flutter analyze`: 0 errors (118 pre-existing warnings/info only)
- [x] **3.2** Complete memory list filters *(2026-02-10)*
  - **Backend:** Added `content_types` array to `MemoryListResource`. Added sort/order/content_type/search/from/to query params to both `/user/memories` and `/user/{id}/memories` endpoints.
  - **Frontend:** Added `contentTypes` field to Memory model. Updated `getUserMemories()` to accept optional `queryParams`. Enhanced `SortDialog` with title sort options (A-Z, Z-A) and current-selection checkmark. New `FilterBottomSheet` with content type chips (text/audio/image/video) and date range pickers. New `FilterState` class. Wired filter/sort state into `memory_list.dart` with badge indicator on filter button.
  - **Localization:** 12 new keys across all 8 languages.
  - `flutter analyze`: 0 errors (118 pre-existing warnings/info only)
  - **Deferred:** Group-based and shared/personal filters to Phases 4/5.
- [x] **3.3** Complete memory search *(2026-02-10)*
  - **Backend:** Extended search query param on both `/user/memories` endpoints to search title, legacy `content` field, and `memory_contents.text` using grouped `orWhere`/`orWhereHas`.
  - **Frontend:** Rewrote `SearchScreen` from stub to full implementation. Debounced search (400ms) with `TextField` + clear button. Three states: empty (search hint icon), loading (spinner), results (list with content type icons and date). `_SearchResultItem` shows cover thumbnail, title, content type icons, date, and contributor avatar.
  - **Wiring:** Replaced `Center(child: Text('Search'))` placeholder in `HomeScreen` with `SearchScreen` widget.
  - **Localization:** 3 new keys (`searchMemories`, `searchHint`, `noSearchResults`) across all 8 languages.
  - `flutter analyze`: 0 errors (118 pre-existing warnings/info only)
- [x] **3.4** Add image and video capture/upload as memory content *(2026-02-10)*
  - **Backend:** Migration adds `thumbnail` column to `memory_contents`. Opened gates in `MemoryContent.php` (`getUploadKeyAttribute`, `getStreamUrlAttribute`) to include `'image'`. Added `image_url` and `thumbnail_url` accessors. `uploadMediaFile()` stores images on public disk with auto-generated 300x300 thumbnails via ImageUpload trait. `streamMedia()` uses correct disk per content type. `addContent()` creates pending uploads for image content. Updated `MemoryResource.php` and `MemoryContentResource.php` with `image_url`, `thumbnail_url` fields and extended `upload_key` to images.
  - **Frontend:** Added `video_player: ^2.9.2` dependency. Updated `MemoryContent` model with `imageUrl`/`thumbnailUrl` fields. Added `pickVideo()` to `ImageHelper` (camera/gallery bottom sheet, 10min max). Extended `AddContentModal` and `CreateMemoryModal` from 2 to 4 options (text, audio, image, video) using `Wrap` layout. Added `initialMediaPath` to `MemoryContentEditor`. Added `_addImageContent`/`_addVideoContent` methods and wired into `_showAddContentModal`. `_saveMemory()` includes image/video in contents JSON and upload queue. Image preview (`Image.file`) and video placeholder in editor widget. New `MemoryVideoPlayer` widget with `VideoPlayerController.networkUrl`, play/pause overlay, progress indicator, token auth. `MemoryContentList` displays images (with full-screen `InteractiveViewer` on tap) and videos (with `MemoryVideoPlayer`). Uploading placeholders for pending media.
  - **Localization:** 5 new keys (`recordVideo`, `chooseVideoFromGallery`, `imageUploading`, `videoUploading`, `unableToLoadVideo`) across all 8 languages.
  - `flutter analyze`: 0 errors (118 pre-existing warnings/info only)

### Phase 4: Memory Groups

> New organizational system. Groups are optional - memories can exist ungrouped.

- [x] **4.1** Backend: Create groups system *(2026-02-09)*
  - `groups` table (id, name, color, user_id, timestamps)
  - `group_memory` pivot table (group_id, memory_id)
  - `group_user` pivot table for shared groups (group_id, user_id, permission_level)
  - API endpoints: CRUD for groups, add/remove memories from groups
  - 7 endpoints: GET/POST /groups, GET/POST/DELETE /groups/{id}, POST/DELETE /groups/{id}/memories/{id}
  - GroupController with owner-only auth for mutations, canAccessGroup for shared users
  - GroupResource/GroupListResource, StoreGroupRequest/UpdateGroupRequest
  - MemoryListResource/MemoryResource updated with groups field
  - Eager loading added to MemoryController::index and user.php routes
- [x] **4.1.1** Frontend: Upgrade Kotlin version to 2.1.0+ *(2026-02-11)*
  - Flutter warns that Kotlin 1.9.0 support will be dropped soon
  - Updated `android/settings.gradle.kts` plugin from 1.8.22 → 2.1.0
  - Updated `android/build.gradle` ext.kotlin_version from 1.9.0 → 2.1.0
  - flutter analyze passes (0 errors)
- [x] **4.2** Frontend: Groups UI *(2026-02-11)*
  - Replaced Search tab (index 1) with Groups tab (folder icon)
  - `Group` model + `GroupService` (7 API methods matching backend)
  - `GroupsScreen`: 2-column grid of colored group cards, create/edit bottom sheet with 12-color palette
  - `GroupDetailScreen`: group detail with memory list, add/remove memories, edit/delete group
  - Localization: 20 new keys across all 8 .arb files (en, da, de, es, fr, ja, ko, zh)
  - flutter analyze: 0 errors
**4C - Bug Fixes (discovered during Phase 4 testing)**

- [x] **4.2.1** Fix filter toggle disappearing when no results found *(2026-02-11)*
  - Root cause: `memory_list.dart` returned early with just "no memories" text when list was empty, hiding the header with filter/sort buttons
  - Fixed by restructuring: header with buttons always renders, empty state moved into the `Expanded` content area as a ternary
- [x] **4.2.2** Fix bottom bar overlapping settings page content *(2026-02-11)*
  - Root cause: `settings_screen.dart` used `EdgeInsets.all(16.0)` with no extra bottom padding for nav bar
  - Fixed by adding `bottom: 100.0 + MediaQuery.of(context).padding.bottom` to padding
- [x] **4.2.3** Fix save button visibility when editing existing memory content *(2026-02-11)*
  - Root cause: `_loadExistingContent()` in `create_memory_screen.dart` set `_hasChanges = true` without `setState()`, so widget never rebuilt to show the conditional save button
  - Fixed: wrapped in `setState(() => _hasChanges = true)`, also added `onChanged` handler to title `TextFormField`
- [x] **4.2.4** Fix "Failed to update memory: 405" error *(2026-02-11)*
  - Root cause: Frontend sent `_method=PUT` in form data, but backend route is `Route::post('memories/{memory}', ...)`. Laravel's method spoofing converted the request to PUT, but no PUT route exists
  - Fixed by removing `request.fields['_method'] = 'PUT'` from both `saveMemory()` and `updateMemory()` in `memory_service.dart`
- [x] **4.2.5** Add missing translations across all languages *(2026-02-11)*
  - Audited all keys in `app_en.arb` against all 7 other locale files
  - DA: added 62 missing keys, DE: added 51 missing keys, ES/FR/JA/KO/ZH: each added 36 missing keys
  - Fixed `flutter gen-l10n` type conflict: removed `@byAuthor`/`@dateFormat` metadata from non-template locale files (DA, DE had `"type": "String"` conflicting with template's `"Object"`)
  - All 8 languages now have complete translations for all keys

- [x] **4.3** Group colors *(2026-02-11)*
  - ~~Color picker when creating/editing a group~~ Done in 4.2: 12-color palette in create/edit dialog
  - ~~Color affects group icon, accent, and text in the group overview~~ Done in 4.2: colored header bar + dot on cards
  - Memory list items in GroupDetailScreen now carry the group color: left accent border, tinted avatar background, colored fallback icons, tinted empty state icon
- [x] **4.4** Move search into the memory list screen *(2026-02-11)*
  - Added search icon button next to "Memories" title in memory list header
  - Tapping search icon expands an inline search field (replaces title), with debounced search (400ms)
  - Search query passed as `search` param to backend API alongside existing sort/filter params
  - Empty state adapts: shows "no search results" icon when searching vs generic "no memories" otherwise
  - Clear button in search field resets results; close icon collapses back to title
  - Deleted standalone `search_screen.dart` (no longer referenced since Groups replaced Search tab in 4.2)
- [x] **4.5** Tags for groups and memories
  - Backend: `tags` table + `taggables` polymorphic pivot (migration `2026_02_11_200000_create_tags_table.php`)
  - `Tag` model with `morphedByMany` relationships to Memory and Group
  - `TagController` with full CRUD + `addToMemory`/`removeFromMemory`/`addToGroup`/`removeFromGroup`
  - `StoreTagRequest`/`UpdateTagRequest` validation (unique per user, max 50 chars)
  - `TagListResource`/`TagResource` for API responses
  - Routes in `routes/endpoints/tag.php` (CRUD + association endpoints)
  - Updated `MemoryListResource`, `MemoryResource`, `GroupResource`, `GroupListResource` to include tags
  - Updated `user.php` search to include tag names (`orWhereHas tags`), added `tag` query param filter
  - Eager-loaded tags in `GroupController` and `MemoryController`
  - Frontend: `Tag` model, `TagService` (CRUD + associations)
  - Updated `Memory` and `Group` models with `List<Tag> tags` field
  - `TagPickerModal` widget: reusable bottom sheet with FilterChip toggles and inline tag creation
  - Tags display as compact Chips on memory detail screen (between author and content) and group detail screen (below app bar)
  - Only visible when tags exist - "+" ActionChip opens picker to add tags
  - Tag filter integrated into `FilterBottomSheet` via `FilterState.tagIds`
  - `memory_list.dart` passes `tag` query param when tag filter is active
  - Localization: 16 new keys across all 8 languages (en, da, de, es, fr, ja, ko, zh)
- [x] **4.5.1** Fix memory save bug *(2026-02-11)*
  - Root cause: Two-sided issue — backend `update()` only processed `title` and `cover_image`, completely ignoring content changes; frontend sent `content` (singular string via MultipartRequest) but backend expected `contents` (plural array)
  - Backend fix: `MemoryController@update` now processes `contents` — deletes old contents/order/pending uploads, creates new ones with proper order and upload keys, wrapped in DB transaction. Returns `upload_keys` in response. `StoreMemoryRequest` now validates `contents` for updates (`sometimes|array`). Added `prepareForValidation()` to decode JSON string contents before validation.
  - Frontend fix: `updateMemory()` in `memory_service.dart` now sends JSON POST with `contents` (decoded array) when no cover image, or MultipartRequest with `contents` field when cover image is present. Fixed duplicate cover image upload (was uploading via both `updateMemory()` and separate `updateMemoryCoverImage()` call). Removed debug `print` statements from `create_memory_screen.dart`.

### Phase 5: Friends & Social

> Friends system, sharing, and permissions.

- [x] **5.1** Backend: Friends system *(2026-02-13)*
  - `friendships` table (user_id, friend_id, status enum pending/accepted, unique constraint, cascade deletes)
  - `friend_invites` table (code string 16 unique, used_by FK nullable, expires_at nullable)
  - `Friendship` model with requester/recipient BelongsTo relationships
  - `FriendInvite` model with isUsed()/isExpired()/isValid() helpers, creator/usedByUser relationships
  - `User` model updated: sentFriendRequests(), receivedFriendRequests(), friendInvites() HasMany
  - `FriendController` with 13 endpoints: list friends, remove friend, pending/sent requests, send/accept/decline/cancel request, user search, invite CRUD, redeem invite
  - User search: name uses LIKE (partial), email uses exact match (privacy), response never exposes email
  - Edge cases: self-friending rejected (422), duplicate requests detected both directions, reverse pending request auto-accepts, invite self-use rejected (422), expired/used invites return 410, already-friends returns 409, invite redeem wrapped in DB::transaction
  - 4 API resources: FriendListResource, FriendshipResource, FriendInviteResource, UserSearchResource
  - 2 form requests: SendFriendRequestRequest, SearchUsersRequest
  - Routes in `routes/endpoints/friend.php` (literal paths before parameterized to avoid capture conflicts)
  - Email invites deferred (no email service configured) — invite links shareable via copy/paste
- [x] **5.2** Frontend: Friends UI *(2026-02-13)*
  - Friends button on profile screen with Badge showing pending request count
  - `FriendsScreen` with 4-tab TabBar: Friends list, Requests, Search, Invites
  - `Friend` model + 5 related models (`FriendshipUser`, `Friendship`, `UserSearchResult`, `FriendInvite`, `InviteUsedBy`)
  - `FriendService` with 13 API methods matching all backend endpoints
  - Friends list tab: pull-to-refresh, remove friend with confirmation
  - Requests tab: incoming (accept/decline) + sent (cancel) sections with confirmations
  - Search tab: debounced user search (500ms, min 2 chars), send request with auto-accept detection
  - Invites tab: create/delete invite links, copy to clipboard, redeem invite codes
  - Reusable `FriendTile` widget across all tabs
  - Backend fix: `FriendController@index()` now passes `friendship_id` through to `FriendListResource`
  - Localization: 38 new keys across all 8 languages
- [x] **5.3** Backend: Memory & group sharing with permissions *(2026-02-14)*
  - Migration: added `permission` column to `memory_user` pivot (owner/contribute/view, default 'owner')
  - `ChecksFriendship` trait for reusable bidirectional friendship checks
  - Memory model: `owner()`, `userPermission()`, `canAccess()`, `effectivePermission()` helpers
  - User model: updated `memories()` pivot, added `sharedMemories()` relationship
  - **Authorization fixed on ALL MemoryController endpoints** (index, show, store, update, destroy, updateCoverImage, addContent, streamMedia) — previously most had NO access checks
  - Permission-aware `canModifyContent()` in MemoryContentManagement trait
  - 3 memory sharing endpoints: share, update permission, revoke (owner-only, friends-only)
  - 3 group sharing endpoints: share, update permission, revoke (owner-only, friends-only)
  - `addMemory()` in GroupController now requires memory ownership (not just access)
  - API Resources: `permission` field in users, `is_shared` flag in MemoryListResource
  - `GET /user/memories` now includes group-shared memories (not just direct pivot)
  - 4 Form Request classes, 6 new routes total
- [x] **5.4** Frontend: Sharing & permissions UI *(2026-02-14)*
  - Invite friends to a memory (choose permission: view or contribute)
  - Invite friends to a group (same permission model)
  - Shared memories appear in main list with a "shared" indicator, filterable
  - Also accessible through a "Shared with me" filter/section
  - New widgets: `ShareWithModal`, `ManageSharesSection` in `lib/widgets/sharing/`
  - Models updated: `Memory.isShared`, `User.permission`, `Group.sharedUsers`/`GroupSharedUser`
  - Services updated: 3 sharing methods each for `MemoryService` and `GroupService`
  - Permission-based UI: edit/delete hidden for view-only users, share button owner-only
  - 15 new l10n keys across all 8 languages
- [x] **5.5** Group memory contributions *(completed 2026-02-14)*
  - When invited to a group with "contribute" permission, users can add their own memories to that group
  - Contributed memories appear alongside the group owner's memories in the list/timeline
  - Contributors can also add content (text, audio, images) to existing memories they have contribute access to
  - Backend: `GroupController::addMemory()` updated to allow contributors (not just owners)
  - Frontend: Permission-aware GroupDetailScreen — FAB/edit/delete visibility based on role
  - Frontend: "Add Memory" dialog now offers two options: add existing or create new memory
  - `CreateMemoryScreen` accepts optional `groupId` to auto-add new memory to group
  - 2 new l10n keys (`addExistingMemory`, `createNewMemory`) across all 8 languages
- [x] **5.6** Content requests *(completed 2026-02-14)*
  - Create a "request" directed at a specific user (must have account)
  - Or generate a one-time shareable link (recipient must log in or register)
  - Request owner defines what's needed (spoken, written, photo, video)
  - One-click copy link, shareable via Messenger, email, etc.
  - Recipient sees the request and can contribute directly
  - Backend: `content_requests` table, `ContentRequest` model, `ContentRequestController` (6 endpoints), resource, form request, routes
  - Frontend: `ContentRequest` model, `ContentRequestService`, `ContentRequestsSheet` + `CreateContentRequestSheet` widgets, `FulfillRequestScreen`, "Redeem Content Request" on profile
  - 21 new l10n keys across all 8 languages

### Phase 6: Personal / Hidden Memories

> Privacy layer for sensitive content.

- [x] **6.1** Backend: Personal flag on memories and groups *(2026-02-15)*
  - Migration adds `is_personal` boolean (default false) to `memories` and `groups` tables
  - `include_personal` query param on index endpoints — personal items excluded by default, included when `?include_personal=1`
  - `PATCH /memories/{id}/personal` and `PATCH /groups/{id}/personal` toggle endpoints (owner-only)
  - Updated all 4 API resources (MemoryResource, MemoryListResource, GroupResource, GroupListResource) with `is_personal` field
- [x] **6.2** Frontend: Personal memory flow *(2026-02-15)*
  - "Mark as Personal" / "Unmark as Personal" option in memory detail and group detail menus (owner-only)
  - Checks for security setup (PIN or biometrics) before allowing marking — prompts `setupSecurityFirst` if none configured
  - Confirmation dialog before marking as personal
  - `PrivacyProvider` (ChangeNotifier) manages unlock state and PIN via `flutter_secure_storage`
  - `PinDialog` widget for setting, changing, and verifying 4-digit PIN
  - Models updated: `Memory.isPersonal` and `Group.isPersonal` fields
  - Services updated: `togglePersonal()` methods on both `MemoryService` and `GroupService`
- [x] **6.3** Frontend: Unlock flow *(2026-02-15)*
  - Privacy section on profile screen: unlock/lock button + PIN setup/change
  - Unlock tries biometrics first (via existing `AuthService.verifyBiometrics()`), falls back to PIN dialog
  - Once unlocked, `include_personal=1` passed to API — personal items appear with lock icon indicator
  - "Personal only" filter chip in FilterBottomSheet (visible only when unlocked)
  - Client-side `showPersonalOnly` filtering in memory list
  - Groups screen passes `includePersonal` to `GroupService.getGroups()`
  - Session-based: items re-hide when app closes or user taps "Lock Personal"
  - 21 new l10n keys across all 8 languages

### Phase 7: Notifications

> Push notifications to the device.

- [x] **7.1** Backend: Notification system *(2026-02-16)*
  - `notifications` table (id, user_id FK, type, title, message, data JSON, read_at, timestamps) with indexes on user_id+read_at, user_id+created_at, type
  - `device_tokens` table (id, user_id FK, token unique, platform, timestamps) for future FCM/APNs push
  - `AppNotification` model with `notify()` static factory, `markAsRead()`, type constants for 7 notification types
  - `DeviceToken` model for push notification token storage
  - `NotificationController` with 7 endpoints: list (paginated + unread_count), unread-count, mark-as-read, mark-all-as-read, delete, register-device-token, remove-device-token
  - `NotificationResource` / `NotificationListResource` API resources
  - `CreatesNotifications` trait with helper methods for each notification type
  - Routes in `routes/endpoints/notification.php`, registered in `api.php`
  - Route model binding for `{notification}` → `AppNotification` in RouteServiceProvider
  - Notification creation wired into existing controllers:
    - `FriendController`: friend request sent, accepted (including auto-accept), invite redeemed
    - `MemoryController`: memory shared
    - `GroupController`: group shared
    - `ContentRequestController`: directed content request created, content request fulfilled
  - Notification types: `friend_request`, `friend_accepted`, `invite_redeemed`, `memory_shared`, `group_shared`, `content_request`, `content_request_fulfilled`
- [x] **7.2** Frontend: In-app notification UI *(2026-02-16)*
  - `AppNotification` model with type constants and `NotificationResponse` for pagination
  - `AppNotificationService` with 7 methods: getNotifications (paginated), getUnreadCount, markAsRead, markAllAsRead, deleteNotification, registerDeviceToken, removeDeviceToken
  - `NotificationsScreen`: paginated list with pull-to-refresh, infinite scroll, swipe-to-delete, unread dot indicator, relative time display, type-specific icons/colors
  - Notification tap navigation: friend types → FriendsScreen, memory types → MemoryDetailScreen, group types → GroupDetailScreen
  - Profile screen: notification bell icon in AppBar with Badge showing unread count, refreshes count on return from notifications screen
  - 3 new l10n keys (`notifications`, `noNotifications`, `markAllRead`) across all 8 languages
  - Push notifications (FCM/APNs) deferred — device token registration API is ready, FCM setup requires Firebase project configuration
- [x] **7.3** Frontend: Notification settings *(2026-02-16)*
  - Backend: Migration adds `notification_preferences` JSON column to `users` table
  - Backend: `User` model gains `isNotificationEnabled()` and `isNotificationQuiet()` helpers
  - Backend: `AppNotification::notify()` now checks user preferences before creating — disabled types are silently skipped
  - Backend: `GET/POST /notifications/settings` endpoints for reading/updating preferences with defaults
  - Frontend: `NotificationPreferences` and `NotificationTypePreference` models
  - Frontend: `getSettings()` and `updateSettings()` methods on `AppNotificationService`
  - Frontend: `NotificationSettings` widget in settings screen — global toggle, per-type enable/disable switches, per-type quiet mode FilterChip
  - Optimistic UI updates with rollback on failure
  - 10 new l10n keys (`notificationSettings`, `notificationsEnabled`, `quietMode`, `friendRequests`, `friendAccepted`, `inviteRedeemed`, `memoryShared`, `groupShared`, `contentRequests`, `contentRequestFulfilled`) across all 8 languages

### Phase 8: Backend Infrastructure

- [x] **8.1** Add API URL versioning (`/api/v1/...`) *(2026-02-16)*
  - Changed route prefix from `api` to `api/v1` in `RouteServiceProvider`
  - Updated frontend `ApiConfig.baseUrl` to include `/v1`
  - Updated hardcoded stream URL in `MemoryContent::getStreamUrlAttribute()`
  - Updated documentation comment URLs in `routes/endpoints/memory.php`
  - All 78 routes now under `/api/v1/` — future versions can add `/api/v2/` without breaking v1
- [x] **8.2** Admin panel *(2026-02-16)*
  - Installed Filament v3 admin panel framework at `/admin`
  - Migration: `is_admin` + `is_banned` on users, `is_flagged` on memories
  - User model implements `FilamentUser` — only `is_admin` users can access panel
  - Ban check in `AuthController::loginUser()` — banned users get 403
  - **UserResource**: list/edit users, search, ban/unban toggle, reset password, admin toggle
  - **MemoryResource**: list/view memories, search by title/owner, flag/unflag, delete
  - **Dashboard widgets**: StatsOverview (users, memories, storage, flagged), ContentTypeChart (doughnut), UserGrowthChart (30-day line)
  - Panel at `/admin/login` with Filament's built-in auth

### Phase 9: External Storage Providers

> Allow users to choose where their memory files are stored.

**9A - Storage provider architecture**

- [x] **9.1** Backend: Storage provider abstraction layer *(2026-02-16)*
  - `StorageProviderInterface` with 13 methods: store, storeUploadedFile, retrieve, readStream, delete, exists, move, url, size, mimeType, makeDirectory, listDirectory, testConnection
  - `BaseStorageProvider` abstract class with path normalization, validation, directory traversal prevention
  - `LocalStorageProvider` wraps Laravel filesystem (public + local disks, auto-resolves disk by path)
  - `StorageManager` singleton: resolves provider per user, caches instances, supports provider registration
  - `user_storage_settings` migration: user_id (unique), provider_type, config (encrypted JSON), is_active
  - `UserStorageSetting` model with encrypted config cast, `storageSetting` HasOne on User
- [x] **9.2** Backend: Mapping file system for file-based providers *(2026-02-16)*
  - `StorageManifest` class manages `memory_lane_manifest.json` at storage root
  - Manifest structure: version, app name, updated_at, files map (path → memory_id, content_id, type, size, checksum, created_at)
  - Atomic writes: write to `.tmp` then move/rename
  - `DO_NOT_ALTER_THESE_FILES.txt` warning file generated via `createWarningFile()`
  - `verify()` method: detects missing files (in manifest, not on disk) and orphaned files (on disk, not in manifest)
  - Helper methods: `addFile()`, `removeFile()`, `filesForMemory()`, `allPaths()`, `getFileInfo()`
- [x] **9.3** Backend: Local/server storage provider (refactor current system) *(2026-02-16)*
  - `ResolvesStorage` trait: resolves provider per memory (owner's storage) or per user
  - `MemoryController` uses `ResolvesStorage` for critical paths: `uploadMediaFile()`, `streamMedia()`, `update()` file cleanup
  - `LocalStorageProvider` wraps existing `Storage::disk()` calls — identical behavior for default users
  - Model accessors kept as-is (URL generation unchanged for local storage)
  - No migration needed — existing users automatically use `LocalStorageProvider`

**9B - Individual storage providers**

- [x] **9.4** Backend + Frontend: Dropbox integration _(2026-02-16)_
  - `DropboxStorageProvider` using `spatie/flysystem-dropbox` — full interface impl with root folder prefixing
  - `DropboxOAuthController` — authorization URL generation, code-for-token exchange, token refresh
  - `StorageSettingsController` — CRUD for storage settings, connection test, disconnect, available providers
  - `config/services.php` Dropbox config from `DROPBOX_APP_KEY`/`DROPBOX_APP_SECRET` env vars
  - 7 new API routes: `GET/PUT/DELETE storage/settings`, `POST storage/settings/test`, `GET storage/providers`, `GET storage/dropbox/authorize`, `POST storage/dropbox/callback`
  - Frontend: `StorageService`, `StorageProvider` (ChangeNotifier), `StorageSettings` widget in settings screen
  - OAuth flow: open Dropbox auth in browser → user pastes code → backend exchanges for tokens → stored encrypted
  - 17 new l10n keys across 8 languages
- [x] **9.5** Backend + Frontend: FTP / sFTP / FTPS integration _(2026-02-16)_
  - `FtpStorageProvider` using `league/flysystem-ftp` + `league/flysystem-sftp-v3` — supports FTP, FTPS, SFTP
  - Protocol-aware adapter creation: FTP/FTPS via `FtpAdapter`, SFTP via `SftpAdapter` with password or private key
  - `FtpConnectionController` — validates connection before saving, supports all 3 protocols
  - 1 new API route: `POST storage/ftp/connect`
  - Frontend: `connectFtp()` in service/provider, FTP connection dialog with protocol selector (SegmentedButton), host/port/username/password/root folder fields, auto-port (21 for FTP, 22 for SFTP)
  - 7 new l10n keys across 8 languages
- [x] **9.6** Backend + Frontend: SMB network drive integration _(2026-02-16)_
  - `SmbStorageProvider` using `icewind/smb` + `jerodev/flysystem-v3-smb-adapter`
  - `SmbConnectionController` — validates connection before saving (server, share, credentials, domain)
  - 1 new API route: `POST storage/smb/connect`
  - Frontend: `connectSmb()` in service/provider, SMB connection dialog with server/share/username/password/domain/root folder fields
  - **LAN-only warning** in connect dialog: "SMB is only available on local networks. Use VPN for remote access."
  - 6 new l10n keys across 8 languages
- [x] **9.7** Frontend: Storage settings UI _(2026-02-16)_
  - "Storage Provider" section in settings screen with current provider display (icon + label + status)
  - Provider connection buttons: Dropbox (OAuth), FTP/SFTP (connection form), SMB (connection form with LAN warning)
  - Connection test button for connected providers, disconnect with confirmation dialog
  - `StorageProvider` (ChangeNotifier) registered in `main.dart`, loaded on settings screen init
  - _Deferred: folder browser (tree-view navigation), thumbnail caching, first-launch provider choice_

**9C - Contributor upload routing**

**9D - Migration Wizard (separate phase from initial setup)**

- [x] **9.8** Frontend + Backend: Storage migration wizard _(2026-02-16)_
  - **Backend:** `StorageMigration` model with `file_manifest` (JSON), `source_config`/`target_config` (encrypted). `StorageMigrationController` with 7 endpoints: status, start (enumerates files from DB), process (batch copy with size verification), complete (switches provider setting), rollback (deletes from target), cancel, cleanup (deletes from old source). Source config stored in migration record for post-switch access.
  - **Frontend:** `MigrationStatus` + `MigrationBatchResult` models in `StorageService`. `StorageProvider` gains `runMigration()` (batch loop with progress callback), `startMigration()`, `completeMigration()`, `rollbackMigration()`, `cancelMigration()`, `cleanupMigration()`.
  - **UI:** `StorageMigrationWizard` — full-screen stepper (select → configure → confirm → migrate → done). Step indicator, provider config forms (reuses FTP/SMB/Dropbox patterns), live progress bar with file count + byte count, rollback on error, optional source cleanup after success. "Migrate Storage" button added to storage settings when connected.
  - **Localization:** 27 new keys across all 8 languages.
  - **Migration:** `2026_02_16_140000_create_storage_migrations_table` — tracks user, source/target types + configs, status, file manifest, progress counters.
  - _Deferred: resume after app close (would need background isolate + push notification), checksum verification (using size comparison instead)_

**9E - Contributor upload routing**

- [x] **9.9** Backend: Contributor upload proxy _(2026-02-16)_
  - Already implemented via `ResolvesStorage` trait: `storageForMemory()` resolves by memory **owner**, not uploader
  - `uploadMediaFile()` uses `$this->storageForMemory($memory)` → files always go to owner's storage
  - Server acts as relay: contributor uploads to API → API pushes to owner's storage provider
  - _Deferred: queue-based retry for unavailable storage, storage-full notifications_

### Phase 10: Payment & Business Model Baseline

> Prepare the codebase for a tiered access system. During development, all users are "premium for life" so nothing is limited. But the infrastructure must be in place so limits can be flipped on when the business model is ready.

- [x] **10.1** Backend: User tier system _(2026-02-16)_
  - `user_tiers` table: id, slug, name, `storage_limit_bytes` (0=unlimited), `memory_limit` (0=unlimited), `contributors_per_memory` (0=unlimited), `features` (JSON), `is_default`, `sort_order`
  - Added `tier_id` FK to `users` table (nullable, constrained with nullOnDelete)
  - `UserTier` model with `hasFeature()`, `hasUnlimitedStorage()`, `hasUnlimitedMemories()`, `default()` static
  - `User::tier()` relationship + `effectiveTier()` helper (falls back to default or in-memory premium)
  - `UserTierSeeder`: "free" tier (500MB, 50 memories, 3 contributors) and "premium" tier (unlimited everything, is_default=true)
  - Filament `UserResource` updated: tier selector in form, tier badge column in table
  - User `show` endpoint now eager-loads tier relationship
- [x] **10.2** Backend: Feature gating system _(completed 2026-02-16)_
  - Feature gate methods on User model: `canUse($feature)`, `canCreateMemory()`, `hasStorageSpace($bytes)`, `canAddContributor($memory)`, `tierInfo()`
  - `CheckTierFeature` middleware for route-level gating; registered as `tier.feature` alias in Kernel
  - Applied `tier.feature:external_storage` to Dropbox authorize/callback, FTP connect, SMB connect routes
  - Memory creation gating in `MemoryController::store()` — 403 with `limit_reached` type when limit hit
  - Contributor gating in `MemoryController::shareMemory()` — 403 when contributor limit reached
  - `GET /user/tier` endpoint returning tier info (slug, name, limits, usage, features)
  - All gates return `true` during development (premium tier is default, unlimited everything)
- [x] **10.3** Frontend: Limit awareness UI _(completed 2026-02-16)_
  - `TierInfo` model in `user_service.dart` with progress helpers and feature checks
  - `UserProvider` extended with `loadTierInfo()` fetching `GET /user/tier`
  - `TierInfoSettings` widget in settings screen: tier badge, storage/memory usage bars with progress indicators, contributor limit display, feature chip list
  - `LimitReachedException` in `exceptions.dart`; `createMemory()` and `shareMemory()` throw it on 403 `limit_reached` responses
  - 14 new l10n keys across 8 languages (yourPlan, storageUsage, memoriesUsage, contributorsPerMemory, unlimited, tierInfoUnavailable, includedFeatures, featureGroups, featureExternalStorage, featureEncryption, featureTimePeriods, limitReachedMemories/Contributors/Storage)
  - During development: premium tier shows unlimited everything
- [x] **10.4** Backend: Usage tracking _(completed 2026-02-16)_
  - Migration adds `storage_used_bytes` to `users` table, `file_size` to `memory_contents` table
  - `MemoryContent.file_size` fillable; set on upload in `uploadMediaFile()`
  - `User.incrementStorageUsed()` / `decrementStorageUsed()` / `recalculateStorageUsed()` methods
  - Upload increments owner storage, content delete decrements, memory delete sums and decrements
  - `php artisan storage:recalculate` command with optional `--user=` flag for backfill
  - Memory count tracked via live query in `tierInfo()` (no denormalized counter needed)
  - Deferred: feature usage analytics, admin dashboard stats (future admin phase)
- [x] **10.5** Payment integration (future - placeholder) _(noted 2026-02-16)_
  - Payment provider TBD (Stripe, RevenueCat, etc.)
  - In-app purchase for mobile (App Store / Google Play)
  - Subscription management (upgrade, downgrade, cancel)
  - **Not implemented now** — tier system is flexible enough: `user_tiers` table with slug, limits, features JSON; `tier_id` FK on users; seedable tiers; middleware gating. Payment integration can add a `subscription` table linking to tier and manage transitions.

### Phase 11: Memory Dating & Time Periods

> Flexible temporal placement for memories. Memories are often about the past, and recollections are rarely precise — the system must embrace that. Logically follows Phase 4 (groups) as another organizational axis. Prerequisite for the Timeline view (backlog).

- [x] **11.1** Backend: Flexible memory date model _(completed 2026-02-16)_
  - Migration adds `memory_date_start` (date, nullable), `memory_date_end` (date, nullable), `date_precision` (enum: day/month/year/range, nullable) to `memories` table with composite index
  - `Memory` model: fillable + date casts + `getFormattedDateAttribute()` accessor (adapts display per precision)
  - `StoreMemoryRequest` updated: validates `date_precision`, `memory_date_start`, `memory_date_end` (nullable for now; required when frontend adds picker)
  - `MemoryResource` + `MemoryListResource` include `memory_date_start`, `memory_date_end`, `date_precision`, `formatted_date`
  - `MemoryController::store()` + `update()` save date fields (owner-only for updates)
- [x] **11.2** Backend: Time periods _(completed 2026-02-16)_
  - `time_periods` table: id, user_id, name, start_date, end_date, color (hex, nullable), timestamps. Composite index on (user_id, start_date, end_date)
  - `TimePeriod` model with user relationship, date casts
  - `TimePeriodController` with full CRUD (index, store, show, update, destroy) + ownership checks
  - `User::timePeriods()` HasMany relationship
  - 5 routes registered under `time-periods` prefix in `api.php`
- [x] **11.3** Frontend: Memory date picker _(completed 2026-02-16)_
  - `TimePeriod` model + `TimePeriodService` (CRUD matching backend API)
  - `Memory` model extended with `memoryDateStart`, `memoryDateEnd`, `datePrecision`, `formattedDate`
  - `MemoryService.createMemory()` + `updateMemory()` send date fields to backend
  - `MemoryDatePicker` widget: precision selector chips (Exact/Month/Year/Range), date pickers per precision, year picker dialog, time period quick-pick chips
  - Integrated into `CreateMemoryScreen`: loads time periods, pre-populates when editing, passes date fields on save
  - Memory detail screen + memory list show `formattedDate` when available (falls back to `createdAt`)
  - 9 new l10n keys across 8 languages
- [x] **11.4** Frontend: Time periods management _(completed 2026-02-16)_
  - `TimePeriodSettings` widget in settings screen: list with color avatars, date ranges, edit/delete popup menu
  - Create/edit bottom sheet form: name, start/end date pickers (auto-adjust end if before start), 12-color palette
  - Delete with confirmation dialog + snackbar feedback
  - 12 new l10n keys across 8 languages
- [x] **11.5** Backend + Frontend: Date-based filtering _(completed 2026-02-16)_
  - Backend (`user.php`): Added `memory_date` sort using `COALESCE(memory_date_start, created_at)`, date range filtering adapted to `memory_date_start`/`memory_date_end` with `created_at` fallback, `time_period` query param with overlap detection
  - Frontend: Added `memoryDateNewest`/`memoryDateOldest` sort options, `timePeriodId` in `FilterState`, time period filter chips in `FilterBottomSheet` (loads from API, clears date range on select), `memory_list.dart` sends `sort=memory_date` and `time_period` params
  - 2 new l10n keys across 8 languages
- [x] **11.6** Timeline behavior for flexible dates _(completed 2026-02-16)_
  - Design decisions: vertical chronological timeline (newest first), grouped by year → month
  - Precise dates (day): solid primary dot, anchored at exact position
  - Loose dates (month/year/range): hollow tertiary dot + range indicator badge showing approximate scope (≈ Jan 2024, ≈ 2023, etc.)
  - Time periods: colored chip badges on year headers showing overlapping periods
  - New `TimelineView` widget (`lib/widgets/timeline_view.dart`): CustomPaint for timeline line/dots, IntrinsicHeight rows for proper connector stretching
  - List/timeline toggle button in memory list header (Icons.view_list / Icons.timeline)
  - 2 new l10n keys across 8 languages (timelineView, listView)
  - Future enhancement: zoom interaction for loose memories to spread out within their range

### Phase 12: Polish & Production Readiness

> Harden and polish the existing feature set before adding more surface area. Security, performance, and UX safety.

- [x] **12.1** Security hardening: rate limiting on auth endpoints (login/register) _(completed 2026-02-16)_
  - Rate limiting: `auth` limiter (5/min per IP) on login, `register` limiter (3/hour per IP) on register
  - Sanctum token expiration: set to 30 days (env-configurable via `SANCTUM_TOKEN_EXPIRATION`)
  - CORS: removed duplicate custom `Cors` middleware from Kernel, configured `config/cors.php` with env-based `CORS_ALLOWED_ORIGINS`, explicit methods/headers, `max_age: 3600`, `supports_credentials: true`
  - Logout endpoint: added `POST /api/v1/auth/logout` (authenticated) that revokes current token
  - Biometric security: migrated biometric token/email storage from SharedPreferences to `flutter_secure_storage` (iOS Keychain / Android Keystore). Removed dead code (`saveBiometricCredentials`, `getBiometricCredentials`, `_biometricCredentialsKey`)
  - Frontend logout: now calls server logout endpoint to revoke token before clearing local state
  - Biometric edge case: expired/invalid tokens are detected and cleared, user falls back to manual login
- [x] **12.2** Audit API endpoints for proper authorization checks _(completed 2026-02-16)_
  - Systematic review of all 14 controllers and all route files
  - Fixed: TagController `addToMemory`/`removeFromMemory` — now requires owner/contribute permission (was only checking pivot existence, allowing view-only users to modify tags)
  - Fixed: NotificationController `registerDeviceToken` — prevented device token hijacking (was allowing any user to reassign another user's token via `updateOrCreate`)
  - Fixed: Upload endpoint — added rate limiting (`throttle:60,1`) to prevent storage exhaustion attacks
  - Verified: StorageMigration and UserStorageSetting configs already use `encrypted:array` cast
  - Verified: Streaming endpoint has proper `canAccess()` check with manual token auth (intentional design for media player compatibility)
  - Verified: All controllers inside auth group properly use `auth()->id()` for ownership checks
- [x] **12.3** Confirmation dialogs before destructive actions _(completed 2026-02-16)_
  - Audited all 11 destructive actions across the frontend; 9 already had confirmation dialogs
  - Added confirmation dialog to `_cancelRequest` in `content_requests_sheet.dart`
  - Added confirmation dialog to `_deleteNotification` in `notifications_screen.dart`
  - 4 new l10n keys across 8 languages (cancelContentRequest, cancelContentRequestConfirm, deleteNotificationTitle, deleteNotificationConfirm)
- [x] **12.4** Database indexes review and query optimization _(completed 2026-02-16)_
  - Reviewed all 37 migration files across 11 phases
  - Migration `2026_02_16_180000_add_missing_indexes.php` adds 7 indexes across 5 tables:
    - `memory_user`: composite `['user_id', 'permission']` for permission lookups
    - `memories`: `is_personal` for personal filtering
    - `groups`: `is_personal` for personal filtering
    - `friendships`: composite `['user_id', 'status']` and `['friend_id', 'status']`
    - `content_requests`: `status` and composite `['memory_id', 'status']`
  - Eager loading audit: all controllers properly use `->with()` for relationships, no N+1 issues found
  - Foreign keys via `foreignId()` already auto-indexed, no duplicate indexes needed
- [x] **12.5** Pagination for memory list _(completed 2026-02-16)_
  - Backend: offset pagination on `/user/memories` and `/user/{id}/memories` — configurable `per_page` (default 20, max 100)
  - Frontend: `PaginatedMemories` class in `memory_service.dart`, infinite scroll with `ScrollController` in both list and timeline views
  - Loading indicator at bottom of list during page fetches
- [x] **12.6** Health check endpoint _(completed 2026-02-16)_
  - `GET /api/v1/health` — unauthenticated, checks DB connectivity + storage write/delete, returns app version
  - Returns 200 `{"status":"ok"}` when all healthy, 503 `{"status":"degraded"}` when any check fails
- [x] **12.7** Image gallery improvements _(completed 2026-02-16)_
  - New `ImageGalleryViewer` widget: `PageView` with swipe between all images in a memory
  - Pinch-to-zoom via `InteractiveViewer` (minScale 0.5, maxScale 5.0) on each page
  - Image counter overlay ("1 / 5"), loading progress indicator, immersive fullscreen mode
  - `MemoryContentList._openImageGallery()` collects all image URLs and opens gallery at tapped index

### Phase 13: UX & Engagement

> Make the app feel more complete and delightful with social features and onboarding.

- [x] **13.1** Comments and reactions on memory content _(completed 2026-02-16)_
  - Backend: `comments` and `reactions` tables, `Comment`/`Reaction` models, `CommentController` (CRUD + threading), `ReactionController` (grouped list + toggle)
  - Frontend: `CommentsSection` (threaded replies, edit/delete own), `ReactionBar` (emoji chips + picker), integrated into memory detail
  - 9 new l10n keys across 8 languages
- [x] **13.2** Empty state illustrations _(completed 2026-02-16)_
  - New reusable `EmptyState` widget with circular icon background, title, optional description, optional action button
  - Updated 5 screens: memory list, groups (with create button), friends list, friend requests, notifications
  - Consistent styling via theme colors with subtle primary container background
- [x] **13.3** Onboarding / tutorial screens _(completed 2026-02-16)_
  - 5-page `PageView` walkthrough: Memories, Groups, Sharing, Privacy, Timeline
  - Animated page dots, skip button, "Get Started" on last page
  - Shows on first launch (before login); flag stored in SharedPreferences
  - Re-accessible from Settings via "Show Tutorial" button
  - 13 new l10n keys across 8 languages
- [x] **13.4** Drag-and-drop content reordering _(completed 2026-02-16)_
  - Backend: `MemoryResource` now uses `getOrderedContents()` to sort by `memory_content_order` positions, falling back to default order for older memories
  - Backend: New `POST /memories/{memory}/contents/reorder` endpoint accepts ordered array of content IDs, bulk-updates positions in `memory_content_order` table
  - Frontend: `MemoryService.reorderContents()` for API calls
  - Frontend: `CreateMemoryScreen` uses `ReorderableListView.builder` with drag handles on content cards (visible when 2+ items), `proxyDecorator` with Material elevation for drag feedback
  - Drag handle icon added to `MemoryContentEditorWidget` via optional `dragHandle` parameter
- [x] **13.5** Location tagging for memories _(completed 2026-02-16)_
  - Backend: Migration adds `latitude`, `longitude`, `location_name` to memories table with composite index
  - Backend: Model fillable + casts, StoreMemoryRequest validation, MemoryResource + MemoryListResource include location fields, MemoryController store/update save location (owner-only on update)
  - Frontend: Memory model extended with `latitude`, `longitude`, `locationName`; MemoryService sends location in create/update
  - Frontend: `LocationPicker` widget — text input + "Use current location" button (geolocator + geocoding), auto reverse-geocodes to place name
  - Frontend: Location displayed on `MemoryDetailScreen` with pin icon below author section
  - Platform permissions: Android (ACCESS_FINE/COARSE_LOCATION), iOS (NSLocationWhenInUseUsageDescription)
  - 5 new l10n keys across 8 languages; deferred: map view (requires Google Maps API key)

### Phase 14: Testing Foundation

> Establish automated test coverage across the codebase to catch regressions and enable confident refactoring.

- [x] **14.1** Backend: Unit tests for controllers _(completed 2026-02-16)_
  - Auth, Memory, Group, Friend, Tag, Notification controllers — 57 tests, 153 assertions
  - Fixed SQLite compatibility: migration column rename guard, FOREIGN_KEY_CHECKS, MemoryFactory
  - Fixed transaction leak bug in MemoryController::update early returns
  - Added APP_KEY to phpunit.xml, fixed JsonResource::withoutWrapping() in test assertions
- [x] **14.2** Backend: Unit tests for models and relationships _(completed 2026-02-16)_
  - UserModelTest (21 tests): relationships, effectiveTier, canCreateMemory, hasStorageSpace, notifications, storage tracking
  - MemoryModelTest (19 tests): permissions, canAccess, effectivePermission, date formatting, Group/Friendship relationships
  - User, Memory, Group, Friendship, Tag, TimePeriod, UserTier relationships
  - Model accessors, scopes, and helper methods
- [x] **14.3** Backend: API integration tests for key flows _(completed 2026-02-16)_
  - 5 integration tests, 51 assertions: full memory lifecycle, friend+share flow, groups+tags, permission hierarchy, contributor content
  - Total backend: 102 tests, 286 assertions
- [~] **14.4** Frontend: Unit tests for services _(started 2026-02-16)_
  - Model parsing: Memory (10 tests), Group (6 tests), Exceptions (9 tests) — 25 tests, all passing
  - Services need DI refactoring for HTTP mocking; focused on model/utility coverage
- [x] **14.5** Frontend: Widget tests for key screens _(completed 2026-02-16)_
  - EmptyState (5 tests), CustomInputField (4 tests) widget tests
  - Total frontend: 34 tests (10 Memory model, 6 Group model, 9 Exceptions, 9 widget tests)
- [x] **14.6** CI pipeline setup _(completed 2026-02-16)_
  - Backend: `.github/workflows/tests.yml` — PHP 8.3, SQLite, Composer cache, `vendor/bin/phpunit`
  - Frontend: `.github/workflows/tests.yml` — Flutter 3.29.x, `flutter analyze` + `flutter test`
  - Both trigger on push/PR to main and develop branches

### Phase 15: Bug Fixes, UX Overhaul & Media Improvements

> Address accumulated bugs, redesign app navigation with a side drawer and floating create button, restructure settings, improve the date picker UX, and overhaul the audio recording/playback visualization.

**15A — Bug Fixes**

- [x] **15.1** Fix date sorting (year not considered) _(completed 2026-02-17)_
  - Root cause: backend SQL sorting was correct (`COALESCE(memory_date_start, created_at)`), but the default sort was `created_at`, not `memory_date`. Timeline view re-sorted client-side, but only the current page — so paginated results appeared out of order
  - Fix: `memory_list.dart` now forces `sort=memory_date` when timeline view is active, ensuring correct pagination order from the backend
  - Toggling between list/timeline view now triggers a reload with the correct sort parameter

- [x] **15.2** Fix comments system (creating and/or fetching broken) _(completed 2026-02-17)_
  - Root cause: `CommentService.getComments()` tried `body['data']` on a JSON array response. With `JsonResource::withoutWrapping()` in Laravel, the collection returns a plain array `[{...}]`, not `{"data": [...]}`. Accessing `body['data']` on a `List<dynamic>` throws `TypeError` (List expects int index, got String). The exception was silently caught in `_loadComments()`
  - Fix: changed parsing to `body is List ? body : (body['data'] ?? [])` to handle both wrapped and unwrapped responses
  - Creating comments worked (returns single resource, parsed correctly), but fetched list was always empty due to the error

- [x] **15.3** Fix audio upload status text _(completed 2026-02-17)_
  - `memory_content_list.dart` had a hardcoded `'Audio not available'` string for audio without a stream URL, while image and video used the localized `_buildPlaceholder()` with proper "Uploading..." messages
  - Replaced hardcoded text with `_buildPlaceholder(context, Icons.music_note, l10n.audioUploading)`
  - Added `audioUploading` l10n key across all 8 languages

- [x] **15.4** Investigate missing memory ("Summer Vacation", id 25) _(completed 2026-02-17)_
  - Code analysis: the `GET /user/memories` query logic is correct — pivot row exists (user_id 6, memory_id 25, permission owner), access query should match it
  - No global scopes, no SoftDeletes, no `is_flagged` filter in the query
  - **Most likely cause: `is_personal = true`** — the personal filter (line 150-154 of user.php) excludes memories where `is_personal = true` unless `include_personal=1` is passed. If the user accidentally marked "Summer Vacation" as personal, it would be hidden from the default list
  - **Action needed:** Check the `is_personal` column value for memory 25 in the database. If it's `1`/`true`, either toggle it via the API (`PATCH /memories/25/personal`) or unlock personal memories in the app to see it
  - Could not verify directly — remote DB not accessible locally

- [x] **15.5** Refresh memory list after unlocking hidden memories _(completed 2026-02-17)_
  - Root cause: `context.read<PrivacyProvider>()` in `_buildQueryParams()` reads the value at call time but doesn't listen for changes. When unlock state changes, the memory list was never reloaded
  - Fix: `MemoryListState` now listens to `PrivacyProvider` via `addListener()` and triggers `_loadMemories()` on unlock/lock state changes. Properly removes listener in `dispose()`

**15B — Navigation & UX Overhaul**

- [x] **15.6** Side drawer menu _(completed 2026-02-17)_
  - Add a hamburger menu icon (top-left of home screen) that slides in a drawer from the left
  - Drawer contents (top to bottom):
    - **Profile section:** User's profile picture + name (tappable → profile screen)
    - **Groups:** List of user's groups with color indicators (tappable → group detail), plus "Manage Groups" link → groups screen
    - **Time Periods:** List of user's time periods with color dots and date ranges, plus "Manage Time Periods" link (replaces the settings-embedded management)
    - **Divider**
    - **Settings** link → settings screen
    - **Logout** button with confirmation
  - The drawer should load groups and time periods when opened (or cache them)
  - This replaces the current bottom navigation as the primary navigation method for non-memory-list screens

- [x] **15.7** Replace bottom navigation with floating action button _(completed 2026-02-17)_
  - Remove the current `CustomBottomNav` bar (Home, Groups, Profile tabs)
  - The home screen becomes the memory list directly (no tab switching)
  - Add a floating action button (FAB) for creating new memories — position bottom-right or bottom-center
  - The FAB should be the primary create entry point (replaces the bottom nav "+" button)
  - Ensure the FAB doesn't obscure content (slight margin from bottom, semi-transparent or hide on scroll)
  - Profile screen is now accessed via the drawer's profile section
  - Groups screen is now accessed via the drawer

- [x] **15.8** Make timeline the default view _(completed 2026-02-17)_
  - When opening the memory list, default to the timeline view instead of the list view
  - Remember the user's last chosen view preference (list vs. timeline) in SharedPreferences
  - On first launch (no preference saved), default to timeline

- [x] **15.9** Restructure settings page _(completed 2026-02-17)_
  - Organize settings into clear grouped sections with headers:
    - **Appearance:** Theme (light/dark/system), color theme selector, language
    - **Privacy & Security:** Personal memories PIN, biometric unlock settings
    - **Storage:** Current provider, connect/disconnect, migrate, storage usage
    - **Notifications:** Global toggle + per-type notification settings
    - **Account:** Edit profile link, tier info, show tutorial, about/version
  - Each section should be visually distinct (card or divider-separated)
  - Complex sections (Storage, Notifications) can expand inline or navigate to a dedicated sub-page
  - Time periods management moves OUT of settings → into the side drawer (see 15.6)

- [x] **15.10** Improve date selector for memories _(completed 2026-02-17)_
  - Current issue: selecting "Month" or "Year" precision still presents a full specific-date picker
  - Fix: adapt the picker UI to the selected precision:
    - **Year:** Show a year-only scroll picker / dialog (no month or day)
    - **Month:** Show a year + month picker (no day)
    - **Day (Exact):** Show the full date picker (current behavior)
    - **Range:** Show two date pickers (start and end) — verify this already works and improve if needed
  - Ensure the selected precision updates the picker UI immediately when the user taps a precision chip

- [x] **15.11** Fix top icon visibility on scroll (light theme) _(completed 2026-02-17)_
  - In light theme, the top icons (back, share, menu) fade/become hard to see when scrolling down within a memory detail view
  - In dark theme this works fine (icons likely change color or have a background)
  - Solution options: add a subtle background scrim behind icons, change icon color on scroll, or use a collapsing app bar pattern — match the dark theme behavior or improve both

- [x] **15.12** Add group filtering to memory list _(completed 2026-02-17)_
  - In the existing `FilterBottomSheet`, add a group filter section (similar to the existing time period filter and content type filter)
  - Load user's groups and display as selectable chips (with group colors)
  - Backend: add `group` or `group_id` query parameter to the `GET /user/memories` endpoint
  - Frontend: include selected group in `FilterState` and pass to API calls
  - Clearing the group filter shows all memories again

- [x] **15.13** Show group indicators in memory list _(done 2026-02-17)_
  - Added `MemoryGroup` class (id, name, color) and `groups` field to Memory model
  - Small colored dots displayed in subtitle row of list items and timeline cards
  - Handles multiple groups (each group shown as a separate colored dot)
  - Handles nullable group colors gracefully with fallback gray

**15C — Media & Upload Improvements**

- [x] **15.14** Show local content while uploading _(done 2026-02-17)_
  - Added `uploadKey` field to `MemoryContent` model (parsed from backend)
  - Added `findByUploadKey()` to `UploadService` for matching content to pending uploads
  - Rewrote `MemoryContentList` to watch `UploadService` via Provider
  - Images: shows local file preview (Image.file) with semi-transparent overlay + progress ring
  - Audio/Video: shows icon placeholder with progress ring
  - Upload progress overlay is tappable → navigates to profile screen (pending uploads)
  - Failed uploads: error container with "tap to retry" that calls retryUpload
  - Post-upload processing: shows spinner + "Processing..." when upload done but server URL not yet available

- [x] **15.15** Rework audio visualization widget _(done 2026-02-17)_
  - Created `AudioWaveformWidget` using `CustomPainter` for efficient rendering
  - Recording mode: bars grow from right, auto-scroll to latest data
  - Playback mode: static bars with red position indicator, tap-to-seek, scroll-to-seek
  - Fixed NaN: zero-division guards on all playback position calculations
  - Fixed auto-scroll: re-enables when playback line returns to viewport
  - Replaced inline waveform in `record_memory_screen.dart` (removed ~120 lines of inline code)
  - Replaced inline waveform in `create_memory_screen.dart` (removed scroll controller, bar state, scroll methods)

- [x] **15.16** Audio waveform display during playback in memory detail
  - Backend: Created migration adding `waveform` text column to `memory_contents` table
  - Backend: Added `waveform` to `MemoryContent` model `$fillable`, `MemoryResource` API response (for audio content)
  - Backend: `store()` saves waveform from content JSON during memory creation; `uploadMediaFile()` accepts optional waveform field during upload
  - Frontend: Added `waveformData` field to `PendingUpload` model for persistence across app restarts
  - Frontend: `UploadService.addUpload()` accepts waveform, `_performUpload()` sends it as form field
  - Frontend: `create_memory_screen.dart` passes waveform data when queuing audio uploads
  - Frontend: Rewrote `MemoryAudioPlayer` to use `AudioWaveformWidget` when waveform data exists, with slider fallback for older recordings
  - Frontend: `MemoryContentList` passes `content.waveform` to `MemoryAudioPlayer`


**15D — Structure improvements**

- [x] **15.17** Keep all content in the hand of the user (started 2026-02-17, completed 2026-02-17)
  - Three storage modes: `local` (default), `external_cached` (DB cache + external), `external_only` (minimal DB stubs)
  - Per-memory JSON metadata files on external storage (index.json, memories/{id}.json, tags.json, groups.json)
  - Comments always in DB (multi-user), with per-memory disable toggle and global `comments_enabled` preference
  - Privacy Center screen + guided wizard for transparency about what's stored where
  - [x] **15.17a** Database schema & models — `metadata_mode` + `comments_enabled` on user_storage_settings; `comments_disabled` + `is_metadata_stub` on memories; title made nullable
  - [x] **15.17b** MetadataManager & backend infrastructure — `MetadataManager` class for external JSON read/write; `ResolvesMetadata` trait for controller helpers; manifest v2
  - [x] **15.17c** Controller integration — dual-write pattern in MemoryController (store/update/destroy/show/index + all content methods); CommentController rejects when disabled; MemoryResource includes `comments_disabled`
  - [x] **15.17d** Metadata migration endpoints — `MetadataMigrationController` with PUT mode, POST export/import/strip-db/restore-db, GET status; StorageSettingsController returns metadata fields
  - [x] **15.17e** Frontend Privacy Center & Wizard — `PrivacyCenterScreen` showing what's stored where; `PrivacySetupWizard` 4-step modal; drawer menu item; `StorageProvider` metadata methods; all 8 languages
  - [x] **15.17f** Frontend model updates & comment UI — `commentsDisabled` field on Memory model; `CommentsSection` hides input when disabled with explanation message; l10n keys in all 8 languages


**15E — Bug fixes & UX polish**

- [x] **15.18** Post phase 15 fixes _(started 2026-02-17, completed 2026-02-17)_
  - [x] **15.18a** Fix timeline/list toggle icons (swapped) — icon now shows current view mode
  - [x] **15.18b** Fix filter popup bottom cutoff — added isScrollControlled + SingleChildScrollView with max height
  - [x] **15.18c** Add pull-to-refresh on memory detail screen — wrapped CustomScrollView with RefreshIndicator
  - [x] **15.18d** Move notifications icon to main page (memory list header, next to search icon)
  - [x] **15.18e** Side menu: add unlock/lock hidden memories toggle
  - [x] **15.18f** Side menu: add time period administration — new TimePeriodsScreen wrapping TimePeriodSettings
  - [x] **15.18g** Side menu: add About section (app name, version, author: Mikkel Bjornmose Bundgaard)
  - [x] **15.18h** Profile screen: biometric above uploads, logout pinned to bottom
  - [x] **15.18i** Unlock flow: uses hasBiometricCredentials() not supportsBiometrics()
  - [x] **15.18j** Settings page: section headers with icons, primary color, trailing divider
  - [x] **15.18k** Settings page: removed Edit Profile option
  - [x] **15.18l** Privacy Center: fixed local mode description, added "Not on server" section, storage settings link, minimal server title for external_only
  - [x] **15.18m** App icon: configured flutter_launcher_icons with icon.png + adaptive-icon.png (#1a5276 background)
  - [x] **15.18n** Add info/help icons: HelpIconButton widget, added to Fulfill Request, Personal Memories, Time Periods, Biometric Login (all 8 languages)
  - [x] **15.18o** Summer Vacation: confirmed is_personal filtering; added personalMemoriesHidden banner in empty state when PIN is set but not unlocked




### Phase 16: Critical Bug Fixes

> Fix accumulated bugs and small UI issues discovered during testing.

**16A — Data visibility bugs**

- [x] **16.1** Fix profile image not loading after login *(completed 2026-02-18)*
  - Root cause: only the normal email/password login path fetched user data and updated `UserProvider`. Biometric login (from login screen and splash screen) and token-restore all skipped this step.
  - Fix: added `_loadUserData()` in `HomeScreen.initState()` so user data (including profile picture URL) is fetched regardless of which auth path was used. Also added user data fetch to the biometric login path in `login_screen.dart`.
  - The side drawer already reads `profile_picture_thumbnail_url` from `UserProvider` reactively — the issue was just that the provider was never populated.

- [x] **16.2** Fix personal memories not appearing in timeline view *(completed 2026-02-18)*
  - Investigated: `TimelineView` receives the exact same `displayMemories` list as the list view — no filtering or data path differences exist.
  - Root cause was the broken pagination (fixed in a previous session): personal memories were on page 2+, but infinite scroll never loaded beyond page 1 because `hasMorePages` was always `false` (pagination metadata read from wrong JSON location).
  - No code changes needed — already resolved by the pagination fix in `memory_service.dart`.

- [x] **16.3** Fix shared memories not appearing in list or timeline *(completed 2026-02-18)*
  - The backend query in `/user/memories` correctly includes shared memories (direct and group-based). The data-level issue was likely the broken pagination (same as 16.2).
  - Found and fixed a real bug: `is_shared` flag in `MemoryListResource` only detected directly shared memories (user in `memory_user` pivot). Group-shared memories had `is_shared = false` because the user accesses them via `group_user`, not `memory_user`. The "Shared with me" filter would miss them.
  - Fix: changed `is_shared` logic from "user is in pivot with non-owner permission" to "user is NOT the owner" — correctly covers both direct and group-based sharing.

**16B — Recording & media bugs**

- [x] **16.4** Fix sound waves not shown during recording *(completed 2026-02-18)*
  - No waveform visualization during active audio recording
  - Was partially addressed in 2.3 and 15.15 (AudioWaveformWidget), but something has regressed or isn't wired correctly
  - Investigate `record_memory_screen.dart` and `AudioWaveformWidget` connection
  - Ensure waveform is consistent across all recording contexts in the app (record screen, create memory inline recording)

- [x] **16.5** Fix save button not appearing when adding/changing header photo *(completed 2026-02-18)*
  - The save button only appears when adding/changing content, not when only the cover image changes
  - The cover image change handler in `create_memory_screen.dart` needs to call `setState(() => _hasChanges = true)`
  - Audit all actions on the edit page that should trigger the save button (title, cover image, content changes, date changes, location changes, tag changes)

- [x] **16.6** Fix re-saving a memory makes media content disappear *(completed 2026-02-18)*
  - When updating a memory that already has media (image, video, audio), the content disappears — likely trying to re-upload existing media
  - Root cause: the backend `update()` method deletes all old content and recreates it; for existing media that already has a URL/source, it shouldn't create new pending uploads
  - Frontend should distinguish between "new content to upload" vs "existing content to preserve" when sending the update request
  - Backend should detect content items that reference existing files and skip the pending upload flow for those

**16C — UI layout fixes**

- [x] **16.7** Fix lock/unlock personal memories button overlapping text on profile page *(completed 2026-02-18)*
  - Layout issue in the personal memories section of the profile screen
  - Fix spacing/padding or restructure the widget layout to prevent overlap

- [x] **16.8** Add info icon to "Redeem Content Request" button on profile *(completed 2026-02-18)*
  - Use the existing `HelpIconButton` pattern (from 15.18n)
  - Add an info icon next to the "Redeem Content Request" button explaining what this feature does
  - Add l10n key for the explanation text across all 8 languages

- [x] **16.9** Add pattern unlock as option for personal memories *(completed 2026-02-18)*
  - Add a 3x3 dot drag pattern (Android-style) as an alternative unlock method alongside PIN and biometrics
  - Use a Flutter pattern lock package (e.g., `pattern_lock`) or build a custom 3x3 grid with gesture detection
  - Pattern setup flow: draw pattern, confirm pattern, store securely (hashed in `flutter_secure_storage`)
  - Unlock flow: biometrics first (if available) → pattern or PIN fallback (user chooses which they set up)
  - Update `PrivacyProvider` to support pattern as a third security method
  - Settings: "Set up pattern lock" / "Change pattern" in Privacy & Security section
  - L10n keys for pattern-related strings across all 8 languages

- [x] **16.10** Make year headers sticky in timeline view *(completed 2026-02-18)*
  - When scrolling through the timeline, the current year header should stick to the top of the screen until the next year is reached
  - Investigate using `SliverPersistentHeader` with `pinned: true`, or a `sticky_headers` package
  - The sticky header should show the year text with the same styling as the inline year header
  - When scrolling into a new year, the new year header pushes the previous one off screen

### Phase 17: Notification & Upload System Improvements

> Fix notification gaps, implement push notifications, and improve the upload list UX.

**17A — Notification fixes**

- [x] **17.1** Fix notification icon not showing pending friend requests *(done 2026-02-18)*
  - The unread count badge only reflects in-app notifications, not pending friend requests
  - Investigate: are friend request notifications actually being created by the backend? (Check `CreatesNotifications` trait in `FriendController`)
  - If notifications are created but not counted, fix the unread count query
  - If notifications aren't created for some paths, add them
  - The badge should accurately reflect all unread items that need user attention

- [x] **17.2** Fix friend request notification navigation *(done 2026-02-18)*
  - Pressing a friend request notification should take the user directly to the Requests tab (TabBar index 1) in `FriendsScreen`, not the general friends page
  - Update the notification tap handler in `NotificationsScreen` to pass the correct tab index
  - `FriendsScreen` may need to accept an `initialTabIndex` parameter

- [x] **17.3** Implement push notifications (FCM/APNs) *(done 2026-02-18)*
  - Push notifications were deferred in Phase 7 — device token registration API is already ready
  - **Backend:** Integrate Firebase Admin SDK (`kreait/firebase-php` or `laravel-notification-channels/fcm`). When `AppNotification::notify()` creates a notification, also send a push to the user's registered device tokens. Respect quiet mode preferences (no push for quiet notifications)
  - **Frontend:** Add `firebase_messaging` package. Request notification permission on first launch. Register device token via existing `POST /notifications/device-token` endpoint. Handle foreground/background/terminated notification taps (navigate to relevant screen)
  - **Setup:** Firebase project configuration, `google-services.json` (Android), `GoogleService-Info.plist` (iOS), Firebase console setup
  - **Note:** This requires Firebase project credentials — coordinate with project owner

**17B — Upload list UX**

- [x] **17.4** Add upload status icon to header bar *(done 2026-02-18)*
  - Add an upload icon alongside the notification bell in the memory list header
  - When uploads are pending/active, show a badge count or animated indicator
  - Tapping opens a dropdown/popup showing currently pending and uploading items with progress
  - Each item shows: content type icon, memory name, upload progress (or status: pending/failed)
  - A "View all uploads" link at the bottom navigates to the full upload list (existing `PendingUploadsList` on profile, or a new dedicated screen)

- [x] **17.5** Navigate to content from upload list *(done 2026-02-18)*
  - Each item in the upload dropdown/list should be tappable
  - Tapping navigates to the `MemoryDetailScreen` for the memory that content belongs to
  - Requires the `PendingUpload` model to store `memoryId` (if not already)
  - Ideally scroll to or highlight the specific content item within the memory

### Phase 18: Friends System Overhaul

> Simplify the friend-adding experience. Replace the cumbersome invite link system with direct user search and native sharing.

**18A — Backend: Username system**

- [x] **18.1** Add username field to users *(done 2026-02-18)*
  - Migration: add `username` column (string, unique, nullable initially) to `users` table
  - Validation rules: alphanumeric + underscores, min 3 chars, max 30 chars, unique, case-insensitive
  - Auto-generate username on registration: derive from name (lowercase, replace spaces with underscores, append random 4-digit suffix if taken)
  - `POST /auth/register` creates username automatically
  - `POST /user/profile` allows changing username (with uniqueness validation)
  - Update `UserResource` and any relevant API resources to include `username`

- [x] **18.2** Backfill existing users with usernames *(done 2026-02-18)*
  - Migration or artisan command to generate usernames for existing users who don't have one
  - Same derivation logic as registration (name-based + suffix)
  - Handle edge cases: users with identical names, users with empty/null names

- [x] **18.3** Expand user search to include username *(done 2026-02-18)*
  - Update `GET /friends/search` to search by name (LIKE), email (exact), AND username (LIKE)
  - Update `UserSearchResource` to include `username` in results
  - Ensure username search is case-insensitive

**18B — Frontend: Username integration**

- [x] **18.4** Username in registration flow *(done 2026-02-18)*
  - Add username field to registration screen (auto-suggested from name, editable)
  - Real-time uniqueness check (debounced API call or validate on submit)
  - Show availability feedback (green check / red X)

- [x] **18.5** Username in profile *(done 2026-02-18)*
  - Show username on profile screen (displayed as @username)
  - Allow editing username via edit profile (with uniqueness check)
  - Show username in side drawer under the user's name
  - L10n keys for username-related strings across all 8 languages

**18C — Frontend: Friends UX overhaul**

- [x] **18.6** Replace invite system with "Add Friend" flow *(done 2026-02-18)*
  - Remove the Invites tab from `FriendsScreen`
  - Add an "Add Friend" FAB or button on the Friends list tab
  - Tapping opens the user search directly (merge Search tab into the Add Friend flow)
  - Search results show: profile picture, display name, @username
  - One-tap "Send Request" on each search result
  - Keep the existing friend request accept/decline flow (Requests tab stays)

- [x] **18.7** Native share for inviting new users *(done 2026-02-18)*
  - When a user wants to invite someone not on the app, offer a "Share invite" option
  - Use Flutter's `share_plus` package for native share sheet (Facebook, Instagram, SMS, WhatsApp, email, copy link, etc.)
  - The shared content should include: a personal message, an app store link / download link, and optionally a referral/invite code for tracking
  - This replaces the old manual invite link copy/paste system

- [x] **18.8** Clean up old invite system *(done 2026-02-18)*
  - Remove `FriendInvitesTab` widget
  - Remove invite-related l10n keys that are no longer used
  - Keep backend invite endpoints for backwards compatibility (existing invite links should still work if redeemed), but hide from UI
  - Remove "Create Invite" functionality from frontend entirely

### Phase 19: Side Menu Time Period Filtering

> Make time periods in the side drawer interactive — tapping one filters the memory list.

- [x] **19.1** Make time periods tappable in side drawer *(done 2026-02-18)*
  - Each time period entry in the drawer should be tappable (add `InkWell` or `ListTile` tap handler)
  - Tapping a time period: closes the drawer and applies a time period filter to the memory list
  - The memory list should reload with the `time_period` query parameter set (existing backend support from 11.5)

- [x] **19.2** Show active time period filter indicator *(done 2026-02-18)*
  - When a time period filter is active, show a visible indicator on the memory list screen
  - Options: a dismissible chip/banner at the top of the list showing "Filtered: [Time Period Name]", or highlight the filter button
  - Tapping the chip/X clears the filter and reloads all memories
  - The filter should persist through list/timeline view toggles but clear on app restart

### Phase 20: Privacy Information Audit and enhanced setup guide

> Dedicated phase to review and correct all privacy-related information in the app. This phase is brainstorming-first — no code until the audit is complete and findings are documented.

- [x] **20.1** Audit current Privacy Center content
  - Go through every screen and section in the Privacy Center
  - Document what each section claims vs. what the code actually does
  - Flag any discrepancies, outdated information, or missing explanations

- [x] **20.2** Audit data storage locations
  - Enumerate ALL data the app stores: database tables, local filesystem, external storage, SharedPreferences, flutter_secure_storage, device tokens, cached images
  - For each data type, document: what it contains, where it's stored, who can access it, when it's deleted
  - Compare against what the Privacy Center tells the user

- [x] **20.3** Audit data flows
  - Map all data that leaves the device: API calls, push notification tokens, Firebase analytics (if any), crash reports, etc.
  - Map what the server stores vs. what it only proxies
  - Map what third-party services see (Firebase, Dropbox, FTP servers, etc.)
  - Verify the privacy info accurately describes all data flows

- [x] **20.4** Update Privacy Center UI and content
  - Fix any incorrect or misleading information found in 20.1-20.3
  - Add missing explanations for data types or flows not currently covered
  - Ensure language is clear, non-technical, and accurate
  - Update l10n keys across all 8 languages for any text changes

- [x] **20.5** Review privacy policy text (if applicable)
  - If the app needs a user-facing privacy policy (for app store submission), draft it based on audit findings
  - Ensure consistency between in-app Privacy Center and any external privacy policy

- [x] **20.6** Enhanced setup guide (done 2026-02-18)
  - Please rephrase this when starting the task - and ask questions if any.
  - Extend the welcome guide. It should ask - in a user friendly and kind way - how the memories should be stored - defaulting to our server, with clear options to read more about how and why we store what we do. But also giving the option to select "I will host the data myself", indicating that the user will be presented with a second part of the guide after this, guiding the user through the different options, and letting them choose (with skip options of cause). This also means that the app must be able to handle a siatuation where the user hasn't selected a storage method - this should disallow the creation of memories etc. - and clearly state so when trying, given the option to be taken to the settings page to set this up - but it will still allow the user to view friends memories etc.


### Phase 21: Bug Fixes & Corrections

> Fix known bugs, incorrect information, and missing integrations discovered during development.

- [x] **21.1** Fix personal memories not appearing in timeline when filtering *(completed 2026-02-18)*
  - Root cause: `_showPersonalOnly` and `_showSharedOnly` filters were applied client-side after pagination, creating a mismatch — server paginated over all results but client discarded non-matching ones, causing pages to appear empty
  - Backend fix: Added `personal_only` query param to `GET /user/memories` — when set, returns ONLY `is_personal = true` memories (implies `include_personal`). Added `shared_only` query param — when set, returns only memories where the user is NOT the owner
  - Frontend fix: `_buildQueryParams` now sends `personal_only=1` or `shared_only=1` to the backend. Removed client-side filtering of `_showPersonalOnly` and `_showSharedOnly` from the `displayMemories` builder

- [x] **21.2** Fix year sticky header bug in timeline view *(completed 2026-02-18)*
  - Root cause: Multiple `SliverPersistentHeader(pinned: true)` in Flutter stack at the top rather than pushing each other off — each year header accumulated, creating a growing stack of pinned headers
  - Fix: Replaced per-year `SliverPersistentHeader` with regular `SliverToBoxAdapter` year headers that scroll with content, plus a single overlay managed via `Stack`. A scroll listener uses `GlobalKey`s on each year header to detect which year has scrolled past the viewport top, and a `_YearHeaderOverlay` with elevation renders on top. Extracted shared `_YearHeaderContent` widget used by both inline and overlay headers

- [x] **21.3** Fix Privacy Center incorrect media storage claim *(completed 2026-02-18)*
  - The `privacyNotOnServerMedia` l10n key claimed media is "not on server", which is incorrect
  - Media files are uploaded to either the Memory Lane server (default) or the user's configured external storage provider
  - Fix: Removed `privacyNotOnServerMedia` from the "Not on server" card. Added new `privacyServerMedia` l10n key shown in the "On server" card when user has no external storage configured (`!hasExternal`). When external storage is configured, media is correctly shown in the external data card already. Updated all 8 ARB files

- [x] **21.4** Fix "Local Storage" option not selectable when no storage is configured *(completed 2026-02-18)*
  - Renamed "Local Storage" to "Memory Lane Server" across all 8 ARB files — the old label was misleading since it suggested device storage when it actually means the Memory Lane server
  - Changed server storage icon from `Icons.storage` to `Icons.dns_outlined` for consistency with server theme
  - Always show green check mark for the active storage provider (previously only shown for external providers), so users clearly see their current storage is active
  - Updated migration wizard to use `Icons.dns_outlined` for the server option too
  - The subtitle `storageDefault` already correctly says "Default — files stored on server"

- [x] **21.5** Fix pattern lock not available as personal memory unlock method *(completed 2026-02-18)*
  - Pattern lock was already connected in `privacy_provider.dart` unlock flow (biometrics → pattern → PIN fallback chain), but was missing from Settings screen
  - Added pattern lock management section to Settings `_PrivacySecuritySection` — set/change/clear pattern alongside PIN and biometrics
  - Added `_showPatternDialog` and `_clearPattern` methods, imported `PatternDialog`
  - Replaced all hardcoded English strings in `_verifyPatternDialog` and `_verifyPinDialog` with l10n keys (`drawYourPattern`, `incorrectPattern`, `cancel`, `enterPin`, `pinHint`, `verifyButton`)
  - Added 8 new l10n keys across all 8 languages: `patternProtection`, `patternIsSet`, `noPatternSet`, `clearPattern`, `clearPatternConfirm`, `drawYourPattern`, `pinHint`, `verifyButton`

- [x] **21.6** Fix About info in settings *(completed 2026-02-18)*
  - Replaced hardcoded "1.2.0" with dynamic version from `package_info_plus` (added as dependency)
  - About tile now shows actual version+build from `PackageInfo.fromPlatform()` via `FutureBuilder`
  - Made About tile tappable — shows Flutter's `showAboutDialog` with app name, version, icon, description, and developer name
  - Fixed developer name to "Mikkel Bjørnmose Bundgaard" (correct ø character)
  - Added `appDescription` and `developer` l10n keys across all 8 languages

### Phase 22: Notification Improvements

> Enhance the notification system with bulk actions and quicker access.

- [x] **22.1** Add "Mark all as read" action for notifications *(completed 2026-02-18)*
  - Already implemented from Phase 17: backend `POST /notifications/read-all` endpoint, frontend `markAllAsRead()` service method, and UI "Mark All Read" button in notifications screen app bar (visible when `_unreadCount > 0`). No changes needed

- [x] **22.2** Add notification dropdown from the notification icon *(completed 2026-02-18)*
  - Replaced full-screen navigation with overlay popup from notification icon in `memory_list.dart`
  - Popup shows 5 most recent notifications with icon, title, message preview, and relative time
  - Unread notifications highlighted with bold text and tinted background
  - Header with "Mark all read" button, footer with "View all notifications" link and "Clear all" action
  - Tapping a notification dismisses popup and opens full notifications screen
  - Tap-outside-to-dismiss via transparent backdrop overlay

- [x] **22.3** Add "Clear all notifications" action *(completed 2026-02-18)*
  - Backend: Added `DELETE /notifications/clear-all` endpoint (`destroyAll` on `NotificationController`)
  - Frontend: Added `clearAll()` method to `AppNotificationService`
  - Added "Clear all" button (delete_sweep icon) to notifications screen app bar
  - Added "Clear all" button to notification dropdown popup footer
  - Confirmation dialog before clearing on the full notifications screen
  - Added l10n keys: `clearAllNotifications`, `clearAllNotificationsConfirm`, `viewAllNotifications`, `recentNotifications` across all 8 languages

### Phase 23: UI/UX Polish

> Improve visual clarity and navigation structure across the app.

- [x] **23.1** Make personal memory indicator more prominent *(completed 2026-02-18)*
  - Created shared `PersonalBadge` widget (`personal_badge.dart`) with a diagonal triangle in top-right corner using `CustomPaint` and a white lock icon
  - Both list view (`memory_list.dart`) and timeline view (`timeline_view.dart`) now wrap cards in `Stack` with `Clip.antiAlias` and show the badge for personal memories
  - Removed the old small lock icon from the bottom metadata rows in both views

- [x] **23.2** Restructure settings page into categorized sub-pages *(completed 2026-02-18)*
  - Replaced single scrollable settings page with a category list navigation
  - Created 5 sub-pages in `lib/screens/settings/`: `AppearanceSettingsPage`, `PrivacySecuritySettingsPage`, `StorageSettingsPage`, `NotificationSettingsPage`, `AccountSettingsPage`
  - Main `SettingsScreen` now shows ListTiles with icons for each category, navigating to dedicated sub-pages
  - All existing functionality preserved — code moved from inline to separate files
  - Each category shows as a `ListTile` with an icon, title, and optional subtitle/description
  - Tapping a category navigates to a dedicated screen for that section's settings
  - Remove the About section from the bottom of settings — move it to a separate "About" entry in the list

- [x] **23.3** Create dedicated About page *(completed 2026-02-18)*
  - Created `AboutPage` (`lib/screens/settings/about_page.dart`) as a dedicated screen
  - Displays: app icon, app name, version (from `package_info_plus`), app description, developer name card
  - Includes "Open-source licenses" tile that opens Flutter's built-in `showLicensePage`
  - Updated `AccountSettingsPage` to navigate to `AboutPage` instead of showing `showAboutDialog`
  - Added `openSourceLicenses` l10n key across all 8 languages

- [x] **23.4** Minor bugs *(completed 2026-02-19)*
  - Fixed: "Memory Lane Server" not selectable after choosing "decide later" in setup wizard
  - Root cause: When user skipped setup, `storage_setup_completed` stayed `false` but the UI showed local storage as already selected with a green checkmark — no way to explicitly confirm it
  - Fix: Added `_buildConfirmServerButton` to `StorageSettings` widget — when `storageSetupCompleted` is `false` and provider is local, shows a prominent "Use Memory Lane Server" button that calls `completeSetup()`. Provider card now shows warning icon + "Not configured" subtitle instead of green checkmark when setup is incomplete
  - 4 new l10n keys across all 8 languages: `storageNotConfigured`, `storageConfirmServer`, `storageServerConfirmed`, `storageOrConnectExternal`

- [x] **23.5** Fix "failed to update memory" when adding content to a shared memory *(completed 2026-02-19)*
  - Root cause: Frontend always sends title, date, and location fields in the update request. Backend had hard 403 blocks for contributors sending these owner-only fields — even when the contributor only wanted to add content
  - Backend fix: Changed owner-only field checks from hard 403 errors to silent skips — contributors' requests with title/date/location are accepted but those fields are ignored (only owner's values are applied). This is the correct behavior since the frontend sends all fields regardless of permission
  - Backend fix: Content deletion now checks ownership — contributors can only delete their own content, not the owner's or other contributors'. Content the contributor can't delete is preserved with its ordering
  - Backend fix: Text content editing now checks ownership — contributors can only edit text they created

- [x] **23.6** Fix search not finding partial/case-insensitive matches *(started 2026-02-19, completed 2026-02-19)*
  - Root cause: Backend search used `LIKE "%{$search}%"` relying on database collation for case-insensitivity; also had no escaping of LIKE wildcards (`%`, `_`) in user input, and the date range filters had implicit AND/OR precedence that could cause subtle scoping issues
  - Backend fix in `routes/endpoints/user.php`: Search now uses explicit `LOWER(column) LIKE ?` with `mb_strtolower()` on the search term, ensuring case-insensitive matching regardless of database collation. LIKE wildcard characters in user input are escaped. Applied to both `/user/memories` and `/user/{id}/memories` endpoints
  - Backend fix: Date range `$from` filter now wraps its first branch in a proper `where(function...)` closure to prevent OR conditions from escaping the intended scope via SQL AND/OR precedence. Same fix applied to the `$to` filter's inner conditions on both endpoints

- [x] **23.7** Fix privacy settings page showing blank white page with spinner *(started 2026-02-19, completed 2026-02-19)*
  - Root cause: The actual page with a spinner is `PrivacyCenterScreen` (accessible from the app drawer), not `PrivacySecuritySettingsPage` (which has no loading state at all). The `PrivacyCenterScreen` uses `Consumer<StorageProvider>` and shows a `CircularProgressIndicator` whenever `storage.loading` is true — including on re-fetches when settings were already loaded
  - Frontend fix in `privacy_center_screen.dart`: Changed loading check from `storage.loading` to `storage.loading && storage.settings == null` — spinner only shows on initial load. On subsequent visits/refreshes, existing content is displayed immediately while data refreshes in the background
  - Note: `PrivacySecuritySettingsPage` (Settings > Privacy & Security) renders PIN/Pattern/Biometrics controls directly with no loading state — it was never the page with the spinner issue

- [x] **23.8** Fix clearing search field not resetting results *(started 2026-02-19, completed 2026-02-19)*
  - Root cause: Race condition in `_loadMemories()` — when the user clears the search, a new API call fires without the search param, but a slower in-flight search request can return later and overwrite the correct (unfiltered) results with stale search results
  - Frontend fix in `memory_list.dart`: Added `_loadGeneration` counter. Each `_loadMemories()` call increments the counter and captures the current value. When the async API response returns, results are only applied if the generation still matches (i.e., no newer request was started). This prevents stale responses from overwriting fresher data
  - Both the X clear button and the collapse/toggle action already correctly reset `_searchQuery` to `''` and call `_loadMemories()` — the race condition was the only issue

- [x] **23.9** Sticky years look *(started 2026-02-19, completed 2026-02-19)*
  - Frontend fix in `timeline_view.dart`: Replaced `Material(elevation: 2, ...)` on the sticky year overlay with a flat `Container` using a subtle bottom border (`outlineVariant` at 50% opacity). Removed shadow entirely. Changed the `_YearHeaderContent` API from `elevation` parameter to `isOverlay` boolean for clarity. Inline year headers remain unchanged (no border, no shadow).

### Phase 24: Memory Tagging Enhancement

> Improve the tagging workflow by allowing users to add and manage tags directly from the memory detail/edit screen, with smart auto-suggestions based on memory metadata.

- [x] **24.1** Add inline tag management to memory create/edit screen *(completed 2026-02-19)*
  - Add a "Tags" section to `CreateMemoryScreen` (below the date picker or location) where users can view, add, and remove tags
  - Reuse or adapt the existing `TagPickerModal` for tag selection
  - Allow creating new tags inline (type a name → create if it doesn't exist)
  - Tags should be saved when the memory is saved (not as a separate API call)
  - Backend: ensure `MemoryController::store()` and `update()` can accept a `tags` array and sync them in the same request
  - **Notes:** Backend: added `tags` validation to `StoreMemoryRequest`, added `tags()->sync()` in both `store()` and `update()` (owner-only, with ownership check per tag). Frontend: added `tagIds` param to `MemoryService.createMemory()` and `updateMemory()`, added inline tag section to `CreateMemoryScreen` with FilterChip toggles for existing tags and a text field to create new tags on the fly. Tags are sent with the memory save request (no separate API calls).

- [x] **24.2** Auto-suggest tags based on memory metadata *(completed 2026-02-19)*
  - When adding tags, suggest relevant tags based on:
    - **Time period:** If the memory's date falls within a named time period (e.g., "Childhood", "College"), suggest that as a tag
    - **Title and content:** Extract keywords from the memory title and text content to suggest matching existing tags
    - **Existing tags:** Show the user's most-used tags as quick suggestions
    - **Date/season:** Suggest seasonal tags based on memory date (e.g., "Summer", "Christmas", "2024")
  - Suggestions appear as chips above the tag input, tappable to add
  - Backend: new endpoint `GET /tags/suggestions?memory_id={id}` that analyzes memory metadata and returns suggested tag names
  - Frontend: call suggestions endpoint when opening the tag picker, display as a "Suggested" section above existing tags
  - **Notes:** Backend: new `GET /tags/suggestions` endpoint in `TagController` that returns existing matching tags (top-5 most-used, keyword-matched from title/content, time-period-matched) and suggested new tag names (time period names, year from memory date). Accepts `memory_id`, `title`, `date_start`, `text_content` params. Frontend: added `TagSuggestions` model, `getSuggestions()` to `TagService`, integrated into `CreateMemoryScreen` with a "Suggested" section showing ActionChips above the regular tags. Suggestions refresh when the memory date changes. Added `suggestedTags` l10n string to all 8 ARB files.

- [x] **24.3** Reorganize side menu: groups and time periods as sub-menus with pinning *(completed 2026-02-19)*
  - Groups and time periods currently clutter the side menu when there are many items
  - Show "Groups" and "Time Periods" as menu items that expand into a sub-menu within the side menu
  - Allow users to **pin** individual groups and time periods, which promotes them to the first level of the side menu (like current behavior)
  - Only show as many pinned items as can fit in the first-level menu area
  - When viewing the complete list (sub-menu), pinned items should appear at the top
  - Backend: add `pinned` boolean field to user-group and user-time-period relationships (or a separate pinned_items table)
  - Backend: API endpoints to pin/unpin groups and time periods
  - Frontend: redesign drawer to show collapsible sections for groups and time periods
  - Frontend: add pin/unpin UI (e.g., pin icon on each item)
  - **Notes:** Backend: created polymorphic `drawer_pins` table (user_id, pinnable_type, pinnable_id) with `DrawerPin` model. Added `drawerPins()` morphMany to Group and TimePeriod models. New `DrawerPinController` with pin/unpin endpoints for groups and time periods. Group list and time period list endpoints now return `is_drawer_pinned`. Frontend: added `isDrawerPinned` to Group and TimePeriod models. Added `pinGroup`/`unpinGroup` and `pinTimePeriod`/`unpinTimePeriod` to services. Redesigned `AppDrawer`: pinned items show at first level (max 5 per section), "Groups" and "Time Periods" are `ExpansionTile` sub-menus showing all items (pinned at top) with manage buttons. Long-press shows pin/unpin context menu. Added `pinToDrawer`/`unpinFromDrawer` l10n strings to all 8 ARB files.

- [x] **24.4** Improve "Unlock personal" visibility when personal memories exist *(completed 2026-02-19)*
  - The "Unlock personal" option in the side menu should visually stand out more when the user has personal (private) memories
  - Add a visual indicator (badge count, different color, subtle highlight, or icon emphasis) to draw attention to the option
  - Only emphasize when the user actually has personal memories; if none, display normally
  - **Notes:** Backend: added `GET /memories/personal-count` endpoint to MemoryController that returns the count of personal memories owned by the user. Frontend: added `getPersonalCount()` to MemoryService. Added `personalCount` and `hasPersonalContent` to PrivacyProvider with `updatePersonalCount()` method. Drawer fetches personal count during `_loadData()`. When personal content exists and is locked, the "Unlock personal" tile shows primary-colored icon and text with bold weight, plus a badge showing the personal memory count.

- [x] **24.5** Group membership indicators on memory cards *(completed 2026-02-19)*
  - Memories that belong to a group should be visually marked differently on the memory list/timeline
  - Replace the current dot indicator with a **colored vertical line** on the left side of the memory card
  - The line color should match the group's color
  - For memories in **multiple groups**, the vertical line should be split into multiple colored segments (one color per group)
  - Ensure the indicator works in both list and timeline views
  - **Notes:** Replaced the 8x8 colored dots with a 4px-wide vertical color bar on the left edge of memory cards. Created `_GroupColorBar` widget in `memory_list.dart` and `_TimelineGroupColorBar` in `timeline_view.dart`. For single-group memories, shows a solid colored bar; for multi-group memories, the bar is split into equal-height colored segments. Works in both list and timeline views. Removed the old dot indicators from the subtitle row.

- [x] **24.6** Redesign contributor display on memory detail *(Completed 2026-02-19)*
  - The current "Share with" / "By Mikkel Bundgaard" section is too intrusive
  - Replace with a compact contributor display showing **merged user avatar icons** (overlapping circles, similar to Facebook Messenger group conversation icons)
  - Show contributor names as a comma-separated list or on tap/expand
  - The merged avatars should be small and unobtrusive, fitting naturally into the memory header area
  - **Notes:** Replaced the "By [author]" + inline ManageSharesSection with a compact merged-avatar display. Added `_buildMergedAvatars()` method using a Stack of overlapping `ProfileAvatar` circles (28px, 10px overlap, 2px surface-colored border). Shows up to 5 avatars with a "+N" overflow indicator. Contributor names shown as comma-separated text with the date below. Removed the inline ManageSharesSection from the detail view (management will move to a dedicated menu item in Step 24.7).

- [x] **24.7** Add contributor management as its own menu item *(Completed 2026-02-19)*
  - Managing contributors (adding/removing users who can contribute to a memory) should have its own dedicated menu item or action
  - Move contributor management out of the main memory detail view into a dedicated screen/sheet accessible from a menu
  - This declutters the memory detail view while keeping contributor management easily accessible
  - **Notes:** Added "Manage contributors" menu item (with people icon) to the memory detail options menu, visible when the memory has more than one user. Opens a `DraggableScrollableSheet` bottom sheet containing the existing `ManageSharesSection` widget with full permission management and revoke controls. Added `manageContributors` l10n string to all 8 ARB files.

### Phase 25: Admin Panel Expansion

> Expand the Filament admin panel from basic user/memory management into a full operational dashboard. Add system information, app version tracking, group/tag management resources, storage insights, and moderation tools.

- [x] **25.1** System information & app version dashboard widget *(completed 2026-02-19)*
  - New `SystemInfoWidget` on the admin dashboard showing:
    - **Backend version** (read from `config('app.version')` — defined in `config/app.php`)
    - **Laravel version** (`app()->version()`)
    - **PHP version** (`phpversion()`)
    - **Database version** (MySQL/MariaDB version via `DB::select('SELECT VERSION()')`)
    - **Last deploy timestamp** (read from a `storage/deploy_timestamp` file, written by `deploy.sh`)
    - **Server uptime / disk free space** (optional, via `disk_free_space()`)
  - Update `deploy.sh` to write a timestamp file (`date > storage/deploy_timestamp`) after each deploy
  - Display as a clean info card on the dashboard (below the existing stats)

- [x] **25.2** Frontend app version tracking *(completed 2026-02-19)*
  - Add middleware that reads a `X-App-Version` header from API requests and stores it on the user's record (new `last_app_version` and `last_active_at` columns on `users`)
  - Frontend: send the app version (from `package_info_plus`) as `X-App-Version` header on every API request
  - New `AppVersionChart` dashboard widget showing version distribution (doughnut chart of how many users are on each version)
  - Add `last_app_version` and `last_active_at` columns to the UserResource table in Filament

- [x] **25.3** Group Resource in Filament *(completed 2026-02-19)*
  - New `GroupResource` for admin management of groups
  - Table columns: name, color (as colored badge), owner name, memory count, shared user count, is_personal, created date
  - View page: group details, list of memories in the group, list of shared users with permission levels
  - Actions: delete group (with confirmation)
  - Filters: is_personal, has shared users

- [x] **25.4** Tag Resource in Filament *(completed 2026-02-19)*
  - New `TagResource` for viewing and managing tags across all users
  - Table columns: name, owner name, usage count (number of taggables), created date
  - Actions: delete tag (with confirmation), bulk delete
  - Useful for identifying unused/orphaned tags and understanding how users organize content

- [x] **25.5** Storage statistics dashboard widget *(completed 2026-02-19)*
  - New `StorageStatsWidget` (doughnut or bar chart) showing:
    - Number of users per storage provider type (local, Dropbox, FTP, SMB)
    - Total storage used across all users
    - Top 5 users by storage consumption
  - Helps the admin understand infrastructure load and storage provider adoption

- [x] **25.6** Enhanced moderation: flagged content queue *(completed 2026-02-19)*
  - New dedicated Filament page (or filtered view) for reviewing flagged memories
  - Show memory title, owner, flag date, content preview (first text block + thumbnail)
  - Quick actions: unflag (dismiss), delete memory, ban owner
  - Add `flagged_at` timestamp and `flagged_reason` (optional text) to memories so admins can track when/why content was flagged
  - Add a "Flag reason" prompt when flagging from the admin panel

- [x] **25.7** System-wide announcements *(completed 2026-02-19)*
  - Allow admin to send a notification to all users (or filtered subset) from the admin panel
  - New Filament action page with: title, message body, target audience (all users / specific tier / specific users)
  - Uses the existing `AppNotification::notify()` + FCM push system
  - Useful for maintenance notices, feature announcements, or policy updates

- [x] **25.8** The groups page should be reloaded after a group has been created *(completed 2026-02-20)*
  - Root cause: `_saveGroup()` used the bottom sheet's `BuildContext` for `ScaffoldMessenger.of(context)` after `Navigator.pop()` dismissed the sheet, causing the deactivated context to throw an exception that skipped `_loadGroups()`
  - Fix: Renamed parameter to `sheetContext` (used only for `Navigator.pop`), all post-pop `ScaffoldMessenger`/`AppLocalizations` calls now use the State's `context`
  - Moved `_loadGroups()` outside the try-catch so it always runs regardless of SnackBar success
  - Applied same fix to `_confirmDeleteGroup()`: renamed dialog builder context to `dialogContext`, used State's `context` for SnackBars

### Phase 26: Support / Suggestion / Bug Report System

> User-facing support ticket system with chat-style conversations. Users submit bug reports, suggestions, or support inquiries. Admins manage tickets through the Filament panel with status tracking and reply functionality. Feature is per-user enabled via admin panel (disabled by default). Sections are admin-configurable. Attachments (images/videos) supported on both submissions and replies with configurable upload size limits.

- [x] **26.1** Backend: Database migrations and models
  - Migration: add `support_enabled` boolean (default false) to `users` table
  - Migration: create `support_tickets` table (user_id, type enum[bug/suggestion/support], section, section_other, subject, status enum[open/waiting_on_user/waiting_on_supporter/closed], max_upload_bytes nullable, closed_at, reopen_requested_at, reopen_reason)
  - Migration: create `support_messages` table (ticket_id, sender_type enum[user/admin], sender_id, body)
  - Migration: create `support_attachments` table (message_id, file_path, file_name, file_size, mime_type, thumbnail_path, upload_key)
  - Migration: create `support_settings` table (key/value) with seed for max_upload_bytes default (50MB) and sections list
  - Models: `SupportTicket`, `SupportMessage`, `SupportAttachment`, `SupportSetting` with relationships, casts, and helper methods
  - Update `User` model: add `support_enabled` to fillable/casts, add `supportTickets()` HasMany relationship
  - Add `TYPE_SUPPORT_REPLY` constant to `AppNotification`

- [x] **26.2** Backend: API endpoints, controller, middleware, form requests, resources, routes
  - `SupportController` with 7 methods: index, store, show, sendMessage, requestReopen, sections, uploadAttachment
  - `StoreSupportTicketRequest` form request (type, section validated against DB sections, section_other, subject, body, attachments)
  - `SendSupportMessageRequest` form request (body, attachments)
  - `EnsureSupportEnabled` middleware (checks user.support_enabled, returns 403 if false)
  - API Resources: `SupportTicketListResource`, `SupportTicketResource`, `SupportMessageResource`, `SupportAttachmentResource`
  - Routes in `routes/endpoints/support.php`: GET/POST tickets, GET ticket detail, POST messages, POST reopen, GET sections (authenticated + middleware); POST upload (unauthenticated, upload_key auth)
  - Auto-status transitions: user reply → waiting_on_supporter, admin reply → waiting_on_user
  - Two-step upload: create attachment with upload_key → upload file using key
  - File storage in `storage/support/{ticket_id}/attachments/` with image thumbnail generation
  - File size validation against global setting (from support_settings) and per-ticket override

- [x] **26.3** Backend: Include `support_enabled` and sections in user/config API responses
  - Update `/api/v1/user` endpoint response to include `support_enabled` field
  - Ensure auth login/register responses also include `support_enabled`
  - `GET /api/v1/support/sections` endpoint returns admin-configured sections list

- [x] **26.4** Admin panel: SupportTicketResource (table, list page with tabs, filters, actions)
  - New `SupportTicketResource` Filament resource with table: type badge (color-coded), subject (searchable), user name (searchable), section badge, status badge (color-coded), message count, reopen request indicator, timestamps
  - List page with tabs: Active (status != closed), Closed (status = closed), Reopen Requests (closed + reopen_requested_at set)
  - Filters: type, status, section
  - Row actions: view, change status dropdown, close ticket, approve reopen

- [x] **26.5** Admin panel: Custom ticket view page with conversation thread and admin reply
  - Custom Filament ViewPage for SupportTicketResource:
    - Ticket header: type badge, section, subject, status, user info, dates
    - Chronological message thread with visual user/admin distinction, message bodies, attachment previews (image thumbnails, file links)
    - Admin reply form: textarea + send button → creates SupportMessage (sender_type='admin'), auto-transitions status to waiting_on_user, sends push notification to user via `AppNotification::notify()` with TYPE_SUPPORT_REPLY
    - Status management: dropdown to manually change status
    - Per-ticket upload size override field
    - Reopen request display with approve/dismiss actions

- [x] **26.6** Admin panel: SupportSettings page (upload limits, sections manager) + UserResource toggle
  - New `SupportSettings` Filament page (follows SendAnnouncement pattern):
    - Global max upload size setting (number input in MB, stored in support_settings)
    - Sections manager: add/remove/reorder sections
  - Update `UserResource` form: add `support_enabled` toggle with helper text
  - Update `UserResource` table: add `support_enabled` icon column
  - Add bulk action to enable/disable support for multiple users

- [x] **26.7** Frontend: Models and SupportService
  - `SupportTicket` model (id, type, section, sectionDisplay, subject, status, messageCount, latestMessagePreview, etc.)
  - `SupportTicketDetail` model (full ticket with messages list, isClosed, canSendMessage getters)
  - `SupportMessage` model (id, senderType, senderName, senderAvatar, body, attachments, createdAt, isFromAdmin getter)
  - `SupportAttachment` model (id, fileName, fileSize, mimeType, fileUrl, thumbnailUrl, isImage/isVideo getters)
  - `SupportService` singleton: getTickets(), createTicket(), getTicketDetail(), sendMessage(), requestReopen(), getSections(), uploadAttachment()
  - All HTTP calls through AuthService headers, following AppNotificationService pattern

- [x] **26.8** Frontend: Support ticket list screen (with drawer entry, conditional visibility)
  - `SupportScreen` with AppBar, FAB for new ticket
  - Paginated ticket list with pull-to-refresh and infinite scroll
  - Each tile: type icon, subject, status chip, section label, time ago, latest message preview
  - Toggle to show/hide closed tickets (hidden by default)
  - Empty state with icon and localized message
  - Add "Support" entry to app drawer, conditionally visible when `userData['support_enabled'] == true`

- [x] **26.9** Frontend: Create support ticket screen (form with type, section, attachments)
  - `CreateSupportTicketScreen` with form:
    - Type selector (ChoiceChips: Bug Report, Suggestion, Support Inquiry)
    - Section dropdown (fetched from API, admin-configurable)
    - Free text field when "Other" selected
    - Subject text field (required, max 255)
    - Description textarea (required, max 5000)
    - Attachment picker (images/videos, previews with remove button, max 5)
  - Form validation with localized error messages
  - On submit: call createTicket(), upload attachments via two-step flow, navigate to ticket detail

- [x] **26.10** Frontend: Ticket detail screen (chat UI, replies, attachments, closed/reopen states)
  - `SupportTicketDetailScreen` with:
    - AppBar: ticket subject, status chip
    - Scrollable message list (chat-style): user messages left-aligned, admin messages right-aligned
    - Each bubble: sender name, body text, attachment previews (tappable for full-screen), timestamp
    - Bottom input bar: TextField, send button, attachment button
    - Input bar hidden when ticket is closed → show "This ticket is closed" banner + "Request Re-open" button
    - Re-open dialog: reason text field + submit
    - Auto-scroll to newest message
  - Support widgets in `widgets/support/`: ticket_tile, message_bubble, attachment_preview, type_selector, section_picker

- [x] **26.11** Frontend: Notification handling for `support_reply` type
  - Add `typeSupportReply = 'support_reply'` constant to `AppNotification` model
  - Handle notification tap: navigate to `SupportTicketDetailScreen` with ticket_id from notification data
  - Update notification preferences to include support_reply type

- [x] **26.12** Localization: All new strings across 8 languages (~32 keys)
  - Add all support-related strings to all 8 .arb files (EN, DA, DE, ES, FR, JA, KO, ZH)
  - Keys include: support, supportTickets, newTicket, bugReport, suggestion, supportInquiry, ticketType, ticketSection, ticketSubject, ticketDescription, section names, status names, sendMessage, typeMessage, attachFile, noTickets, ticketClosed, requestReopen, reopenReason, etc.
  - Run `flutter gen-l10n` to generate

- [x] **26.13** Testing, polish, and version bump
  - Test full flow: enable support for user in admin → user creates ticket → admin views and replies → user sees reply and notification → user replies back → admin closes → user sees closed state → user requests reopen → admin approves
  - Test attachment upload flow (images and videos) on both submissions and replies
  - Test file size validation (global limit and per-ticket override)
  - Test conditional visibility (support disabled = no access, 403 from API)
  - Test notification flow (admin reply triggers push to user)
  - Test edge cases: empty messages rejected, closed ticket can't accept messages, reopen request on non-closed ticket rejected
  - Version bump

### Phase 27: Wear OS Integration

> Quick-capture memories from your wrist via Wear OS. Record voice memories with a single tap on your watch, paired to your phone app for seamless authentication.
>
> **Note:** Android Auto was originally planned but **skipped** — Android Auto cannot access the microphone for audio recording and only supports templated media/messaging/navigation UIs (no custom Flutter rendering). If Android Auto support is desired in the future, it would be limited to **memory playback** (listening to audio memories while driving).

**Backend — Device Pairing API:**
- [x] **27.1** Create device pairing system *(2026-03-02)*
  - Created `device_pairings` migration and `DevicePairing` model
  - Created `PairingController` with `initiate` (no auth), `status` (no auth), `confirm` (auth), `devices` (auth), `unpair` (auth)
  - Routes in `routes/endpoints/pairing.php` + unauthenticated routes in `api.php` with rate limiting
  - Pairing flow: watch generates 6-digit code → user enters code on phone → backend issues Sanctum token to watch

**Wear OS Frontend:**
- [x] **27.2** Set up Wear OS support *(2026-03-02)*
  - Added `wear_plus: ^1.2.4` to `pubspec.yaml`
  - Added `<uses-feature android:name="android.hardware.type.watch" android:required="false"/>` to manifest
  - Added platform detection MethodChannel (`isWearOS`) in `MainActivity.kt`
  - Modified `main.dart` to detect Wear OS at startup and route to `WearApp`

- [x] **27.3** Build Wear OS pairing screen *(2026-03-02)*
  - `lib/wear/wear_pairing_screen.dart` — displays 6-digit code, polls for confirmation every 3 seconds
  - Shows countdown timer, handles expiry and errors with retry
  - On successful pairing, stores auth token and transitions to record screen

- [x] **27.4** Build Wear OS Quick Record screen *(2026-03-02)*
  - `lib/wear/wear_record_screen.dart` — circular watch-optimized UI
  - States: idle (large mic button) → recording (pulsing red stop button + timer) → saving → saved (checkmark) → auto-reset to idle
  - Uses `record` package for AAC-LC audio capture (mono, 44.1kHz)
  - Calls `quickCreateMemory(source: 'wear_os')` and queues upload via `UploadService`
  - Supports ambient mode (minimal display to save battery)

**Phone-side Pairing UI:**
- [x] **27.5** Add Pair Watch screen to phone app *(2026-03-02)*
  - `lib/screens/settings/pair_watch_page.dart` — enter 6-digit code to pair, view/unpair devices
  - Added "Pair Watch" option in Account Settings page
  - Created `lib/services/pairing_service.dart` for pairing API calls

- [x] **27.6** Localization *(2026-03-02)*
  - Added 8 new localization keys to all 8 ARB files (EN, DA, DE, ES, FR, JA, KO, ZH)
  - Keys: `pairWatch`, `pairWatchInstructions`, `pairedDevices`, `noPairedDevices`, `watchPairedSuccess`, `unpairWatch`, `unpairWatchConfirm`, `unpair`

- [x] **27.7** Version bump *(2026-03-02)*
  - Frontend: 0.9.0+1 → 0.10.0+1
  - Backend: 0.11.0 → 0.12.0

### Phase 28: Audio Player & Streaming Overhaul

> **Complete rewrite of the audio playback experience.** The current audio player and waveform visualizer are legacy code with known issues: large files fail to stream, the visualizer feels rough, and playback controls are too minimal. This phase rebuilds the player from scratch while keeping the existing waveform data format.

- [x] **28.1** Fix backend audio streaming (Range request support, correct MIME types) *(2026-03-03)*
  - `response()->stream()` → proper `BinaryFileResponse` with Range support for local storage
  - Handle Range requests for external storage providers (Dropbox, FTP, SMB)
  - Fix MIME type: return `audio/mp4` for `.m4a` files instead of `video/mp4`
  - Ensure `Content-Length` header is present in all responses
- [x] **28.2** Design new audio player widget (brainstorm with user) *(2026-03-03)*
  - Clean, modern player with waveform visualization
  - Controls: play/pause, seek (tap on waveform), return to start
  - Time display: current position / total duration
  - Loading state for streaming audio
  - Error state with retry
- [x] **28.3** Implement new audio player widget *(2026-03-03)*
  - Rewrote `MemoryAudioPlayer` with spinner while setSource() loads, restart button, error+retry state
  - Kept existing `AudioWaveformWidget` unchanged (waveform data format unchanged)
  - Handles both URL sources (streamed from server) and local files
- [x] **28.4** Bulletproof recording on Wear OS and phone *(2026-03-03)*
  - **Lifecycle interruption detection** — `WidgetsBindingObserver` in both `RecordMemoryScreen` and `WearRecordScreen`. On `paused`/`detached` while recording: stops recorder, saves waveform, clears wakelock, dismisses notification.
  - **Recovery flow** — recording path + elapsed seconds + waveform snapshot written to `SharedPreferences` on start and updated every 30s. On next open of `RecordMemoryScreen`, if a path is found and the file exists, a dialog offers Save or Discard.
  - **Recording notification** — ongoing system notification ("Recording... MM:SS") shown when recording starts via `NotificationService.showRecordingNotification()`. Updated every 10s. Dismissed on stop/interruption. Added `cancelNotification` to `NotificationHelper.kt` + `MainActivity.kt`.
  - **Wear OS ambient mode** — `WearRecordScreen` stops and auto-saves when lifecycle transitions to paused/detached (ambient mode triggers this).
- [x] **28.5** Localize new player strings, test, version bump *(2026-03-03)*
  - No new l10n strings needed for the player rewrite (uses icons/animations)
  - Frontend bumped to `0.11.0`, backend bumped to `0.13.0`

### Phase 29: Quick Memory Workflow & Content Management

> **Two new features to improve how memories are created and organized.** Quick recordings from the watch (and phone) currently land directly in the timeline as bare voice memos — they need a staging step where the user can enrich them before they appear alongside polished memories. Additionally, users need the ability to move content between memories for better organization.

**29.1 and 29.2 require brainstorming with the user before implementation.**

- [x] **29.1** Design quick memory staging workflow *(2026-03-03)*
  - Decided: dedicated **"Voice Memos"** section in the drawer (not "Inbox" — too confusing)
  - Amber badge count on drawer item shows number of unprocessed recordings
  - Quick memories filtered from main timeline until "promoted" (given a title via existing edit flow)
  - For now: quick captures are always audio only

- [x] **29.2** Design content movement between memories *(2026-03-03)*
  - Decided: long-press on content item → bottom sheet with "Move to another memory" + "Delete"
  - Memory picker: `DraggableScrollableSheet` with real-time search filter
  - Move only (no copy) for simplicity

- [x] **29.3** Implement quick memory staging *(2026-03-03)*
  - Backend: `is_quick_memory` boolean column added to memories table (migration)
  - Backend: main timeline `index()` filters out `is_quick_memory = true`
  - Backend: new `GET /memories/inbox` endpoint returns only owned quick memories
  - Frontend: `VoiceMemosScreen` — staging area with audio player per item, edit + delete buttons
  - Frontend: amber badge count in drawer via `getInboxCount()`
  - Wear OS recording flow marks memories as `is_quick_memory = true`

- [x] **29.4** Implement content movement between memories *(2026-03-03)*
  - Backend: `POST /api/v1/memories/{memory}/contents/{content}/move` — moves file + updates record
  - Frontend: long-press on content in `MemoryContentList` → move or delete bottom sheet
  - Frontend: `_MemoryPickerSheet` widget with searchable list of user's memories
  - Frontend: long-press on memory list items → delete confirmation (for owners)

- [x] **29.5** Localize, test, version bump *(2026-03-03)*
  - Added keys to all 8 languages: `voiceMemos`, `voiceMemosEmpty`, `voiceMemosEmptyDescription`, `voiceMemosTapToTitle`, `refresh`, `moveToMemory`, `moveContent`, `selectMemory`, `contentMoved`
  - Removed duplicate `searchMemories` key from all 8 ARB files
  - Frontend: `0.11.0+1`, Backend: `0.13.0`

### Phase 30: Watch Recording Reliability & Error Logging

> **Fix critical watch reliability issues and add error logging infrastructure.** Users report: save spins forever, retry doesn't work, no offline fallback, no connectivity pre-check, and no way to diagnose issues remotely.

- [x] **30.1** Fix watch save reliability — offline-first queue *(2026-03-05)*
  - Created `PendingRecording` model (`lib/wear/pending_recording.dart`)
  - Created `RecordingSyncService` (`lib/wear/recording_sync_service.dart`)
  - Updated `wear_record_screen.dart`: 10s timeout, connectivity check, offline save fallback, retry fix
  - Updated `wear_app.dart`: init sync service + provide via Provider

- [x] **30.2** Watch UI improvements *(2026-03-05)*
  - New `savedOffline` state with cloud-off icon + "Saved locally / Will sync when online"
  - Fixed retry: error state `onTap` now calls `_retrySave()` (re-attempts save with existing recording)
  - Pending upload count badge on idle screen (orange cloud icon + "N pending")

- [x] **30.3** Client error logging — Backend *(2026-03-05)*
  - Migration: `client_error_logs` table (user_id, device_type, severity, category, message, context JSON, app_version)
  - Model: `ClientErrorLog`
  - Controller: `ClientErrorLogController` (batch POST `/client-errors`, max 50 per request)
  - Route file: `client_error.php`, registered in `api.php`

- [x] **30.4** Client error logging — Frontend *(2026-03-05)*
  - Created `ErrorLogService` (`lib/services/error_log_service.dart`) — singleton, buffered, periodic flush
  - Added logging to `wear_record_screen.dart` (start/save/offline/error) and `upload_service.dart` (complete/failed)
  - Initialized in `main.dart` for both phone and wear_os device types

- [x] **30.5** Filament admin error log viewer *(2026-03-05)*
  - `ClientErrorLogResource` with table, severity badges, category/device/user filters
  - Tabs: Errors (with 24h count badge), Warnings, All
  - Read-only with bulk delete

- [x] **30.6** Localization *(2026-03-05)*
  - Added `savedLocally`, `willSyncWhenOnline`, `pendingCount`, `noConnection`, `connectionRestored` to all 8 ARB files

- [x] **30.7** Testing & version bump *(2026-03-05)*
  - Frontend: `0.11.1+1`, Backend: `0.13.1`

### Phase 31: Watch Experience Enhancement *(completed 2026-03-04)*

> **Enhance the full Wear OS experience** with haptic feedback, health check pre-flight, token refresh, phone-assisted upload via Wearable Data Layer, configurable watch settings, admin error dashboard widgets, cleanup tasks, and Wear OS complication.

- [x] **31.1** Haptic feedback on watch *(2026-03-04)*
  - Added HapticFeedback at key moments: start recording (medium), stop (light), saved (heavy), saved offline (medium), errors (vibrate)

- [x] **31.2** Health check pre-flight *(2026-03-04)*
  - GET `/health` with 3s timeout before API calls; saves offline on failure

- [x] **31.3** Token refresh — backend *(2026-03-04)*
  - Added `last_refreshed_at` to `device_pairings` table
  - Added `POST /pairing/refresh-token` endpoint — revokes old Sanctum token, creates new one

- [x] **31.4** Token refresh — frontend (watch) *(2026-03-04)*
  - Added `PairingService.refreshToken()` method
  - Watch app calls refresh on startup (fire-and-forget); forces re-pair on 401
  - `_saveMemory()` catches `UnauthorizedException` with "Session expired" error

- [x] **31.5** Watch settings — backend *(2026-03-04)*
  - Created `watch_settings` table (user_id unique FK, max_recording_duration nullable, low_quality_audio default false)
  - Added `GET/PUT /pairing/watch-settings` endpoints

- [x] **31.6** Watch settings — phone UI + post-pairing wizard *(2026-03-04)*
  - Created `WatchSettingsScreen` (battery saving + data saving toggles)
  - Added "Watch Settings" button on pairing page when paired
  - Added post-pairing wizard bottom sheet (both settings off by default)

- [x] **31.7** Watch settings — watch side *(2026-03-04)*
  - Watch fetches settings on startup, caches in SharedPreferences
  - Max duration: auto-stop + haptic when limit reached, timer warning at 80%
  - Low quality audio: reduces sampleRate to 22050, bitRate to 64000

- [x] **31.8** Error log cleanup + recording file cleanup *(2026-03-04)*
  - Created `app:cleanup-error-logs` artisan command (deletes logs >30 days), scheduled daily
  - Added `cleanupOrphanedFiles()` to RecordingSyncService (deletes orphaned recording_*.m4a >7 days)

- [x] **31.9** Admin error dashboard widgets *(2026-03-04)*
  - ErrorLogChart: line chart of errors/day (14 days) by severity
  - ErrorLogCategoryChart: doughnut chart of errors by category (7 days)
  - ErrorLogDeviceChart: doughnut chart of errors by device type (7 days)

- [x] **31.10** Phone-assisted upload via Wearable Data Layer *(2026-03-04)*
  - Watch-side: WearableDataService.kt (ChannelClient for files, MessageClient for metadata)
  - Phone-side: WearableListenerService.kt receives recordings, bridges to Flutter
  - Flutter bridge: WearableTransferService (watch Dart wrapper), WearableReceiverService (phone handler)
  - Save flow: phone reachable → send via Data Layer → "Sent to phone" state; fallback to direct upload or offline queue

- [x] **31.11** Wear OS complication *(2026-03-04)*
  - PendingCountComplication: ShortText showing pending recording count on watch face
  - Reads from SharedPreferences, updates every 5 minutes

- [x] **31.12** Localization *(2026-03-04)*
  - Added 16 new strings to all 8 ARB files (EN, DA, DE, ES, FR, JA, KO, ZH)

- [x] **31.13** Version bump *(2026-03-04)*
  - Frontend: `0.12.0+1`, Backend: `0.14.0`

### Quick Fixes (pre-Phase 32)

- [x] **QF.1** Clear biometric credentials on logout *(2026-03-05)*
  - Added `clearBiometricCredentials()` and `prefs.remove(hasShownBiometricPromptKey)` to `AuthService.logout()`
  - On next login, user will be prompted to set up biometric login again

- [x] **QF.2** Watch sync queue screen *(2026-03-05)*
  - Created `lib/wear/sync_queue_screen.dart` — shows all queued recordings with status, timestamp, retry count
  - Per-entry retry and delete (with confirmation dialog) buttons
  - Global "Sync all" button that retries all failed/stale entries
  - Added `retryAll()` method to `RecordingSyncService`
  - Made the orange "N pending" indicator tappable on the watch idle screen → navigates to sync queue

- [x] **QF.3** Fix watch-to-phone Bluetooth transfer reliability *(2026-03-05)*
  - **Root cause:** `_saveMemory()` gated the phone transfer path behind `Connectivity().checkConnectivity()` — which checks WiFi/cellular on the watch device. Bluetooth connection to the phone does NOT register as network connectivity, so `ConnectivityResult.none` was returned and the entire phone-transfer path was skipped.
  - **Fix:** Removed the connectivity gate from the phone transfer path. The Wearable Data Layer works over Bluetooth independently of WiFi. The connectivity check is now only used for diagnostic logging.
  - Added detailed `ErrorLogService` logging at each decision point: phone reachability, transfer result, ACK receipt, and fallback to queue — making future debugging straightforward

### Phase 32: AI Features — Transcription, Smart Metadata, Cover Art & Text-to-Speech

> **Model-agnostic AI integration with per-functionality provider selection, strong privacy controls, and a user-first opt-in philosophy.** All AI processing is server-side (backend calls the AI provider). API keys are platform-managed (configured in admin). The architecture uses abstract provider contracts so new AI services (including self-hosted) can be added by implementing a single class per capability.

**Design principles:**
- **Privacy first** — AI is 100% opt-in. Users can disable all AI features globally. No data is ever sent to AI providers without explicit user action.
- **User-initiated only** — AI never runs automatically. Every AI action requires the user to press a button.
- **Model-agnostic** — each AI capability (transcription, text generation, image generation, TTS) can use a different provider/model, configured independently in admin.
- **Extensible** — adding a new AI provider means implementing an interface class. No core code changes needed.
- **Transparent** — the app clearly indicates when content was AI-generated.

#### Step 32.1 — Backend AI Architecture

- [x] **32.1.1** Create AI service manager and contracts (2026-03-05)
  - `app/Services/AI/AIServiceManager.php` — registry pattern (like `StorageProviderInterface`)
    - `registerProvider(string $capability, string $name, string $class)`
    - `resolve(string $capability): ?AIProviderContract` — reads `AppSetting` to determine which provider to use
    - `isEnabled(): bool` — checks `ai.enabled` global setting
    - `getAvailableProviders(string $capability): array`
  - `app/Services/AI/Contracts/AIProviderContract.php` — base interface
    - `name(): string`
    - `capabilities(): array`
    - `isConfigured(): bool`
    - `getModels(): array` — list available models for admin dropdown
  - `app/Services/AI/Contracts/TranscriptionProvider.php` — extends AIProviderContract
    - `transcribe(string $audioPath, string $language = 'auto'): TranscriptionResult`
  - `app/Services/AI/Contracts/TextGenerationProvider.php` — extends AIProviderContract
    - `generateMemoryMetadata(array $contentTexts, string $language): GeneratedMetadata`
  - `app/Services/AI/Contracts/ImageGenerationProvider.php` — extends AIProviderContract
    - `generateCoverImage(string $description, string $style = 'default'): GeneratedImage`
    - `getAvailableStyles(): array` — returns style presets (photorealistic, illustration, watercolor, etc.)
  - `app/Services/AI/Contracts/TextToSpeechProvider.php` — extends AIProviderContract
    - `synthesize(string $text, string $voice = 'default', string $language = 'en'): SpeechResult`
    - `getAvailableVoices(): array` — returns voice/persona options
  - DTOs in `app/Services/AI/DTOs/`:
    - `TranscriptionResult` (text, language, confidence, segments[])
    - `GeneratedMetadata` (suggestedTitle, suggestedTags[], suggestedTimePeriod{start, end, name})
    - `GeneratedImage` (imageData, mimeType, style, prompt)
    - `SpeechResult` (audioData, mimeType, duration, voice)

- [x] **32.1.2** Create OpenAI provider implementations (2026-03-05)
  - `app/Services/AI/Providers/OpenAI/OpenAITranscription.php` — uses Whisper API
  - `app/Services/AI/Providers/OpenAI/OpenAITextGeneration.php` — uses GPT-4o with structured output
  - `app/Services/AI/Providers/OpenAI/OpenAIImageGeneration.php` — uses DALL-E
  - `app/Services/AI/Providers/OpenAI/OpenAITextToSpeech.php` — uses TTS API with voice selection
  - Register all in `AIServiceManager` boot method
  - Install `openai-php/laravel` package or use raw HTTP via Laravel HTTP client

- [x] **32.1.3** Admin AI settings via `AppSetting` (2026-03-05)
  - `ai.enabled` — global kill switch (boolean)
  - `ai.transcription.provider` — provider name (e.g., "openai")
  - `ai.transcription.model` — model identifier (e.g., "whisper-1")
  - `ai.text_generation.provider` / `ai.text_generation.model`
  - `ai.image_generation.provider` / `ai.image_generation.model`
  - `ai.tts.provider` / `ai.tts.model`
  - `ai.provider_keys.openai` — encrypted API key (stored via `Crypt::encrypt`)
  - Filament admin page: AI Configuration — dropdown per capability showing registered providers, model selection, API key fields
  - Validation: test API connection button per provider

#### Step 32.2 — Content Linking & Database Changes

- [x] **32.2.1** Migration: add AI fields to `memory_contents` (2026-03-05)
  - `linked_content_id` — nullable FK to `memory_contents.id` (links transcription ↔ audio, TTS audio ↔ text)
  - `ai_generated` — boolean, default false (marks content as AI-generated for transparency)
  - `ai_provider` — nullable string (which provider generated this, e.g., "openai/whisper-1")
  - Index on `linked_content_id`

- [x] **32.2.2** Migration: add AI fields to `memories` (2026-03-05)
  - `ai_title` — nullable string (AI-suggested title, separate from user title)
  - `ai_tags_applied` — boolean, default false (whether AI-suggested tags were applied)

- [x] **32.2.3** Update models and resources (2026-03-05)
  - `MemoryContent`: add `linked_content_id`, `ai_generated`, `ai_provider` to fillable; add `linkedContent()` and `sourceContent()` relationships
  - `Memory`: add `ai_title`, `ai_tags_applied` to fillable
  - Update `MemoryContentResource` to include AI fields and linked content info
  - Update `MemoryResource` to include AI metadata

#### Step 32.3 — API Endpoints

- [x] **32.3.1** AI controller and routes (2026-03-05)
  - `app/Http/Controllers/Api/AIController.php`
  - `POST /api/v1/ai/transcribe` — transcribe audio content
    - Input: `memory_id`, `content_id` (must be audio type)
    - Flow: download audio → call TranscriptionProvider → create linked text content → return
    - Returns: new text content with `linked_content_id` set to the audio content
  - `POST /api/v1/ai/generate-metadata` — generate title, tags, time period
    - Input: `memory_id`
    - Flow: gather all text content (incl. transcriptions) → call TextGenerationProvider → return suggestions
    - Returns: `GeneratedMetadata` DTO (user reviews before applying)
  - `POST /api/v1/ai/apply-metadata` — apply user-approved AI suggestions
    - Input: `memory_id`, `title` (optional), `tags[]` (optional), `time_period` (optional)
    - Flow: update memory title, create/attach tags, create/attach time period
  - `POST /api/v1/ai/generate-cover` — generate cover image
    - Input: `memory_id`, `style` (from available presets)
    - Flow: gather content descriptions → call ImageGenerationProvider → store as cover image → return
  - `POST /api/v1/ai/text-to-speech` — convert text to speech
    - Input: `memory_id`, `content_id` (must be text type), `voice` (from available voices)
    - Flow: call TextToSpeechProvider → store audio file → create linked audio content → return
  - `GET /api/v1/ai/capabilities` — return what's enabled and available
    - Returns: which capabilities are enabled, available styles, available voices, user's AI opt-out status
  - Routes in `routes/endpoints/ai.php`

- [x] **32.3.2** User AI preference (2026-03-05)
  - Add `ai_enabled` column to `users` table (boolean, default true — but first-launch wizard will ask)
  - Middleware or check in AIController: if user has `ai_enabled = false`, return 403 with clear message
  - `PATCH /api/v1/user/settings/ai` — toggle AI on/off
  - `GET /api/v1/user/settings/ai` — get current AI preference + available voice preference

- [x] **32.3.3** User voice preference (2026-03-05)
  - Add `ai_tts_voice` column to `users` table (nullable string, stores preferred voice/persona ID)
  - Return voice preference in user settings endpoint
  - Update `PATCH /api/v1/user/settings/ai` to accept `voice` parameter

#### Step 32.4 — Frontend: AI Settings & Onboarding

- [x] **32.4.1** Setup wizard AI step (2026-03-05)
  - Add a new step to the initial setup wizard / onboarding flow (`onboarding_screen.dart`)
  - **Title:** "AI Features" (or localized equivalent)
  - **Content:** Clear, warm explanation:
    - Memory Lane offers optional AI features to help you organize and enrich your memories
    - These features include: transcription, smart titles & tags, cover art generation, and text-to-speech
    - **Your privacy is our top priority.** AI features are completely optional.
    - If you enable AI, it will only run when YOU choose to — never automatically
    - You can turn AI features off at any time in Settings, and no data will be sent to AI services
    - When AI is disabled, these features simply don't appear in the app
  - **Toggle:** "Enable AI Features" with clear ON/OFF state
  - **Privacy emphasis:** Use a privacy shield icon, warm reassuring tone, maybe a small "Learn more" link to privacy policy
  - Save choice to user's `ai_enabled` setting via API

- [x] **32.4.2** AI settings page (2026-03-05)
  - New settings sub-page: Settings > AI Features
  - Master toggle: "Enable AI Features" — with the same privacy reassurance text
  - When enabled, show:
    - **Voice preference** section: list available TTS voices/personas with preview (play sample)
    - **AI-generated content indicator:** toggle to show/hide the "AI" badge on generated content
  - When disabled: show explanation of what AI features are and that they can be enabled here
  - Link to privacy policy section about AI data handling

- [x] **32.4.3** Frontend AI service (2026-03-05)
  - `lib/services/ai_service.dart` — singleton, uses `ApiService` for HTTP calls
    - `transcribeAudio(int memoryId, int contentId): Future<MemoryContent>`
    - `generateMetadata(int memoryId): Future<AIMetadata>`
    - `applyMetadata(int memoryId, {String? title, List<String>? tags, ...}): Future<Memory>`
    - `generateCover(int memoryId, String style): Future<MemoryContent>`
    - `textToSpeech(int memoryId, int contentId, {String? voice}): Future<MemoryContent>`
    - `getCapabilities(): Future<AICapabilities>` — caches available styles, voices, enabled state
    - `toggleAI(bool enabled): Future<void>`

#### Step 32.5 — Frontend: AI Feature UI

- [x] **32.5.1** Audio transcription UI (2026-03-05)
  - On audio content cards: add "Transcribe" button (only visible when AI enabled)
  - Tapping shows a loading state while transcription runs
  - On completion: new text content appears linked below/beside the audio
  - Visual indicator: linked content pair shown with a subtle connector (e.g., a thin line or "Transcribed from audio" label)
  - The text content card shows a small "AI" badge and "Transcribed" label
  - User can edit the transcription text after generation

- [x] **32.5.2** Smart metadata generation UI (2026-03-05)
  - On memory detail screen: "AI Suggest" or magic wand icon button
  - Tapping opens a bottom sheet with loading spinner
  - Shows suggestions: proposed title, proposed tags (as chips), proposed time period
  - Each suggestion has accept/reject controls (checkboxes or swipe)
  - "Apply Selected" button to confirm chosen suggestions
  - Existing title/tags are preserved if user doesn't accept the AI suggestion

- [x] **32.5.3** Cover image generation UI (2026-03-05)
  - On memory detail screen: "Generate Cover" button (in the cover image area, or in an overflow menu)
  - Style picker: 2-3 preset cards with visual examples (photorealistic, illustration, watercolor)
  - Loading state while image generates
  - Preview the generated image before applying
  - User can regenerate (get a different result) or cancel
  - Applied cover image marked with subtle "AI-generated" indicator

- [x] **32.5.4** Text-to-speech UI (2026-03-05)
  - On text content cards: "Read Aloud" or speaker icon button
  - First time: if no voice preference set, show voice picker with samples
  - Generates audio and creates a linked audio content item
  - Audio player appears linked to the text (like transcription but reversed)
  - Subsequent taps play the already-generated audio (no re-generation)
  - Voice preference saved in user settings, changeable in AI settings page

#### Step 32.6 — Localization & Polish

- [x] **32.6.1** Add all AI-related strings to all 8 ARB files (2026-03-05)
  - Onboarding wizard step text, AI settings page, all button labels, loading states, error messages
  - Privacy explanations, voice names/descriptions
  - AI badge labels ("AI-generated", "Transcribed", etc.)

- [x] **32.6.2** Error handling and edge cases (2026-03-05)
  - Graceful handling when AI provider is unreachable (show retry option, not a crash)
  - Handle quota/rate limits from AI providers (queue requests, show "try again later")
  - Handle cases where transcription returns empty (audio too short, no speech detected)
  - Handle cases where metadata generation has no useful suggestions
  - Handle image generation content policy rejections gracefully
  - Timeout handling for long-running AI operations (transcription can take 30s+ for long audio)

- [x] **32.6.3** Version bump (2026-03-05)
  - Bump frontend and backend versions appropriately
  - Assess forced update requirement (new AI endpoints won't break old clients since features are additive)

### Phase 32B: AI Provider Expansion, Queue System & Voice Cloning

> **Expands the AI system from Phase 32 with multi-provider support, async queue processing, and voice cloning infrastructure.** Cloud providers (OpenAI) are ready to plug and play. Self-hosted providers (Ollama, Coqui XTTS, Local Whisper) are fully implemented — they just need a running server configured in admin. All AI jobs now process asynchronously via Laravel queue.

- [x] **32B.1** Foundation fixes (2026-03-05)
  - Fixed TTS capability key mismatch (standardized on 'tts' everywhere)
  - Made AIServiceManager methods static (isEnabled, resolve, isCapabilityAvailable, etc.)
  - Extended getModel() to be provider-scoped: `ai.{capability}.{provider}.model` with fallback
  - Added getProviderConfig() and getActiveProviderName() helpers

- [x] **32B.2** Queue infrastructure (2026-03-05)
  - Created `jobs` table migration (standard Laravel)
  - Created `ai_jobs` table — tracks status, input/output data, timestamps
  - Created `AiJob` model with markProcessing/markCompleted/markFailed helpers
  - Created `AiJobResource` for API responses
  - Added AI job notification types to AppNotification

- [x] **32B.3** Queue jobs & controller refactor (2026-03-05)
  - Created 4 job classes: TranscribeAudioJob, GenerateMetadataJob, GenerateCoverImageJob, TextToSpeechJob
  - All jobs: ShouldQueue, tries=1, timeout=300, onQueue('ai')
  - Rewrote AIController — all AI actions now dispatch jobs and return 202 with job_id
  - Added listJobs() and showJob() endpoints
  - applyMetadata, settings, capabilities remain synchronous

- [x] **32B.4** New providers — Ollama, Coqui, Local Whisper (2026-03-05)
  - OllamaTextGeneration — OpenAI-compatible API, no auth, JSON parse fallback
  - CoquiBase + CoquiTextToSpeech — self-hosted TTS via POST /api/tts
  - LocalWhisperTranscription — whisper-asr-webservice compatible, POST /asr
  - All registered in AIServiceManager::bootProviders()

- [x] **32B.5** Voice cloning infrastructure (2026-03-05)
  - VoiceCloneProvider contract with cloneAndSynthesize()
  - voice_samples table + VoiceSample model (consent tracking with timestamp + text snapshot)
  - voice_clone_enabled boolean on users table
  - CoquiVoiceClone provider (zero-shot cloning via reference audio)
  - VoiceCloneJob for async processing
  - VoiceSampleController (CRUD: list, upload with consent, delete)
  - Updated AIController with voiceClone() method + capabilities response

- [x] **32B.6** Admin UI restructure (2026-03-05)
  - Restructured AISettings from capability-centric to provider-centric layout
  - Sections: Global Settings, OpenAI (cloud), Ollama, Coqui XTTS, Local Whisper, Capability Routing
  - Per-provider model configuration + test connection buttons for each provider
  - Provider-scoped model settings: ai.{capability}.{provider}.model

- [x] **32B.7** Frontend async adaptation (2026-03-05)
  - AiJob model + VoiceSample model (Dart)
  - AICapabilities extended with voiceClone, voiceCloneEnabled, voiceSamples
  - AIService rewritten: _dispatchJob(), waitForJob() polling, voice sample CRUD
  - memory_detail_screen handlers updated for async dispatch + polling
  - VoiceSampleManager widget (upload with consent dialog, list, delete)
  - AI settings page extended with voice cloning section
  - Added file_picker dependency

- [x] **32B.8** Localization, polish & version bump (2026-03-05)
  - 26 new l10n keys across all 8 languages (voice cloning, AI jobs, providers)
  - "voice_cloning" added to support sections
  - Version bumped: Frontend 0.14.0, Backend 0.16.0

### Phase 33: App Design, UX & Style Guide

> **This phase is a collaborative brainstorming session before any code is written.** The AI should act as a seasoned senior app designer with deep experience in mobile UX, visual design, and user-centric product thinking. The goal is to establish a cohesive design language, improve the overall layout and flow, and ensure the app feels simple, intuitive, and delightful to use.

**IMPORTANT: Before starting this phase, request screenshots of every major screen in the app from the user.** You need to see the current state of the app visually to give meaningful design feedback. Ask for screenshots of at minimum:
- Home screen (memory list + timeline views)
- Side drawer / navigation
- Memory detail screen (with content: text, images, audio)
- Create/edit memory screen
- Groups screen + group detail
- Friends screen
- Settings screen + sub-pages
- Notifications screen / dropdown
- Profile screen
- Login / registration / onboarding screens
- Any other screens the user considers important

### Phase 33: Inline AI UX — Accessible AI Features *(completed 2026-03-05)*

> Make AI features seamlessly accessible inline, instead of buried in menus and long-press actions.

#### Memory Detail Screen — Inline AI Buttons
- [x] **33.1** Add visible "Narrate" button (sparkle icon + speaker) below text content blocks — replaces long-press TTS
- [x] **33.2** Add visible "Transcribe" button (sparkle icon + mic) below audio/video content — replaces long-press transcription
- [x] **33.3** Add "AI Generate" option in the cover image area alongside existing cover photo UI
- [x] **33.4** Remove AI features from the buried overflow/long-press menus (moved inline above)

#### Edit Memory Screen — AI Integration
- [x] **33.5** Cover photo picker: Add "Generate with AI" option next to camera/gallery choices
- [x] **33.6** Title field: Add AI suggest icon button that auto-fills from memory content
- [x] **33.7** Tags section: Add "AI Suggest Tags" button inline with tag chips
- [x] **33.8** Date section: Add AI suggest for time period detection from content

#### General UX Principles
- AI buttons use consistent `auto_awesome` sparkle icon
- Loading states with spinner during AI processing
- Title and date results shown in confirmation dialog (accept/reject before applying)
- Tag results added to suggestions section for user to pick
- Graceful fallback when AI is disabled or unavailable
- 5 new strings localized to all 8 languages

### Phase 33B: Bug Fixes — Uploads, Audio Playback, AI Content Linking

> **Bug fixes and improvements identified during testing of audio uploads, AI features, and memory display.**
> **Started:** 2026-03-06 | **Completed:** 2026-03-06

#### Upload Reliability

- [x] **33B.1** Fix audio upload retry getting stuck on "waiting" *(completed 2026-03-06)*
  - Added `POST /memories/content/{id}/refresh-upload-key` backend endpoint to reissue upload keys
  - Added `contentId` field to `PendingUpload` model for tracking which content record the upload belongs to
  - Upload service now refreshes upload key before each retry attempt when `contentId` is available
  - Updated all `addUpload()` call sites (create memory, WearOS sync, wearable receiver) to pass `contentId`
  - Backward-compatible: old persisted uploads without `contentId` use original key

#### Error Log UX

- [x] **33B.2** Add "Copy as JSON" button to the error log view *(completed 2026-03-06)*
  - Added "Copy as JSON" button to Filament admin error log detail view
  - Copies the **full error object** (id, user, device_type, severity, category, message, context, app_version, created_at) as formatted JSON to clipboard
  - Existing "Copy Context" and "Download as JSON" buttons retained for context-only operations

#### Audio Playback

- [x] **33B.3** Fix audio replay — cannot re-play or seek to start after playback ends *(completed 2026-03-06)*
  - `onPlayerComplete` now explicitly sets `_isPlaying = false` and resets position
  - `_togglePlayPause` now seeks to start before resuming when player state is `completed`
  - `_seekTo` now resumes playback after seeking when player state is `completed`

#### TTS Audio Metadata

- [x] **33B.4** Generate proper metadata for TTS-generated audio *(completed 2026-03-06)*
  - `TextToSpeechJob` now generates waveform data (50 amplitude samples) from TTS audio bytes
  - Stores duration from `SpeechResult` DTO in waveform metadata
  - Added `waveform` field to `MemoryContentResource` (was missing from API response)

#### Linked AI Content Display

- [x] **33B.5** Link transcribed text and TTS audio to their source entries *(completed 2026-03-06)*
  - Already implemented: migration `2026_03_05_200001` adds `linked_content_id`, `ai_generated`, `ai_provider`
  - Model relations `linkedContent()` / `derivedContents()` already exist
  - API resource already returns all three fields

- [x] **33B.6** Display linked content together in the memory view *(completed 2026-03-06)*
  - `MemoryContentList` now pre-processes contents to identify linked pairs via `linkedContentId`
  - Derived entries are rendered directly below their parent as a combined block
  - Single author attribution for the combined block (derived entries don't trigger new author headers)

#### AI Action Guards

- [x] **33B.7** Hide redundant AI actions on AI-generated content *(completed 2026-03-06)*
  - Transcribe button hidden for AI-generated audio (TTS output)
  - Read Aloud/TTS button hidden for AI-generated text (transcription output)
  - Uses `content.aiGenerated` flag in the content options bottom sheet

#### AI Content Replacement Logic

- [x] **33B.8** TTS should replace existing TTS audio for the same text entry *(completed 2026-03-06)*
  - Backend: `AIController::textToSpeech()` finds existing linked TTS audio and passes ID to job
  - `TextToSpeechJob` updates existing record (deletes old file, updates source/waveform) instead of creating duplicate
  - Frontend: confirmation dialog shown when existing TTS audio exists ("Replace Audio" / localized to 8 languages)

- [x] **33B.9** Transcription should replace existing transcription for the same audio entry *(completed 2026-03-06)*
  - Backend: `AIController::transcribe()` finds existing linked transcription and passes ID to job
  - `TranscribeAudioJob` updates existing text record instead of creating duplicate
  - Frontend: confirmation dialog shown when existing transcription exists ("Replace Transcription" / localized to 8 languages)

#### Transcription Formatting

- [x] **33B.10** Post-process transcription text through AI for formatting *(completed 2026-03-06)*
  - `TranscribeAudioJob` now post-processes raw transcription through text generation provider
  - Formatting prompt adds punctuation, paragraphs, fixes speech-to-text errors while preserving language
  - Falls back to raw text if text generation provider is unavailable

#### Memory Author Display

- [x] **33B.11** Show author icon and name on the first entry if created by the memory owner *(completed 2026-03-06)*
  - Changed author header condition to always show on first content entry (`prev == null`)
  - Applies regardless of whether there are multiple authors

#### Watch Transfer Indicator

- [x] **33B.12** Show visible indicator on phone when watch is sending audio *(completed 2026-03-06)*
  - Converted `WearableReceiverService` from plain `Provider` to `ChangeNotifierProvider` with `WatchTransferState` enum (idle/receiving/processing)
  - Created `WatchTransferIndicator` widget — compact banner with spinner, watch icon, and status text
  - Banner appears at the top of the home screen when a transfer is in progress
  - Tapping the banner opens a bottom sheet with transfer status and pending uploads list
  - 4 new l10n keys (`watchTransferReceiving`, `watchTransferProcessing`, `watchTransferComplete`, `watchTransferStatus`) across all 8 languages

#### Re-upload & Clipboard Bugs

- [x] **33B.13** Fix audio re-upload still failing with "Invalid upload key" (422) *(completed 2026-03-06)*
  - Root cause: race condition — upload succeeds server-side (pending upload deleted, source set), but client misses response and retries
  - Backend `refreshUploadKey()` now returns `200 { "already_uploaded": true }` instead of 422 when content already has source
  - Frontend `_refreshUploadKey()` throws `AlreadyUploadedException` on already-uploaded response
  - `_performUpload()` catches this and marks the pending upload as completed (no retry needed)

- [x] **33B.14** Fix "Copy as JSON" and "Copy Context" buttons not copying to clipboard *(completed 2026-03-06)*
  - Root cause: Filament Infolist `Action::extraAttributes()` with `x-on:click.prevent` didn't reliably attach Alpine handlers to the rendered button
  - Replaced with `ViewEntry` pointing to a custom Blade view (`filament/resources/error-log/copy-buttons.blade.php`)
  - Buttons use plain Alpine.js `x-on:click` with `navigator.clipboard.writeText()` — no Livewire interference
  - Download action retained as a Filament Action (server-side streamDownload works fine)

#### TTS-Text Content Grouping

- [x] **33B.15** Visually group TTS audio with its source text more clearly *(completed 2026-03-06)*
  - `_buildLinkedContent` now wraps parent + derived in a bordered `Container` with rounded corners and subtle background
  - `Divider` separates parent from derived content
  - Derived content shows AI badge inline (from `_buildContent`)

#### Admin Waveform Regeneration Tool

- [x] **33B.16** Add specific memory ID / content ID input to waveform regeneration tool *(completed 2026-03-06)*
  - Fixed `wire:model` → `wire:model.live` on radio buttons so scope changes are reactive in Livewire v3
  - ID input field now appears immediately when "Specific memory ID" or "Specific content ID" is selected
  - Run button disabled when memory/content scope selected but no ID entered

- [x] **33B.17** Show list of records with missing waveform data and allow individual regeneration *(completed 2026-03-06)*
  - Added "Show list" link next to missing count in stats row
  - `toggleMissingList()` loads and displays up to 100 missing records in a table
  - Each row shows content ID, memory ID/title, filename, created date, and a "Generate" button
  - `regenerateSingle(contentId)` runs `waveform:regenerate --content-id=X --force` synchronously via Artisan
  - Row removed from list after successful generation; stats refreshed

- [x] **33B.18** Fix waveform regeneration not working correctly *(completed 2026-03-06)*
  - Fixed `wire:model` → `wire:model.live` (scope radio buttons weren't syncing to server in Livewire v3)
  - Fixed background exec command (`> /dev/null 2>&1 &`) only works on Unix — added OS detection
  - On Windows, falls back to synchronous `Artisan::call()` instead of failing silently
  - `detectFfmpeg()` now uses `where` on Windows, `which` on Unix

- [x] **33B.19** Show progress indicator during waveform regeneration *(completed 2026-03-06)*
  - Progress bar already existed but was unreachable due to 33B.18 bugs (background exec failing, scope not syncing)
  - Now works: on Unix, background process + wire:poll shows live progress bar with counts
  - On Windows (sync fallback), result is shown immediately after completion
  - Individual regeneration buttons show "Running…" state via `wire:loading`

### Phase 34: Design rework

**Design principles to guide the brainstorm:**
- **Simple and intuitive** — a new user should understand the app within seconds, not minutes
- **Good feel and look** — the app should feel polished, modern, and emotionally warm (it holds people's memories)
- **Minimal cognitive load** — reduce clutter, hide complexity behind progressive disclosure
- **Consistent visual language** — spacing, typography, colors, iconography, and motion should follow a unified system
- **Accessible** — readable text sizes, sufficient contrast, touch targets, screen reader support

- [ ] **34.1** Review current app design (brainstorm)
  - Review all screenshots provided by the user
  - Assess the current visual design: consistency, spacing, typography, color usage, iconography
  - Identify screens that feel cluttered, confusing, or visually inconsistent
  - Note any UX friction points (too many taps, unclear navigation, hidden features)
  - Document findings as a design audit summary

- [ ] **34.2** Define style guide and design language (brainstorm)
  - Establish typography hierarchy (heading sizes, body text, captions, labels)
  - Define spacing system (consistent padding/margins using a base unit, e.g., 4px/8px grid)
  - Define color usage rules (when to use primary, secondary, surface, error colors)
  - Define card/container styles (elevation, border radius, padding)
  - Define icon usage (outline vs filled, size consistency, when to use icons vs text)
  - Define button styles (primary, secondary, text, icon buttons — when to use each)
  - Define animation/transition guidelines (page transitions, micro-interactions, loading states)

- [ ] **34.3** Redesign key screens and flows (brainstorm)
  - Based on the audit, propose specific layout improvements for problem screens
  - Sketch or describe improved layouts (ASCII mockups, wireframe descriptions, or reference examples)
  - Focus on the core user journey: open app → browse memories → view a memory → create a memory
  - Ensure the emotional tone matches the product (warm, personal, nostalgic — not clinical or corporate)

- [ ] **34.4** Navigation and information architecture review (brainstorm)
  - Evaluate the side drawer + FAB pattern — is it working well? Are important features buried?
  - Review the settings page structure — too many sub-pages? Too few?
  - Review how users discover features (tags, groups, sharing, time periods, privacy)
  - Propose improvements to the navigation hierarchy if needed

- [ ] **34.5** Implement agreed design changes
  - Apply the style guide changes agreed upon in the brainstorm
  - Update theme configuration (typography, colors, spacing)
  - Refactor screens that were identified for redesign
  - Ensure consistency across all screens
  - Test on both light and dark themes

### Phase 35: Privacy Data Self-Hosting (Future)

> Allow users to store metadata, upload audit trails, and location data on their own self-hosted server — extending the existing external storage support beyond just media files.

**This phase requires design/brainstorming before implementation. Do not start without consulting the user.**

- [ ] **35.1** Design: Scope and architecture for self-hosted metadata
  - Define which data types can be self-hosted beyond media: metadata (titles, dates, tags), upload audit trails, location data, notification history
  - Design the sync protocol: how does the app write/read metadata to the user's storage vs. the Memory Lane server?
  - Decision: full replacement (all metadata on user's server) vs. selective (user chooses which data types to self-host)?
  - Decision: conflict resolution when data exists in both places
  - Consider impact on features that depend on server-side queries (search, filtering, timeline)

- [ ] **35.2** Design: API and storage format for self-hosted data
  - Define the file/folder structure for metadata stored on external storage providers
  - Define the sync/push/pull mechanism (e.g., JSON files, SQLite database, or structured folders)
  - Consider offline support and eventual consistency
  - Ensure compatibility with all supported storage providers (Dropbox, FTP/SFTP, SMB)

- [ ] **35.3** Implementation: Self-hosted metadata storage
  - Build the read/write layer for metadata on external storage
  - Implement sync logic between local app state and self-hosted storage
  - Add UI in Privacy Center / Storage settings to enable per-data-type self-hosting
  - Update the privacy information to reflect the new data residency options

### Phase 36: S3-Compatible Object Storage & Presigned Audio URLs

> Migrate media storage from the local filesystem to a European S3-compatible provider (Scaleway or OVHcloud) and replace the current audio streaming proxy with presigned URLs. This eliminates server bandwidth costs for audio playback and scales media storage independently of the application server.

**Decision required before starting: choose storage provider (Scaleway recommended, OVHcloud for lower egress cost).**

- [ ] **36.1** Add `S3StorageProvider` implementing `StorageProviderInterface`
  - Implement all interface methods using `league/flysystem-aws-s3-v3` (already supported by Laravel) with a custom endpoint
  - Register `'s3'` in `StorageManager::$providers`
  - Configurable via `UserStorageSetting` (provider_type = `'s3'`, config = endpoint/key/secret/bucket/region)

- [ ] **36.2** Configure platform-level S3 as the server default
  - Add S3 credentials to `.env` for the platform default storage
  - Update `StorageManager::default()` to return `S3StorageProvider` when S3 env vars are set
  - Migrate existing media files from local disk to S3 (one-off artisan command)
  - Verify `RegenerateWaveforms` command still works (it downloads to temp file for remote providers ✓)

- [ ] **36.3** Presigned URLs for audio playback
  - Add `presignedUrl(string $path, int $minutes = 60): ?string` to `StorageProviderInterface`
  - Implement in `S3StorageProvider` using AWS SDK presigned requests; return `null` in all other providers
  - Update `MemoryContentResource` to include `presigned_url` when available
  - Update Flutter `MemoryAudioPlayer` to prefer `presigned_url` over the stream endpoint when present
  - **Benefit:** audio plays directly from S3, bypassing the Laravel server entirely — eliminates proxy bandwidth cost

- [ ] **36.4** Storage lifecycle policies
  - Configure Scaleway/OVHcloud lifecycle rules to transition objects older than N years to cold storage
  - Verify presigned URLs and retrieval still work for cold-tier objects

- [ ] **36.5** Test and verify
  - Upload audio/image/video → verify it lands in S3
  - Play audio → verify presigned URL is used (no proxy request through Laravel)
  - Test `RegenerateWaveforms` admin tool against S3-stored files
  - Test file deletion removes from S3


<!-- NEW PHASES GO HERE -->


### Phase ??: End-to-End Encryption
## IMPORTANT: DO NOT START THIS WITHOUT FIRST CONSULTING ME

> Zero-knowledge encryption so that memory content cannot be read by the server or us. Only the user's master key can decrypt.

**Needs brainstorming before implementation - key design questions below.**

- [ ] **??.1** Design: Encryption architecture decisions
  - Key derivation: master password → encryption key (PBKDF2/Argon2)
  - Per-content encryption keys, wrapped (encrypted) by the user's master key
  - User key pair (public/private) for future key exchange when sharing
  - Decision: separate master password vs. derive from login password?
  - Decision: what happens if master password is lost? (unrecoverable by design, but UX needs to be very clear)
  - Decision: how to handle thumbnails/previews of encrypted content? (encrypted thumbnails? generic icons?)
  - Decision: how to handle search of encrypted content? (client-side only? encrypted indexes?)
- [ ] **??.2** Design: Sharing encrypted memories
  - Option A (simple, first): encrypted memories cannot be shared - must decrypt first or mark as unencrypted
  - Option B (advanced, later): key exchange - re-encrypt content key with recipient's public key, so both can decrypt
  - Option C: store multiple encrypted copies of the content key (one per authorized user)
  - This step is pure design/brainstorming - no code yet
- [ ] **??.3** Backend + Frontend: Personal encryption (non-shared)
  - Implement master key setup flow (first time: set master key, derive encryption key)
  - Client-side encrypt/decrypt using established library (libsodium/NaCl or AES-256-GCM)
  - Encrypted content stored as opaque blobs - server never sees plaintext
  - Memory/content marked as `is_encrypted` in database
  - Frontend: unlock flow with master key → derive key → decrypt content on device
  - Must work with all storage providers (Phase 9) - encrypted blobs stored the same way
- [ ] **??.4** Backend + Frontend: Shared encryption (if Option B/C chosen)
  - Key exchange protocol implementation
  - Each user's public key stored on server, private key encrypted with their master key
  - When sharing: encrypt content key with recipient's public key
  - Recipient decrypts content key with their private key, then decrypts content
  - Revocation: re-encrypt content key without the revoked user's public key

<!-- NEW PHASES GO HERE -->

---

## Backlog

> **Unordered pool of ideas and improvements.**
> Items here are not committed to. They can be promoted into phases at any time.

### Advanced Features (requires brainstorming)
- **AI-driven tagging** - Automatically suggest tags for memories using AI analysis of images (object recognition, scene detection), text content (keyword extraction, topic classification), titles, dates, and location. **Must have clear opt-in/out:** the first time the feature is available, the user is prompted with a friendly explanation of what it does, how it works (what data is sent where), and explicit consent buttons (Enable / Not now / Never ask again). Respects Core Principles — if the user's storage mode is `external_only`, AI analysis should happen client-side or not at all. Settings page should show AI tagging toggle with clear data usage explanation. Consider on-device ML models (e.g., TFLite) for image analysis to avoid sending content to external services.
- **Voice transcription** - Transcribe audio parts of memories to text (speech-to-text service needed)
- **AI read-aloud** - Text-to-speech for written parts, plays actual audio for audio parts, seamless transitions between them
- **AI voice profiles** - Optional customizable voice profiles (e.g., age-based) for reading memories aloud
- **Mood music** - Attach background music to memories (YouTube link paste, possibly Spotify later)

### UX Simplicity Principle (#22)
- Features like tags, hiding, and advanced filters must not clutter the main UI
- The app must feel fast and simple at all times
- Advanced options belong in secondary menus (long-press, "..." menu, edit screens)
- This is a cross-cutting concern that applies to all phases

### Performance & Optimization
- API response caching
- Lazy loading for images in content lists
- WebP thumbnails where supported
- Frontend performance profiling

### Deployment & DevOps
- Document backend deployment process
- Document frontend build/release process (APK, iOS, web)
- Set up staging environment
- Error monitoring/logging service integration
- Automated database backups

### AI Usage & Cost Tracking
- **AI usage dashboard** — Display token usage and cost statistics in AI Settings admin page and main dashboard
- Track tokens used (input/output), cost per request, per model
- Aggregated views: total, monthly, per-user (median)
- Cost breakdown by capability (text gen, TTS, transcription, image gen)
- Historical trends (monthly charts)

### AI Image Generation Content Policy
- Strict content moderation rules for AI image generation
- No violence, explicit content, real likenesses, copyrighted characters
- Pre-check prompts before sending to DALL-E / image generation provider
- Admin-configurable blocked terms list in Filament panel
- Graceful handling of provider content policy rejections (user-friendly error message)
- Audit log of generated image prompts for admin review

### Other Ideas
- Export memories as PDF or video montage
- Calendar integration - memories linked to dates (partially covered by Phase 11)

---

## Change Log

> Record significant changes here so future sessions have context.

| Date       | Change Description                                |
|------------|---------------------------------------------------|
| 2026-02-09 | PROJECT.md created. Initial project analysis done. |
| 2026-02-09 | Restructured plan: only Phase 1 is active. All other items moved to Backlog for brainstorming. |
| 2026-02-09 | Added Session Startup Checklist. Phase 1 now includes framework upgrades and local dev setup. |
| 2026-02-09 | Added Code Guidelines section covering backend (base model pattern, interfaces, API resources) and frontend (composable widgets, Provider, theming, localization). |
| 2026-02-09 | Feature brainstorm complete. Defined Phases 2-8 from user's feature list. Advanced features (timeline, AI voice, mood music) moved to backlog for later brainstorming. |
| 2026-02-09 | **Step 1.1 complete:** Laravel upgraded from 11.44.0 to 12.50.0. PHPUnit upgraded from 10.x to 11.x. No breaking changes found. |
| 2026-02-09 | Enabled PHP extensions (fileinfo, gd, pdo_mysql, intl, exif, mysqli, zip) in c:\php\php.ini for local development. |
| 2026-02-09 | Fixed frontend `intl` constraint from `^0.19.0` to `^0.20.2` (Flutter SDK pins intl 0.20.2). |
| 2026-02-09 | **Step 1.2 complete:** Flutter deps upgraded (94 packages). Major bumps: audioplayers 6, record 6, local_auth 3, connectivity_plus 7, mime 2. Fixed connectivity_plus API change and l10n imports. |
| 2026-02-09 | **Phase 1 complete:** Steps 1.3-1.8 done. Backend README rewritten, api_config.dart configured for local dev (http + 127.0.0.1:8000), .env.example cleaned up, debug_config reviewed, no hardcoded URLs found. |
| 2026-02-09 | **Step 2.1 complete:** Fixed white bar at login screen via `AnnotatedRegion<SystemUiOverlayStyle>`. Fixed deprecated `colorScheme.background`/`onBackground` across auth screens. Fixed `local_auth` 3.x `AuthenticationOptions` removal. Updated `theme_config.dart` deprecated `background:` param. |
| 2026-02-09 | **Step 2.2 complete:** Rewrote `LanguageProvider` - loads saved language on init, persists selection, defaults to system locale. Added "System default" option to language selector. |
| 2026-02-09 | **Step 2.3 complete:** Added `RecordingData.downsample()` to cap waveform at 50 points. Both save paths now downsample before returning. Added error handling to `parseWaveform()`. |
| 2026-02-09 | **Step 2.4 complete:** Wired `MemoryAudioPlayer` into `MemoryContentList`. Renamed `MemoryContent.source` → `streamUrl` to match backend. Added token query param auth for stream endpoint (audioplayers can't send headers). Backend stream route moved outside auth middleware with manual token validation. |
| 2026-02-09 | **Step 2.5 complete:** Fixed audio upload flow: backend upload key length (16→64 chars), frontend `UploadItem` now carries `uploadKey`, removed duplicate content creation POST after upload, fixed silent error swallowing in `_uploadAudio()`, added pending upload cleanup from SharedPreferences. |
| 2026-02-09 | **Step 2.6 complete:** Added `extendBody: true` to Scaffold, bottom padding to ListView, safe area handling to CustomBottomNav. |
| 2026-02-09 | **Step 2.7 complete / Phase 2 done:** Removed ~170 lines dead code from home_screen.dart, consolidated duplicate UploadStatus/UploadItem, replaced WillPopScope→PopScope, fixed all withOpacity→withValues(alpha:) across 13 files (~35 instances), removed unused imports. |
| 2026-02-09 | **Phase 9 updated:** SMB notes expanded (LAN-only indicator, VPN suggestion, unavailable state). Migration wizard split into separate sub-phase (9D). Storage provider chosen at app setup. Thumbnail caching with opt-out setting added. Contributor proxy: owner storage full notification added. |
| 2026-02-09 | **Phase 11 added:** Payment & Business Model Baseline - user tier system, feature gating, limit awareness UI, usage tracking. All users "premium for life" during development. |
| 2026-02-09 | **Core Principles section added:** Privacy & Data Ownership principles documented as non-negotiable project foundation. Users own their data, zero-knowledge encryption, minimal collection, transparency, security by default. Referenced in Code Guidelines and Notes. |
| 2026-02-10 | **Step 3.1 complete:** Complete rewrite of pending uploads system. New single-source-of-truth architecture (SharedPreferences + ChangeNotifier). Unified `PendingUpload` model replaces `UploadItem`+`PendingAudioUpload`. Exponential backoff retries (5 max). Connectivity-aware queue processing. Real upload progress tracking. Android MethodChannel wired for native push notifications with progress bars. New `UploadStatusBanner` widget on home screen. Deleted `pending_audio_upload.dart` and `local_storage_service.dart`. Removed all orphaned `UploadService()` instances and `checkPendingUploads()` calls. 11 new l10n keys across 8 languages. |
| 2026-02-10 | **Step 3.2 complete:** Memory list filters & sorting. Backend: `content_types` field in MemoryListResource, sort/order/content_type/search/from/to query params on both user memory endpoints. Frontend: `contentTypes` in Memory model, query params in `getUserMemories()`, enhanced `SortDialog` (4 options with checkmark), new `FilterBottomSheet` (content type chips + date range pickers), `FilterState` class, badge indicator on filter button. 12 new l10n keys across 8 languages. |
| 2026-02-10 | **Step 3.3 complete:** Memory search. Backend: extended search to title + `content` + `memory_contents.text` with grouped `orWhere`/`orWhereHas`. Frontend: rewrote `SearchScreen` with debounced input (400ms), 3-state UI (empty/loading/results), content type icons in results. Wired into `HomeScreen` replacing placeholder. 3 new l10n keys across 8 languages. |
| 2026-02-10 | **Step 3.4 complete / Phase 3 done:** Image & video capture/upload as memory content. Backend: `thumbnail` migration, opened gates in MemoryContent.php for images, image_url/thumbnail_url accessors, image upload with thumbnail generation via ImageUpload trait, disk-aware streamMedia. Frontend: `video_player` dependency, MemoryContent model updated, `pickVideo()` in ImageHelper, 4-option content modals, `MemoryContentEditor` with mediaPath, image/video add methods + upload queue wiring, `MemoryVideoPlayer` widget, `MemoryContentList` with image display (full-screen InteractiveViewer) + video display. 5 new l10n keys across 8 languages. |
| 2026-02-09 | **Step 4.1 complete:** Groups system backend. 3 migrations (groups, group_memory, group_user tables). Group model with owner/memories/sharedUsers relationships. GroupController with 7 endpoints (CRUD + add/remove memory). StoreGroupRequest/UpdateGroupRequest validation (hex color regex). GroupListResource (with memory_count)/GroupResource (with memories + shared_users). MemoryListResource/MemoryResource updated with groups field. Eager loading added to MemoryController::index and user.php routes. Memory/User models updated with groups relationships. |
| 2026-02-11 | **Step 4.1.1 complete:** Upgraded Kotlin from 1.8.22/1.9.0 → 2.1.0 in `android/settings.gradle.kts` and `android/build.gradle`. Flutter was warning Kotlin 1.9.0 support would be dropped. |
| 2026-02-11 | **Phase 12 added:** Memory Dating & Time Periods — flexible temporal placement (exact date, month, year, or range), user-defined time periods (e.g. "Childhood" = 1988–2000), timeline floating behavior for loose dates. 6 steps covering backend schema, time periods CRUD, frontend date picker, filtering, and timeline integration. |
| 2026-02-11 | **Step 4.2 complete:** Frontend Groups UI. Replaced Search tab with Groups tab (folder icon). Created `Group` model, `GroupService` (7 API methods), `GroupsScreen` (2-column grid with colored cards, create/edit bottom sheet with 12-color palette), `GroupDetailScreen` (memory list, add/remove memories, edit/delete via overflow menu). 20 new l10n keys across 8 languages. Step 4.3 (group colors) partially completed — color picker and color-accented UI already implemented. |
| 2026-02-11 | **Step 4.2.1 complete:** Fixed filter toggle disappearing on empty results. Restructured `memory_list.dart` so header with filter/sort buttons always renders, empty state is inside the content area. |
| 2026-02-11 | **Step 4.2.2 complete:** Fixed bottom bar overlapping settings content. Added `bottom: 100 + safe area` padding to `settings_screen.dart`. |
| 2026-02-11 | **Step 4.2.3 complete:** Fixed save button not showing on edit. Added `setState()` around `_hasChanges = true` in `_loadExistingContent()` and added `onChanged` to title field in `create_memory_screen.dart`. |
| 2026-02-11 | **Step 4.2.4 complete:** Fixed 405 error on memory update. Removed `_method=PUT` from form data in `memory_service.dart` — backend route is POST, not PUT. |
| 2026-02-11 | **Step 4.2.5 complete:** Added all missing translations across 8 languages. DA: 62 keys, DE: 51 keys, ES/FR/JA/KO/ZH: 36 keys each. Fixed `@byAuthor` metadata type conflict in DA/DE ARB files. |
| 2026-02-11 | **Step 4.3 complete:** Group colors already implemented in 4.2. Added color-accented memory list items in GroupDetailScreen (left border, tinted avatar, colored fallback icons). |
| 2026-02-11 | **Step 4.4 complete:** Moved search from standalone tab into memory list header. Inline expandable search field with debounce. Deleted `search_screen.dart`. |
| 2026-02-11 | **Step 4.5 complete:** Tags system. Backend: `tags` + `taggables` tables, Tag model, TagController (CRUD + associations), resources, routes, search integration. Frontend: Tag model, TagService, TagPickerModal, tags display on memory/group detail screens, tag filter in FilterBottomSheet. 16 new l10n keys across 8 languages. |
| 2026-02-11 | **Step 4.5.1 complete / Phase 4 done:** Fixed memory save bug. Backend: `update()` now processes content changes (delete old + create new, with DB transaction and upload keys). `StoreMemoryRequest` validates `contents` for updates, added `prepareForValidation()` for JSON string decoding. Frontend: `updateMemory()` sends JSON POST with `contents` array (not `content` string via MultipartRequest). Fixed duplicate cover image upload. Removed debug prints. |
| 2026-02-13 | **Step 5.1 complete:** Backend Friends System. 2 migrations (`friendships`, `friend_invites`), 2 models (`Friendship`, `FriendInvite`), `FriendController` with 13 endpoints (friend list, send/accept/decline/cancel requests, remove friend, user search, invite CRUD + redeem). 4 resources, 2 form requests. User search uses LIKE for name, exact match for email (privacy). Auto-accepts reverse pending requests. Invite redeem in DB::transaction. Routes in `friend.php`. |
| 2026-02-13 | **Step 5.2 complete:** Frontend Friends UI. `FriendsScreen` with 4-tab TabBar (Friends, Requests, Search, Invites) accessible from profile. 6 models in `friend.dart`, `FriendService` with 13 methods, reusable `FriendTile` widget. Friends list with remove, requests with accept/decline/cancel, debounced search (500ms) with auto-accept detection, invite links with clipboard copy and redeem. Profile screen updated with Friends button + Badge for pending count. Backend fix: `FriendController@index()` passes `friendship_id` to `FriendListResource`. 38 new l10n keys across 8 languages. |
| 2026-02-14 | **Step 5.3 complete:** Backend memory & group sharing with permissions. Migration adds `permission` column to `memory_user` pivot (owner/contribute/view). `ChecksFriendship` trait for reusable friendship checks. Memory model gets `owner()`, `userPermission()`, `canAccess()`, `effectivePermission()` helpers. **Critical fix:** Authorization added to ALL MemoryController endpoints (index/show/update/addContent/streamMedia previously had NO access checks). Permission-aware `canModifyContent()` in trait. 3 memory sharing endpoints + 3 group sharing endpoints (share/update/revoke, owner-only, friends-only). Auto-attach on contribute (group-only users get added to memory_user). `GET /user/memories` now includes group-shared memories. 4 Form Request classes, 6 new routes. |
| 2026-02-14 | **Step 5.4 complete:** Frontend sharing & permissions UI. New widgets: `ShareWithModal` (friend picker with permission selector), `ManageSharesSection` (shared user list with permission management + revoke). Models updated: `Memory.isShared`, `User.permission`, `Group.sharedUsers`/`GroupSharedUser`. Services: 3 sharing methods each for `MemoryService` and `GroupService`. Memory detail: real share menu replaces stub, "Shared with" section, permission-aware options menu (edit hidden for viewers, delete owner-only). Group detail: share button in AppBar (owner-only), shared users section. Memory list: shared indicator icon (people_outline), permission shown in contributors dialog. Filter: "Shared with me" FilterChip with client-side `isShared` filtering. 15 new l10n keys across 8 languages. |
| 2026-02-14 | **Step 5.5 complete:** Group memory contributions. Backend: `GroupController::addMemory()` allows contributors (not just owners) to add their own memories to groups. Frontend: Permission-aware `GroupDetailScreen` — FAB hidden for view-only users, edit/delete owner-only, remove button owner-only. "Add Memory" dialog now shows two options: add existing memory (picker) or create new memory. `CreateMemoryScreen` accepts optional `groupId` to auto-add newly created memory to the group. 2 new l10n keys across 8 languages. |
| 2026-02-15 | **Step 6.1 complete:** Backend personal flag. Migration adds `is_personal` boolean to `memories` and `groups`. `include_personal` query param on index endpoints (excluded by default). `PATCH /memories/{id}/personal` and `PATCH /groups/{id}/personal` toggle endpoints (owner-only). All 4 resources updated with `is_personal` field. |
| 2026-02-15 | **Step 6.2 complete:** Frontend personal memory flow. `PrivacyProvider` manages unlock state + PIN via `flutter_secure_storage`. `PinDialog` widget (set/change/verify 4-digit PIN). "Mark as Personal" in memory detail and group detail menus (owner-only, with security check). Models updated with `isPersonal`, services with `togglePersonal()`. |
| 2026-02-15 | **Step 6.3 complete / Phase 6 done:** Frontend unlock flow. Privacy section on profile screen (unlock/lock + PIN setup). Biometrics-first unlock with PIN fallback. Personal items appear with lock icon when unlocked (`include_personal=1` to API). "Personal only" filter chip in FilterBottomSheet. Groups screen passes `includePersonal`. Session-based locking. 21 new l10n keys across 8 languages. `flutter analyze`: 0 errors (135 pre-existing warnings/info). |
| 2026-02-14 | **Step 5.6 complete / Phase 5 done:** Content requests. Backend: `content_requests` migration + `ContentRequest` model (code-based, directed or link-based, allowed types, expiration). `ContentRequestController` with 6 endpoints (index, store, show, showByCode, fulfill, cancel). `ContentRequestResource`, `StoreContentRequestRequest`, new routes file. Fulfill auto-grants contribute permission on the memory. Frontend: `ContentRequest` model + `ContentRequestService` (5 methods). `ContentRequestsSheet` (view/manage requests per memory, copy code, cancel). `CreateContentRequestSheet` (friend picker, message, type filter, expiration). `FulfillRequestScreen` (code input, request details, contribute button). "Request Content" in memory detail options menu (owner-only). "Redeem Content Request" button on profile screen. 21 new l10n keys across 8 languages. |
| 2026-02-16 | **Step 7.1 complete:** Backend notification system. 2 migrations (`notifications`, `device_tokens`), `AppNotification` model with `notify()` factory (respects user preferences), `DeviceToken` model, `NotificationController` with 9 endpoints (list, unread-count, mark-read, mark-all-read, delete, settings get/update, device-token register/remove). `CreatesNotifications` trait wired into 4 controllers (FriendController, MemoryController, GroupController, ContentRequestController). Route model binding for `{notification}` → `AppNotification`. 7 notification types. |
| 2026-02-16 | **Step 7.2 complete:** Frontend in-app notification UI. `AppNotification` model + `NotificationResponse`, `AppNotificationService` (9 methods). `NotificationsScreen` with paginated list, pull-to-refresh, infinite scroll, swipe-to-delete, type-specific icons/colors, relative time display, tap-to-navigate. Notification bell icon with Badge in profile screen AppBar. 3 new l10n keys across 8 languages. |
| 2026-02-16 | **Step 7.3 complete / Phase 7 done:** Notification settings. Backend: `notification_preferences` JSON column on users, `isNotificationEnabled()`/`isNotificationQuiet()` helpers, preferences checked before creating notifications. Frontend: `NotificationSettings` widget in settings screen with global toggle, per-type enable/disable switches, per-type quiet mode FilterChip, optimistic UI updates. 10 new l10n keys across 8 languages. `flutter analyze`: 0 errors (135 pre-existing warnings/info). |
| 2026-02-16 | **Step 8.1 complete:** API URL versioning. Changed route prefix from `api` to `api/v1` in `RouteServiceProvider`. Updated frontend `ApiConfig.baseUrl` to append `/v1`. Updated hardcoded stream URL in `MemoryContent::getStreamUrlAttribute()`. Updated doc comment URLs. All 78 routes now under `/api/v1/`. |
| 2026-02-16 | **Step 8.2 complete / Phase 8 done:** Admin panel with Filament v3. Installed `filament/filament` v3.3. Created `AdminPanelProvider` at `/admin`. Migrations: `is_admin` + `is_banned` on users, `is_flagged` on memories. User model implements `FilamentUser` (admin-only access). `UserResource`: list/edit/ban/unban/reset password. `MemoryResource`: list/view/flag/unflag/delete. 3 dashboard widgets: StatsOverview (4 stat cards), ContentTypeChart (doughnut), UserGrowthChart (30-day line). Ban check added to `AuthController::loginUser()` (403 for banned users). |
| 2026-02-16 | **Step 9.1 complete:** Storage provider abstraction. `StorageProviderInterface` (13 methods), `BaseStorageProvider` (path normalization, traversal prevention), `LocalStorageProvider` (wraps Laravel filesystem with auto disk resolution). `StorageManager` singleton resolves provider per user with caching. `user_storage_settings` migration + `UserStorageSetting` model (encrypted config). |
| 2026-02-16 | **Step 9.2 complete:** Storage manifest system. `StorageManifest` manages `memory_lane_manifest.json` for external providers. Atomic writes (tmp → rename), integrity verification (missing/orphaned files), `DO_NOT_ALTER_THESE_FILES.txt` warning. |
| 2026-02-16 | **Step 9.3 complete / Phase 9A done:** Local storage refactor. `ResolvesStorage` trait resolves provider per memory owner. `MemoryController` updated: `uploadMediaFile()`, `streamMedia()`, and `update()` cleanup use storage abstraction. Model accessors unchanged (identical behavior for local). No migration needed for existing users. |
| 2026-02-16 | **Step 9.4 complete:** Dropbox integration. Backend: `DropboxStorageProvider` (spatie/flysystem-dropbox), `DropboxOAuthController` (OAuth2 code flow + token refresh), `StorageSettingsController` (CRUD + test + disconnect), `config/services.php` Dropbox config, 7 new routes. Frontend: `StorageService`, `StorageProvider` (ChangeNotifier), `StorageSettings` widget in settings screen, OAuth flow (browser → paste code → token exchange). 17 new l10n keys. Fixed `StorageManager` missing import for `DropboxStorageProvider`. |
| 2026-02-16 | **Step 9.5 complete:** FTP/sFTP/FTPS integration. Backend: `FtpStorageProvider` (league/flysystem-ftp + league/flysystem-sftp-v3), protocol-aware adapter creation, `FtpConnectionController` (validates before saving). 1 new route. Frontend: `connectFtp()` in service/provider, FTP connection dialog with SegmentedButton protocol selector, auto-port switching. 7 new l10n keys. |
| 2026-02-16 | **Step 9.6 complete:** SMB integration. Backend: `SmbStorageProvider` (icewind/smb + jerodev/flysystem-v3-smb-adapter), `SmbConnectionController` (validates before saving). 1 new route. Frontend: `connectSmb()` in service/provider, SMB connection dialog with server/share/domain fields, LAN-only warning. 6 new l10n keys. |
| 2026-02-16 | **Step 9.7 complete / Phase 9B done:** Frontend storage settings UI. `StorageSettings` widget in settings screen with current provider display, Dropbox/FTP/SMB connect buttons, connection test, disconnect with confirmation. `StorageProvider` ChangeNotifier registered in `main.dart`. Deferred: folder browser, thumbnail caching, first-launch provider choice. |
| 2026-02-16 | **Step 9.9 complete / Phase 9E done:** Contributor upload proxy already implemented via `ResolvesStorage` trait — `storageForMemory()` resolves by memory owner, not uploader. `uploadMediaFile()` pushes files to owner's storage provider. Deferred: queue-based retry, storage-full notifications. |
| 2026-02-16 | **Step 9.8 complete / Phase 9 done:** Storage migration wizard. Backend: `StorageMigration` model (`storage_migrations` table) with encrypted source/target configs, file manifest (JSON), progress counters. `StorageMigrationController` with 7 endpoints (status/start/process/complete/rollback/cancel/cleanup). Batch-based copy with size verification. Frontend: `MigrationStatus` + `MigrationBatchResult` models, `StorageMigrationWizard` full-screen stepper (select → configure → confirm → migrate → done), live progress bar, rollback on error, optional source cleanup. "Migrate Storage" button in storage settings. 27 new l10n keys across 8 languages. `flutter analyze`: 0 issues. |
| 2026-02-16 | **Step 10.1 complete:** User tier system. `user_tiers` table + `tier_id` FK on users. `UserTier` model with feature/limit helpers. `UserTierSeeder` (free: 500MB/50 memories/3 contributors; premium: unlimited, is_default). `User::effectiveTier()` with graceful fallback chain. Filament UserResource updated with tier selector + badge. |
| 2026-02-16 | **Step 10.2 complete:** Feature gating system. `canUse()`, `canCreateMemory()`, `hasStorageSpace()`, `canAddContributor()`, `tierInfo()` on User model. `CheckTierFeature` middleware (403 with `limit_reached` type). Applied `tier.feature:external_storage` to storage connect routes. Memory creation + contributor gating in MemoryController. `GET /user/tier` endpoint. |
| 2026-02-16 | **Step 10.3 complete:** Frontend limit awareness UI. `TierInfo` model + `UserProvider.loadTierInfo()`. `TierInfoSettings` widget with tier badge, storage/memory progress bars, contributor limit, feature chips. `LimitReachedException` thrown by `createMemory()` and `shareMemory()` on 403 limit_reached. 14 new l10n keys across 8 languages. |
| 2026-02-16 | **Step 10.4 complete:** Usage tracking. `storage_used_bytes` on users, `file_size` on memory_contents. Incremental tracking on upload/delete/memory-destroy. `User::recalculateStorageUsed()` + `php artisan storage:recalculate` command. |
| 2026-02-16 | **Step 11.1 complete:** Flexible memory date model. Migration adds `memory_date_start`, `memory_date_end`, `date_precision` (day/month/year/range) to memories. Memory model: fillable, date casts, `getFormattedDateAttribute()` accessor. StoreMemoryRequest validation rules. MemoryResource + MemoryListResource include date fields. MemoryController store/update save date fields. |
| 2026-02-16 | **Step 11.2 complete:** Time periods. `time_periods` table (user_id, name, start_date, end_date, color). `TimePeriod` model, `TimePeriodController` (full CRUD with ownership checks), `User::timePeriods()` relationship, 5 routes. |
| 2026-02-16 | **Step 11.3 complete:** Frontend memory date picker. `TimePeriod` model + `TimePeriodService` (CRUD). Memory model extended with 4 date fields. `MemoryService` sends date params on create/update. `MemoryDatePicker` widget (precision chips, adaptive pickers, year dialog, time period quick-picks). Integrated into `CreateMemoryScreen`. Detail + list views show `formattedDate`. 9 new l10n keys across 8 languages. |
| 2026-02-16 | **Step 11.4 complete:** Time periods management UI. `TimePeriodSettings` widget in settings screen — list with color avatars + date ranges, create/edit bottom sheet (name, dates, 12-color palette), delete with confirmation. 12 new l10n keys across 8 languages. |
| 2026-02-16 | **Step 13.4 complete:** Drag-and-drop content reordering. Backend: `MemoryResource.getOrderedContents()` sorts by `memory_content_order` positions with fallback. New `POST /memories/{memory}/contents/reorder` bulk endpoint. Frontend: `MemoryService.reorderContents()`. `CreateMemoryScreen` uses `ReorderableListView.builder` with drag handles + `proxyDecorator` elevation. `MemoryContentEditorWidget` accepts optional `dragHandle` widget. |
| 2026-02-16 | **Step 13.5 complete:** Location tagging. Backend: migration adds `latitude`/`longitude`/`location_name` to memories, model/resource/request/controller updated. Frontend: `LocationPicker` widget with geolocator + geocoding packages, location displayed on detail screen. Android + iOS location permissions added. 5 l10n keys across 8 languages. Map view deferred (needs API key). |
| 2026-02-16 | **Step 14.1 complete:** Backend controller unit tests. 6 test files (Auth, Memory, Group, Friend, Tag, Notification) — 57 tests, 153 assertions, all passing. **Bugs found and fixed:** (1) `MemoryController::update()` had transaction leak — early 403 returns inside `DB::beginTransaction()` without rollback. (2) Migration SQLite compat: `rename_image` migration guarded with `Schema::hasColumn()`, `reorganize_media_files` made driver-agnostic for `FOREIGN_KEY_CHECKS`. (3) MemoryFactory referenced removed `content` column. (4) UserFactory hash incompatible with BCRYPT_ROUNDS=4. Added APP_KEY to phpunit.xml. |
| 2026-02-16 | **Step 14.2 complete:** Backend model unit tests. `UserModelTest` (21 tests) + `MemoryModelTest` (19 tests) — 40 tests, 83 assertions. Covers relationships, effectiveTier, canCreateMemory, storage helpers, permissions, dates, Group/Friendship models. |
| 2026-02-16 | **Step 14.3 complete:** Backend API integration tests. `ApiIntegrationTest` (5 tests, 51 assertions) — full memory lifecycle, friend+share flow, groups+tags, permission hierarchy, contributor content. Total backend: 102 tests, 286 assertions. |
| 2026-02-16 | **Step 14.4 complete:** Frontend model + exception unit tests. 25 tests — Memory model (10), Group model (6), Exceptions (9). Services skipped for now (need DI refactor for HTTP mocking). |
| 2026-02-16 | **Step 14.5 complete:** Frontend widget tests. EmptyState (5 tests) + CustomInputField (4 tests). Total frontend: 34 tests. |
| 2026-02-16 | **Phase 14 complete (Step 14.6):** CI pipeline setup. GitHub Actions workflows for both repos — backend (PHP 8.3, SQLite, PHPUnit) and frontend (Flutter 3.29.x, analyze + test). Both trigger on push/PR to main/develop. **Phase 14 totals: Backend 102 tests (286 assertions), Frontend 34 tests.** |
| 2026-02-17 | **Step 15.17 complete:** External metadata storage. Backend: `MetadataManager` for JSON metadata on external storage, `metadata_mode` enum (local/external_cached/external_only), `MetadataMigrationController` for export/import. Frontend: Privacy Center screen, Privacy Setup Wizard (5-step), comments toggle. All l10n across 8 languages. |
| 2026-02-17 | **Step 15.18 complete / Phase 15 done:** 15 post-phase bug fixes and UX polish. (a) Fixed timeline/list toggle icons. (b) Fixed filter popup cutoff with `isScrollControlled` + scroll wrapper. (c) Added pull-to-refresh on memory detail. (d) Moved notifications to main page header. (e) Side menu unlock/lock toggle. (f) Side menu time period admin (new `TimePeriodsScreen`). (g) Side menu About section. (h) Profile screen: biometric above uploads, logout pinned to bottom. (i) Unlock flow checks `hasBiometricCredentials()` not `supportsBiometrics()`. (j) Settings section headers with icons + primary color + trailing divider. (k) Removed Edit Profile from settings. (l) Privacy Center: fixed local mode description, added "Not on server" section, storage settings link. (m) Android launcher icon via `flutter_launcher_icons`. (n) `HelpIconButton` widget with contextual help on Fulfill Request, Personal Memories, Time Periods, Biometric Login. (o) Personal memories hidden feedback: banner in empty state when PIN set but not unlocked. |
| 2026-02-18 | **Phases 16-20 planned:** Phase 16 (Critical Bug Fixes — profile image, personal memories in timeline, shared memories visibility, recording waveform, save button/media re-upload bugs, layout fixes). Phase 17 (Notification & Upload UX — friend request badge, notification navigation, push notifications via FCM, upload status header icon, upload-to-content navigation). Phase 18 (Friends System Overhaul — username system, expanded search, "Add Friend" flow replacing invite tabs, native share for invites). Phase 19 (Side Menu Time Period Filtering — tappable time periods in drawer with filter indicator). Phase 20 (Privacy Information Audit — full audit of Privacy Center accuracy, data storage, data flows, content corrections). |
| 2026-02-18 | **Step 16.1 complete:** Profile image not loading after login. Root cause: only normal email/password login updated `UserProvider` — biometric login (login screen + splash screen) and token-restore all skipped user data fetch. Fix: added `_loadUserData()` in `HomeScreen.initState()` so user data is always fetched regardless of auth path. Also added user data fetch to biometric login in `login_screen.dart`. |
| 2026-02-18 | **Step 16.2 complete:** Personal memories not appearing in timeline view. Investigation confirmed both timeline and list views receive the same `displayMemories` list — no filtering difference. Likely resolved by pagination fix from previous session. No code change needed. |
| 2026-02-18 | **Step 16.3 complete:** Shared memories not appearing in list/timeline. Root cause: `is_shared` flag in `MemoryListResource` only detected directly shared memories (user in `memory_user` pivot). Group-shared memories had `is_shared = false`. Fix: changed logic from "user is in pivot with non-owner permission" to "user is NOT the owner". |
| 2026-02-18 | **Step 16.4 complete:** Sound waves not shown during recording. Root cause: `_WaveformPainter.shouldRepaint()` compared `data.length` on old vs new painter, but both held a reference to the **same** mutable `_waveformData` list. Since `add()` mutated the list in place, `oldDelegate.data.length == data.length` was always true → `shouldRepaint` returned false → no repaint. Fix: pass `List.of(widget.waveformData)` to create an immutable snapshot per build, so old/new painters have different list objects. |
| 2026-02-18 | **Step 16.5 complete:** Save button not appearing when changing header photo. Root cause: `_pickImage()` set `_imageFile` but never set `_hasChanges = true`. Save button is conditional on `_hasChanges`. Fix: added `_hasChanges = true` inside the setState in `_pickImage()`. |
| 2026-02-18 | **Step 16.6 complete:** Re-saving memory makes media disappear. Three root causes: (1) `_loadExistingContent()` didn't populate `initialMediaPath` for image/video. (2) `_saveMemory()` sent empty objects for media content with no ID reference. (3) Backend `update()` unconditionally deleted ALL existing content files when `contents` was present. Fix: Added `existingContentId` field to `MemoryContentEditor`. Frontend now sends `id` for existing content. Backend preserves content with matching `id`, only deletes content NOT in the new list. Added `contents.*.id` validation rule. Fixed image display to handle both URL and file paths. |
| 2026-02-18 | **Step 16.7 complete:** Lock/unlock button overlapping text on profile page. Root cause: `ListTile` with `FilledButton.tonalIcon` in `trailing` competed for space with title `Row`. Fix: replaced `ListTile` with custom `Column` layout — info row on top, full-width action button below. |
| 2026-02-18 | **Step 16.8 complete:** Info icon for "Redeem Content Request" button. Added `HelpIconButton` next to the button using existing pattern. New l10n key `helpRedeemRequest` across 8 languages. |
| 2026-02-18 | **Step 16.9 complete:** Pattern unlock for personal memories. New `PatternLock` widget (custom 3x3 grid with `GestureDetector` + `CustomPaint`, min 4 nodes). New `PatternDialog` (set/change modes with draw → confirm flow). `PrivacyProvider` extended: `_patternKey` in secure storage, `setPattern()`/`verifyPattern()`/`clearPattern()`, pattern added to `unlock()` chain (biometrics → pattern → PIN) and `hasSecurityMethod()`. Profile screen: new "Set/Change Pattern" ListTile in privacy section. 12 new l10n keys across 8 languages. |
| 2026-02-18 | **Step 16.10 complete:** Sticky year headers in timeline view. Converted `ListView.builder` to `CustomScrollView` with `SliverPersistentHeader(pinned: true)` per year group. `_StickyYearHeaderDelegate` renders year label + time period chips, gains elevation when pinned. Year items grouped into `SliverList` sections. Old `_YearHeader` widget replaced. |
| 2026-02-18 | **Phase 16 complete.** 10 steps: 6 critical bug fixes (profile image, timeline, shared memories, recording waveform, save button, media re-save), 4 UI improvements (layout fix, info icon, pattern lock, sticky headers). Version bumped to 1.3.0. |
| 2026-02-18 | **Step 17.1 complete:** Notification badge on memory list header. Added `Badge` widget with unread count to the notification bell icon in `memory_list.dart`. Count refreshes after returning from `NotificationsScreen`. Friend request notifications were already being created by backend. |
| 2026-02-18 | **Step 17.2 complete:** Friend request notification navigation. Added `initialTabIndex` parameter to `FriendsScreen`. `NotificationsScreen._navigateToTarget()` now passes `initialTabIndex: 1` for `friend_request` type notifications, opening directly on the Requests tab. |
| 2026-02-18 | **Step 17.3 complete:** Push notifications (FCM). Backend: `PushNotificationService` sends FCM via HTTP v1 API with JWT auth (no extra package needed — uses Guzzle). Hooked into `AppNotification::notify()`. Respects quiet mode (silent push). Auto-cleans stale device tokens. Firebase config in `services.php` + `.env.example`. Frontend: `PushNotificationProvider` — Firebase init, permission request, token registration/refresh, foreground/background/terminated message handling. Token removed on logout. Requires Firebase project credentials to activate. |
| 2026-02-18 | **Step 17.4 complete:** Upload status icon in header. `Consumer<UploadService>` in memory list header shows cloud icon with badge count when uploads are active/failed. `cloud_off` icon for failures. Tapping opens dialog with upload list showing type, status, progress, retry button. Each item navigates to its memory. |
| 2026-02-18 | **Step 17.5 complete:** Navigate to content from upload list. Both the header upload popup and profile `PendingUploadsList` items are now tappable — navigate to `MemoryDetailScreen` for the associated memory via `int.tryParse(upload.memoryId)`. |
| 2026-02-18 | **Phase 17 complete.** 5 steps: notification badge, friend request tab navigation, FCM push notifications, upload status header icon, upload-to-memory navigation. |
| 2026-02-18 | **Step 20.6 complete:** Enhanced storage setup guide. Backend: `storage_setup_completed` boolean on users table, `POST /storage/setup-complete` endpoint, flag included in `GET /storage/settings`. Frontend: New `StorageSetupScreen` wizard shown after first login/registration — 3-step PageView: (1) choose "Our server" or "Self-hosted", (2) if self-host: Dropbox/FTP/SMB connection, (3) confirmation. `SplashScreen` + `LoginScreen` + `RegisterScreen` all route through setup check. Memory creation blocked with dialog when setup not completed (allows viewing friends' memories). 31 new l10n keys across 8 languages. Version bumped to 0.x.x for pre-release. |
| 2026-02-18 | **Phase 21 complete.** 6 bug-fix steps: (21.1) Moved personal/shared memory filtering server-side for correct pagination — added `personal_only` and `shared_only` backend query params; (21.2) Rewrote timeline sticky year headers using single Stack overlay with GlobalKey-based scroll tracking; (21.3) Fixed Privacy Center incorrectly claiming media is not on server — added `privacyServerMedia` to server card when no external storage; (21.4) Renamed "Local Storage" to "Memory Lane Server" across all 8 languages, updated icon to `dns_outlined`, always show green check for active provider; (21.5) Added pattern lock management to Settings screen (set/change/clear), replaced hardcoded dialog strings with l10n keys; (21.6) Replaced hardcoded version "1.2.0" with dynamic `PackageInfo`, added About dialog with correct developer name (ø) and localized description. Version bumped to **0.7.0+1**. |
| 2026-02-19 | **Phase 23 bug fixes complete (steps 23.4-23.9).** (23.4) Storage "decide later" fix — added confirm button + visual warning when setup incomplete; (23.5) Shared memory update fix — backend silently skips owner-only fields for contributors instead of returning 403; (23.6) Search case-insensitivity fix — backend now uses explicit `LOWER()/mb_strtolower()` with LIKE wildcard escaping on both endpoints; (23.7) Privacy Center spinner fix — only shows loading spinner on initial load, not on re-fetches when settings already loaded; (23.8) Search clear race condition fix — added `_loadGeneration` counter to discard stale API responses; (23.9) Sticky year headers — replaced Material elevation shadow with subtle bottom border. Version bumped to **0.8.1+1**. |
| 2026-02-19 | **Phase 24 complete (steps 24.1-24.2).** Memory tagging enhancement. (24.1) Inline tag management on create/edit screen — backend: `tags` validation in `StoreMemoryRequest`, `tags()->sync()` in `MemoryController::store()` and `update()` (owner-only); frontend: `tagIds` param on `MemoryService.createMemory()/updateMemory()`, FilterChip tag section in `CreateMemoryScreen` with inline tag creation. (24.2) Auto-suggest tags — backend: new `GET /tags/suggestions` endpoint (most-used tags, keyword matching, time period matching, year suggestion); frontend: `TagSuggestions` model, suggestions displayed as ActionChips above tag list, refreshed on date change. 1 new l10n key (`suggestedTags`) across 8 languages. Version bumped to **0.9.0+1**. |
| 2026-02-20 | **Step 25.8 complete / Phase 25 done.** Fixed groups page not reloading after group creation. Root cause: `_saveGroup()` used the bottom sheet's deactivated `BuildContext` for `ScaffoldMessenger` after `Navigator.pop()`, causing an exception that skipped `_loadGroups()`. Fixed by using State's `context` for all post-pop UI calls and moving `_loadGroups()` outside try-catch. Same fix applied to `_confirmDeleteGroup()`. |
| 2026-03-02 | **Phase 27 complete: Wear OS Integration.** Android Auto skipped — Android Auto cannot access microphone for audio recording. Wear OS implementation: backend device pairing API (6-digit code flow with Sanctum token issuance), Wear OS Flutter app with platform detection via MethodChannel, pairing screen (code display + polling), quick record screen (circular watch UI, mono AAC-LC recording, auto-save), phone-side pair watch screen in Account Settings. Dependencies: `wear_plus: ^1.2.4`. 8 new l10n keys across 8 languages. Version bumped to **0.10.0**. |
| 2026-03-03 | **Phase 28 (steps 28.1–28.3, 28.5) complete: Audio Player Overhaul.** Backend: proper `BinaryFileResponse` with Range request support + correct MIME types for `.m4a`. Frontend: `MemoryAudioPlayer` rewritten with spinner while `setSource()` loads, restart button, error+retry state. No new l10n strings needed. Step 28.4 (Android Foreground Service for bulletproof recording) deferred. |
| 2026-03-03 | **Phase 28.4 complete: Bulletproof recording.** `WidgetsBindingObserver` added to `RecordMemoryScreen` and `WearRecordScreen` — auto-stops and saves on lifecycle interruption. Recovery flow via `SharedPreferences`: recording path + elapsed time + waveform stored every 30s, checked on next open with a Save/Discard dialog. Ongoing recording notification via `NotificationService` (updates every 10s). `cancelNotification` added to native `NotificationHelper` + `MainActivity`. About page version display updated: shows `0.11.0` normally, `0.11.0 (rev 2)` for subsequent builds of the same version. `BUILD_REV` passed as `--dart-define` from `build.sh`. |
| 2026-03-03 | **Phase 29 complete: Quick Memory Workflow & Content Management.** Backend: `is_quick_memory` column on memories, `GET /memories/inbox` endpoint, `POST /memories/{id}/contents/{id}/move` endpoint (moves file in storage + updates record). Frontend: `VoiceMemosScreen` (staging area for quick recordings, named "Voice Memos" not "Inbox"), amber badge in drawer, long-press on content items (move to another memory / delete), long-press on memory list items (delete for owners). 9 new l10n keys across all 8 languages. Version bumped to **0.11.0** (frontend) / **0.13.0** (backend). |
| 2026-03-05 | **Phase 32B complete: AI Provider Expansion, Queue System & Voice Cloning.** Multi-provider architecture: OpenAI (cloud), Ollama (self-hosted text gen), Coqui XTTS (self-hosted TTS + voice cloning), Local Whisper (self-hosted transcription). All AI jobs now async via Laravel queue (ai queue, --max-jobs=1 for model memory management). Queue infrastructure: jobs table, ai_jobs table with status tracking, 4 queue job classes. Voice cloning infrastructure: VoiceCloneProvider contract, voice_samples table with consent tracking, CoquiVoiceClone provider, VoiceCloneJob, VoiceSampleController. Admin UI restructured from capability-centric to provider-centric with test connection buttons for each provider. Frontend adapted for async: AiJob model, waitForJob() polling, VoiceSampleManager widget. 26 new l10n keys across 8 languages. file_picker dependency added. Version bumped to **0.14.0** (frontend) / **0.16.0** (backend). |
| 2026-03-05 | **Phase 33 complete: Inline AI UX.** Moved AI features from buried menus to visible inline buttons. Memory detail screen: "Narrate" button below text content, "Transcribe" button below audio/video, AI Generate Cover button in cover area (outlined button when no cover, overlay chip when cover exists). Removed AI Suggest and Generate Cover from overflow menu, removed Transcribe and Read Aloud from long-press menu. Edit memory screen: "Generate with AI" option in cover photo picker, AI suggest sparkle button next to title field, "AI Suggest Tags" chip in tag section, "AI Suggest Date" button after date picker. All AI features use cached metadata to avoid duplicate API calls. AI buttons only shown when editing existing memories and AI is available. 5 new l10n keys across all 8 languages. |
| 2026-03-05 | **AI bug fixes & improvements.** Fixed `StorageManager::resolveForUser()` → `forUser()` in 3 AI job files (TTS, VoiceClone, Transcribe). Fixed `User.fromJson` null cast in `memory.dart`. Added TTS voice preview endpoint with file-based caching (`storage/app/tts-previews/`). Added preview play buttons in AI Settings page. Made cover image description optional — auto-generates visual prompt from memory content using text generation. Added `generateText()` to TextGenerationProvider contract. Passed app locale to TTS calls. Added localization keys (`voicePreview`, `coverAutoGenerateHint`) to all 8 languages. Added Phase 36 (Inline AI UX) and AI Image Generation Content Policy backlog item to PROJECT.md. |
| 2026-03-05 | **Phase 32 complete: AI Features.** Full AI integration across 10 batches. Backend: AI contracts/DTOs/manager with registry pattern, OpenAI provider implementations (Whisper, GPT-4o, DALL-E, TTS), 3 migrations (AI fields on memory_contents, memories, users), model/resource updates, AIController with 8 endpoints (capabilities, transcribe, generate-metadata, apply-metadata, generate-cover, text-to-speech, user settings get/patch), Filament AISettings admin page. Frontend: ai_service.dart singleton, ai_capabilities/ai_metadata models, AI settings page with voice picker, onboarding AI step with opt-in toggle, 4 AI widgets (ai_badge, ai_metadata_sheet, ai_cover_generator, voice_picker_sheet), AI actions in memory detail screen (transcribe, read aloud, AI suggest, generate cover). 33 new l10n keys across all 8 languages. "ai_features" added to support sections. Version bumped to **0.13.0** (frontend) / **0.15.0** (backend). |
| 2026-03-06 | **Phase 33B: Bug Fixes — Uploads, Audio Playback, AI Content Linking.** 12 bug fixes/improvements. Backend: upload key refresh endpoint, TTS waveform generation, waveform field in API response, AI content replacement logic (TTS+transcription), transcription post-processing through AI formatter. Frontend: upload retry with fresh keys, audio replay fix (completed state handling), linked content grouped display, AI action guards on generated content, confirmation dialogs for replace operations, author display on first entry, watch transfer indicator on home screen. Admin: "Copy as JSON" button for full error log entries. 8 new l10n keys across all 8 languages. |

---

## Code Guidelines

### General Principles

- **Privacy first.** See "Core Principles: Privacy & Data Ownership" above. When in doubt about a design choice, choose the option that gives the user more control and us less access. Never log, cache, or transmit user content beyond what's strictly necessary for the operation at hand.
- **Documentation:** All classes and public methods must have docblocks describing purpose, parameters, and return values. Skip only for trivial getters/setters where the name is self-explanatory.
- **Naming:** Follow each framework's default conventions (Laravel for backend, Flutter/Dart for frontend). No custom suffixes or prefixes unless the framework already uses them.
- **Error handling:** Use a mix of centralized and per-call handling. A global handler catches unexpected errors and formats them consistently. Specific try-catch blocks where business logic needs a custom response or recovery.
- **Versioning:** Both frontend and backend follow [Semantic Versioning 2.0.0](https://semver.org/). Bump the version when completing a phase or shipping a meaningful change. Use patch for bug fixes, minor for new features, major for breaking changes.
  - Frontend version: `Frontend/pubspec.yaml` → `version` field (e.g., `0.9.0+1`)
  - Backend version: `Backend/config/app.php` → `app.version` (e.g., `0.9.0`)

---

### Backend (Laravel / PHP)

#### Architecture

- **Controllers hold the logic.** Keep business logic in controllers directly. Use traits for shared behavior across controllers. Only extract to a Service class if the same logic is genuinely needed in multiple controllers or non-HTTP contexts (e.g., a queue job).
- **Base model pattern.** When a group of models share behavior or fields, create an abstract base model that the concrete models extend. This avoids duplicating logic and makes the shared contract explicit.

  Example - file storage:
  ```
  app/Models/Storage/
  ├── BaseStorageProvider.php      ← Abstract base: shared fields, validation, interface methods
  ├── FtpStorageProvider.php       ← Extends base: FTP-specific connection logic
  ├── LocalStorageProvider.php     ← Extends base: local filesystem logic
  ├── SmbStorageProvider.php       ← Extends base: SMB/network share logic
  └── DropboxStorageProvider.php   ← Extends base: Dropbox API logic
  ```

- **Interface + abstract base for integrations.** When building extensible systems (storage providers, notification channels, etc.):
  1. Define a PHP **interface** that declares the contract (e.g., `StorageProviderInterface`)
  2. Create an **abstract base class** that implements shared logic and common fields
  3. Concrete classes **extend the base** and implement provider-specific behavior

  This gives you swappable implementations for testing and clean contracts for new integrations.

#### API Responses

- Use **Laravel API Resources** for all responses. They provide a clean, consistent structure out of the box.
- Error responses must always follow a structured format:
  ```json
  {
    "message": "Human-readable error description",
    "errors": { "field": ["Validation message"] }
  }
  ```
- Use appropriate HTTP status codes (200, 201, 204, 400, 401, 403, 404, 422, 500).

#### File & Folder Conventions

- Follow Laravel's default directory structure.
- Group related models into subdirectories when a domain grows (e.g., `app/Models/Storage/`).
- Route files are split by domain in `routes/endpoints/` - continue this pattern for new features.
- Migrations are prefixed with timestamps (Laravel default).

#### Database

- Always create migrations for schema changes, never modify the database directly.
- Use foreign key constraints with cascade deletes where appropriate.
- Add indexes for columns used in WHERE clauses, JOINs, or ORDER BY on large tables.

---

### Frontend (Flutter / Dart)

#### Architecture

- **Small, composable widgets.** Break screens into focused widget files, each responsible for one piece of UI. Extract a widget when:
  - It has its own state or logic
  - It could be reused on another screen
  - The parent's `build()` method exceeds ~100 lines
- **State management: Provider + ChangeNotifier.** This is the chosen pattern for the project. Do not introduce Riverpod, Bloc, or other state management libraries.
- **Services are singletons.** ApiService and other services use the singleton pattern. Keep this consistent for new services.

#### File & Folder Conventions

- Follow Dart/Flutter conventions: `snake_case` for file names, `PascalCase` for classes.
- Screens go in `lib/screens/`, reusable widgets in `lib/widgets/`.
- Group related widgets in subdirectories (e.g., `widgets/settings/`).
- Models in `lib/models/`, services in `lib/services/`, providers in `lib/providers/`.
- Config files in `lib/config/`.

#### API Integration

- All HTTP calls go through `ApiService`. Never use `http` package directly in screens or widgets.
- Handle errors using the custom exception hierarchy in `utils/exceptions.dart`.
- Use the `UploadService` for any file upload operations (queuing, retry, progress tracking).

#### Localization

- All user-facing strings must go through the localization system (`AppLocalizations`).
- English (`app_en.arb`) is the source template. Add new keys there first, then to other languages.
- Currently supports 8 languages: EN, DA, DE, ES, FR, JA, KO, ZH.
- **Phase completion rule:** When a phase is marked complete, all missing labels must be translated to every supported language before moving on. No phase is truly done until translations are complete.

#### Theming

- Use the existing `ThemeProvider` and `ColorConfig` system. Do not hardcode colors.
- All colors must work in both light and dark mode.
- Use `Theme.of(context)` to access colors in widgets.

---

## Notes & Decisions

> Record important decisions, gotchas, or architectural notes here.

- **Backend production URL:** `https://memorylane.blommemix.dk/api`
- **Author:** Mikkel Bjornmose Bundgaard (info@inspireme.dk)
- **Media storage pattern:** `storage/memories/{memory_id}/{type}s/` (e.g., audios/, videos/, images/)
- **Upload flow:** Two-step process - create content record (get upload_key) -> upload file using that key. This prevents file confusion and provides audit trail.
- **Frontend uses direct Navigator.of()** - no routing library. Consider adding go_router if navigation grows more complex.
- **SSL pinning** is configured for Let's Encrypt certificate in the frontend.
- **CORS is currently wide open** (all origins) - should be tightened for production.
- **Local development:** Backend runs via `php artisan serve` at `http://127.0.0.1:8000`. Frontend switches between local/production via `useDevelopmentServer` flag in `api_config.dart`. During active development, always use the local backend.
- **Frontend API config** (`lib/config/api_config.dart`): Has `productionHost`, `developmentHost`, and a `useDevelopmentServer` boolean toggle. Also has SSL pinning for Let's Encrypt - this must not block local HTTP connections.
- **Data ownership guarantee:** Downgrading a payment tier (Phase 11) must never delete existing content. It only limits new creation. Users can always export or move their data regardless of tier.
- **No data retention after deletion:** When a user deletes content or their account, all associated files must be removed from storage (including external providers). No "soft delete" retention of media files.
- **Contributor file routing:** Files uploaded by contributors are relayed to the memory owner's storage and not retained on our server after successful delivery. The relay is temporary and purely functional.
- **Android Auto limitation:** Android Auto cannot access the phone/car microphone for audio recording. It only supports templated UI for media playback, messaging, and navigation. Audio recording from Android Auto is not possible with the current Android Auto SDK.
- **Wear OS architecture:** The same Flutter APK runs on both phone and watch. Platform is detected at startup via a native MethodChannel (`PackageManager.FEATURE_WATCH`). On Wear OS, the app shows a minimal pairing → record flow instead of the full phone UI. Auth is handled via phone pairing (6-digit code) rather than direct login on the watch.
- **Device pairing flow:** Watch generates 6-digit code → calls `POST /pairing/initiate` (no auth, rate-limited) → polls `GET /pairing/status` every 3s → Phone user enters code → calls `POST /pairing/confirm` (authenticated) → backend issues Sanctum token → watch receives token on next poll.
