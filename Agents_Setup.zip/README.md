# Memory Lane

A personal memory-sharing app where users can create, share, and collaboratively contribute to memories with family and friends.

## Repository Structure

```
Memory Lane/
  Frontend/   # Flutter mobile app (Dart)
  Backend/    # Laravel REST API (PHP)
  PROJECT.md  # Living project document & development plan
  CLAUDE.md   # AI assistant instructions & project conventions
```

## Quick Start

### Backend (Laravel API)

```sh
cd Backend
composer install
cp .env.example .env
php artisan key:generate
# Configure DB credentials in .env
php artisan migrate
php artisan storage:link
php artisan serve
```

The API runs at `http://127.0.0.1:8000/api`. Admin panel at `/admin`.

### Frontend (Flutter App)

```sh
cd Frontend
flutter pub get
flutter run
```

By default connects to the local backend. See below for production builds.

---

## Build & Deploy

### Frontend — Build Production APK

Use the `build.sh` helper script. It reads from `.env.production`, builds the APK, and renames it to `MemoryLane-{version}-production-release.apk`.

```sh
cd Frontend
bash build.sh -e production
```

The output APK is at:
```
Frontend/build/app/outputs/flutter-apk/MemoryLane-{version}-production-release.apk
```

Other build options:
```sh
bash build.sh -e production -t appbundle   # App Bundle (Play Store)
bash build.sh -e production -d             # Debug build against production API
bash build.sh                              # Local dev APK (default)
bash build.sh -h                           # Show all options
```

**Without the build script** (raw Flutter command — output will be named `app-release.apk`):
```sh
flutter build apk --dart-define=ENVIRONMENT=production
```

### Backend — Deploy to Production

Deployment is automated via GitHub Actions. When a **GitHub Release** is published:

1. The workflow checks out the repository
2. Rsyncs `Backend/` to the production server
3. Runs `deploy.sh` on the server (migrations, cache clear, permissions, docs)

To deploy manually (e.g. via SSH):
```sh
cd /var/www/.../public_html
# Upload Backend/ files
bash deploy.sh
```

`deploy.sh` handles: `composer install --no-dev`, migrations, storage symlink, Filament assets, cache clearing, permissions, and API docs regeneration.

---

## Project Details

| | Frontend | Backend |
|---|---|---|
| **Tech** | Flutter / Dart 3.7+ | Laravel 12 / PHP 8.4+ |
| **State** | Provider + ChangeNotifier | — |
| **Auth** | Sanctum tokens | Laravel Sanctum |
| **Database** | — | MySQL / MariaDB |
| **Localization** | 8 languages (en, da, de, es, fr, ja, ko, zh) | — |
| **Admin** | — | Filament 3.3 at `/admin` |
| **API Docs** | — | Scribe at `/docs` |
| **Production API** | `https://memorylane.blommemix.dk/api` | — |

## More Documentation

- [Frontend/README.md](Frontend/README.md) — Flutter setup, environment files, debugging, testing
- [Backend/README.md](Backend/README.md) — Laravel setup, admin panel, deploy script details
- [PROJECT.md](PROJECT.md) — Full development plan, architecture, and change log
